import 'package:flutter/material.dart';

class HomePage extends StatelessWidget {
  const HomePage({super.key});

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      backgroundColor: const Color(0xFFF4F6F8),
      appBar: AppBar(
        title: const Text(
          'AccessOne - G&E Security',
          style: TextStyle(fontWeight: FontWeight.w600),
        ),
        backgroundColor: const Color(0xFF0a3d62),
        foregroundColor: Colors.white,
        centerTitle: true,
        elevation: 4,
      ),
      body: Padding(
        padding: const EdgeInsets.all(24.0),
        child: Center(
          child: Column(
            mainAxisAlignment: MainAxisAlignment.center,
            children: [
              const Text(
                'Escolha o tipo de ambiente:',
                style: TextStyle(
                  fontSize: 22,
                  fontWeight: FontWeight.bold,
                  color: Color(0xFF0a3d62),
                ),
              ),
              const SizedBox(height: 40),

              // --- Botão Residencial ---
              _buildMainButton(
                context,
                icon: Icons.apartment_rounded,
                title: 'Condomínio Residencial',
                subtitle: 'Acesse as áreas comuns, reservas e visitantes.',
                route: '/reserva_residencial',
                color: Colors.indigo.shade600,
              ),

              const SizedBox(height: 25),

              // --- Botão Comercial ---
              _buildMainButton(
                context,
                icon: Icons.business_center_rounded,
                title: 'Condomínio Comercial',
                subtitle: 'Gerencie salas, eventos e estacionamento.',
                route: '/reserva_comercial',
                color: Colors.teal.shade700,
              ),

              const SizedBox(height: 25),

              // --- Botão Notificações de Encomendas ---
              _buildMainButton(
                context,
                icon: Icons.notifications_active_rounded,
                title: 'Notificações de Encomendas',
                subtitle: 'Visualize entregas e avisos da portaria.',
                route: '/notificacoes',
                color: Colors.orange.shade800,
              ),

              const SizedBox(height: 50),

              // Rodapé
              const Text(
                'AccessOne • Sistema Integrado de Portaria e Estacionamento',
                textAlign: TextAlign.center,
                style: TextStyle(color: Colors.grey, fontSize: 13),
              ),
            ],
          ),
        ),
      ),
    );
  }

  Widget _buildMainButton(
    BuildContext context, {
    required IconData icon,
    required String title,
    required String subtitle,
    required String route,
    required Color color,
  }) {
    return InkWell(
      onTap: () => Navigator.pushNamed(context, route),
      borderRadius: BorderRadius.circular(16),
      child: Ink(
        decoration: BoxDecoration(
          color: Colors.white,
          borderRadius: BorderRadius.circular(16),
          boxShadow: [
            BoxShadow(
              color: Colors.black12,
              blurRadius: 8,
              offset: const Offset(0, 3),
            ),
          ],
        ),
        child: Padding(
          padding: const EdgeInsets.symmetric(vertical: 20, horizontal: 18),
          child: Row(
            children: [
              CircleAvatar(
                radius: 28,
                backgroundColor: color.withOpacity(0.15),
                child: Icon(icon, size: 34, color: color),
              ),
              const SizedBox(width: 18),
              Expanded(
                child: Column(
                  crossAxisAlignment: CrossAxisAlignment.start,
                  children: [
                    Text(
                      title,
                      style: TextStyle(
                        fontSize: 18,
                        fontWeight: FontWeight.w600,
                        color: color,
                      ),
                    ),
                    const SizedBox(height: 5),
                    Text(
                      subtitle,
                      style: const TextStyle(color: Colors.black54),
                    ),
                  ],
                ),
              ),
              const Icon(Icons.arrow_forward_ios_rounded,
                  color: Colors.grey, size: 18),
            ],
          ),
        ),
      ),
    );
  }
}
