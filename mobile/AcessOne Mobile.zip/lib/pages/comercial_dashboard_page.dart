import 'package:flutter/material.dart';

class ComercialDashboardPage extends StatelessWidget {
  const ComercialDashboardPage({super.key});

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      backgroundColor: const Color(0xFFF4F6F8),
      appBar: AppBar(
        title: const Text(
          'Painel Comercial',
          style: TextStyle(fontWeight: FontWeight.w600),
        ),
        backgroundColor: const Color(0xFF0a3d62),
        foregroundColor: Colors.white,
        centerTitle: true,
        elevation: 4,
        actions: [
          IconButton(
            icon: const Icon(Icons.logout),
            tooltip: 'Sair',
            onPressed: () {
              Navigator.pushReplacementNamed(context, '/login');
            },
          ),
        ],
      ),
      body: Padding(
        padding: const EdgeInsets.all(24.0),
        child: Center(
          child: Column(
            mainAxisAlignment: MainAxisAlignment.center,
            children: [
              const Text(
                'Escolha uma ação:',
                style: TextStyle(
                  fontSize: 22,
                  fontWeight: FontWeight.bold,
                  color: Color(0xFF0a3d62),
                ),
              ),
              const SizedBox(height: 40),

              _buildMainButton(
                context,
                icon: Icons.event_available_rounded,
                title: 'Gerenciar Reservas',
                subtitle: 'Controle salas, eventos e espaços comerciais.',
                route: '/reserva_comercial',
                color: Colors.teal.shade700,
              ),
              const SizedBox(height: 25),

              _buildMainButton(
                context,
                icon: Icons.support_agent_rounded,
                title: 'Abrir Chamado',
                subtitle: 'Reportar incidentes ou solicitar manutenção.',
                route: '/chamado_comercial',
                color: Colors.deepOrange.shade600,
              ),
              const SizedBox(height: 25),

              _buildMainButton(
                context,
                icon: Icons.notifications_active_rounded,
                title: 'Notificações de Encomendas',
                subtitle: 'Visualize entregas e avisos da portaria.',
                route: '/notificacoes_encomendas',
                color: Colors.orange.shade600,
              ),

              const SizedBox(height: 50),
              const Text(
                'AccessOne • Sistema Integrado de Portaria e Estacionamento',
                textAlign: TextAlign.center,
                style: TextStyle(color: Colors.grey, fontSize: 13),
              ),
            ],
          ),
        ),
      ),
    );
  }

  Widget _buildMainButton(
    BuildContext context, {
    required IconData icon,
    required String title,
    required String subtitle,
    required String route,
    required Color color,
  }) {
    return InkWell(
      onTap: () => Navigator.pushNamed(context, route),
      borderRadius: BorderRadius.circular(16),
      child: Ink(
        decoration: BoxDecoration(
          color: Colors.white,
          borderRadius: BorderRadius.circular(16),
          boxShadow: [
            BoxShadow(
              color: Colors.black12,
              blurRadius: 8,
              offset: const Offset(0, 3),
            ),
          ],
        ),
        child: Padding(
          padding: const EdgeInsets.symmetric(vertical: 20, horizontal: 18),
          child: Row(
            children: [
              CircleAvatar(
                radius: 28,
                backgroundColor: color.withOpacity(0.15),
                child: Icon(icon, size: 34, color: color),
              ),
              const SizedBox(width: 18),
              Expanded(
                child: Column(
                  crossAxisAlignment: CrossAxisAlignment.start,
                  children: [
                    Text(
                      title,
                      style: TextStyle(
                        fontSize: 18,
                        fontWeight: FontWeight.w600,
                        color: color,
                      ),
                    ),
                    const SizedBox(height: 5),
                    Text(subtitle,
                        style: const TextStyle(color: Colors.black54)),
                  ],
                ),
              ),
              const Icon(Icons.arrow_forward_ios_rounded,
                  color: Colors.grey, size: 18),
            ],
          ),
        ),
      ),
    );
  }
}
