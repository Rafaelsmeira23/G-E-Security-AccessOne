import 'package:flutter/material.dart';

class ReservaComercialPage extends StatefulWidget {
  const ReservaComercialPage({super.key});

  @override
  State<ReservaComercialPage> createState() => _ReservaComercialPageState();
}

class _ReservaComercialPageState extends State<ReservaComercialPage> {
  final _formKey = GlobalKey<FormState>();
  String? _espacoSelecionado;
  DateTime? _dataSelecionada;
  TimeOfDay? _inicio;
  TimeOfDay? _fim;
  final TextEditingController nomeCtrl = TextEditingController();
  final TextEditingController totalCtrl = TextEditingController();
  final TextEditingController emailCtrl = TextEditingController();
  final TextEditingController telefoneCtrl = TextEditingController();
  bool aceitarTermos = false;
  bool habilitarIntegrantes = false;
  List<TextEditingController> integrantes = [];
  String? mensagem;
  bool sucesso = false;

  void _gerarCampos() {
    final total = int.tryParse(totalCtrl.text) ?? 0;
    setState(() {
      integrantes = List.generate(total, (_) => TextEditingController());
    });
  }

  Future<void> _selecionarData() async {
    final data = await showDatePicker(
      context: context,
      initialDate: DateTime.now(),
      firstDate: DateTime.now(),
      lastDate: DateTime(2030),
    );
    if (data != null) setState(() => _dataSelecionada = data);
  }

  Future<void> _selecionarHoraInicio() async {
    final hora = await showTimePicker(
      context: context,
      initialTime: TimeOfDay.now(),
    );
    if (hora != null) setState(() => _inicio = hora);
  }

  Future<void> _selecionarHoraFim() async {
    final hora = await showTimePicker(
      context: context,
      initialTime: TimeOfDay.now(),
    );
    if (hora != null) setState(() => _fim = hora);
  }

  void _enviar() {
    setState(() {
      mensagem = null;
      sucesso = false;
    });

    if (!_formKey.currentState!.validate()) {
      setState(() {
        mensagem = 'Por favor, preencha todos os campos obrigatórios corretamente.';
      });
      return;
    }

    if (!aceitarTermos) {
      setState(() {
        mensagem = 'É necessário aceitar os termos e condições para prosseguir.';
      });
      return;
    }

    if (_inicio != null && _fim != null) {
      final inicioMin = _inicio!.hour * 60 + _inicio!.minute;
      final fimMin = _fim!.hour * 60 + _fim!.minute;
      if (inicioMin >= fimMin) {
        setState(() {
          mensagem = 'O horário final deve ser maior que o horário inicial.';
        });
        return;
      }
    }

    setState(() {
      sucesso = true;
      mensagem = 'Reserva realizada com sucesso!';
      _formKey.currentState!.reset();
      _espacoSelecionado = null;
      _inicio = _fim = null;
      _dataSelecionada = null;
      aceitarTermos = false;
      habilitarIntegrantes = false;
      integrantes.clear();
      totalCtrl.clear();
    });

    ScaffoldMessenger.of(context).showSnackBar(
      const SnackBar(
        content: Text('Reserva realizada com sucesso!'),
        backgroundColor: Colors.green,
        duration: Duration(seconds: 2),
      ),
    );
  }

  // 🔹 Função de logout com confirmação
  void _logout() {
    showDialog(
      context: context,
      builder: (context) => AlertDialog(
        title: const Text('Sair'),
        content: const Text('Tem certeza de que deseja sair do sistema?'),
        actions: [
          TextButton(
            onPressed: () => Navigator.pop(context),
            child: const Text('Cancelar'),
          ),
          TextButton(
            onPressed: () {
              Navigator.pop(context);
              Navigator.pushReplacementNamed(context, '/login');
            },
            child: const Text(
              'Sair',
              style: TextStyle(color: Colors.red),
            ),
          ),
        ],
      ),
    );
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        title: const Text('Reserva Comercial'),
        backgroundColor: const Color(0xFF222222),
        foregroundColor: const Color(0xFFD9C66B),
        centerTitle: true,
        actions: [
          IconButton(
            icon: const Icon(Icons.logout),
            tooltip: 'Sair',
            onPressed: _logout,
          ),
        ],
      ),
      body: Container(
        decoration: const BoxDecoration(
          gradient: LinearGradient(
            colors: [Color(0xFF4A4A4A), Color(0xFFA8A8A8)],
            begin: Alignment.centerLeft,
            end: Alignment.centerRight,
          ),
        ),
        child: Center(
          child: SingleChildScrollView(
            padding: const EdgeInsets.all(16),
            child: Column(
              children: [
                Card(
                  color: const Color(0xDD222222),
                  elevation: 8,
                  shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(12)),
                  child: Padding(
                    padding: const EdgeInsets.all(16),
                    child: Column(
                      children: const [
                        SizedBox(height: 12),
                        Text(
                          'Reservar espaço comercial',
                          style: TextStyle(
                            color: Color(0xFFD9C66B),
                            fontWeight: FontWeight.bold,
                            fontSize: 22,
                            letterSpacing: 0.8,
                          ),
                        ),
                      ],
                    ),
                  ),
                ),
                const SizedBox(height: 16),
                Card(
                  elevation: 6,
                  shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(12)),
                  child: Padding(
                    padding: const EdgeInsets.all(16),
                    child: Form(
                      key: _formKey,
                      child: Column(
                        crossAxisAlignment: CrossAxisAlignment.start,
                        children: [
                          const Text('Selecione o espaço', style: TextStyle(fontWeight: FontWeight.bold)),
                          const SizedBox(height: 8),
                          Wrap(
                            spacing: 12,
                            runSpacing: 8,
                            children: [
                              _radioEspaco('Sala de reunião'),
                              _radioEspaco('Auditório'),
                              _radioEspaco('Espaço gourmet (eventos)'),
                              _radioEspaco('Sala de treinamento'),
                              _radioEspaco('Área de convivência'),
                            ],
                          ),
                          const SizedBox(height: 16),
                          const Text('Escolha a data', style: TextStyle(fontWeight: FontWeight.bold)),
                          const SizedBox(height: 8),
                          InkWell(
                            onTap: _selecionarData,
                            child: InputDecorator(
                              decoration: const InputDecoration(
                                labelText: 'Data',
                                border: OutlineInputBorder(),
                              ),
                              child: Text(
                                _dataSelecionada == null
                                    ? 'Selecione...'
                                    : '${_dataSelecionada!.day}/${_dataSelecionada!.month}/${_dataSelecionada!.year}',
                              ),
                            ),
                          ),
                          const SizedBox(height: 16),
                          const Text('Escolha o horário', style: TextStyle(fontWeight: FontWeight.bold)),
                          const SizedBox(height: 8),
                          Row(
                            children: [
                              Expanded(
                                child: InkWell(
                                  onTap: _selecionarHoraInicio,
                                  child: InputDecorator(
                                    decoration: const InputDecoration(labelText: 'Início'),
                                    child: Text(_inicio?.format(context) ?? 'Selecione...'),
                                  ),
                                ),
                              ),
                              const Padding(
                                padding: EdgeInsets.symmetric(horizontal: 8.0),
                                child: Text('até'),
                              ),
                              Expanded(
                                child: InkWell(
                                  onTap: _selecionarHoraFim,
                                  child: InputDecorator(
                                    decoration: const InputDecoration(labelText: 'Fim'),
                                    child: Text(_fim?.format(context) ?? 'Selecione...'),
                                  ),
                                ),
                              ),
                            ],
                          ),
                          const SizedBox(height: 16),
                          TextFormField(
                            controller: nomeCtrl,
                            decoration: const InputDecoration(
                              labelText: 'Nome completo do responsável',
                            ),
                            validator: (v) => v!.isEmpty ? 'Campo obrigatório' : null,
                          ),
                          const SizedBox(height: 16),
                          CheckboxListTile(
                            title: const Text('Há outros participantes nesta reserva?'),
                            value: habilitarIntegrantes,
                            onChanged: (v) {
                              setState(() {
                                habilitarIntegrantes = v ?? false;
                                if (!habilitarIntegrantes) {
                                  integrantes.clear();
                                  totalCtrl.clear();
                                } else {
                                  _gerarCampos();
                                }
                              });
                            },
                          ),
                          if (habilitarIntegrantes) ...[
                            const SizedBox(height: 8),
                            TextFormField(
                              controller: totalCtrl,
                              keyboardType: TextInputType.number,
                              decoration: const InputDecoration(
                                labelText: 'Total de participantes',
                              ),
                              onChanged: (_) => _gerarCampos(),
                            ),
                            const SizedBox(height: 8),
                          ],
                          for (int i = 0; i < integrantes.length; i++)
                            TextFormField(
                              controller: integrantes[i],
                              decoration: InputDecoration(labelText: 'Nome do participante ${i + 1}'),
                              validator: (v) {
                                if (habilitarIntegrantes && (v == null || v.isEmpty)) {
                                  return 'Preencha o nome';
                                }
                                return null;
                              },
                            ),
                          const SizedBox(height: 16),
                          TextFormField(
                            controller: emailCtrl,
                            keyboardType: TextInputType.emailAddress,
                            decoration: const InputDecoration(labelText: 'E-mail'),
                            validator: (v) {
                              if (v == null || v.isEmpty) return 'Campo obrigatório';
                              if (!v.contains('@')) return 'E-mail inválido';
                              return null;
                            },
                          ),
                          const SizedBox(height: 16),
                          TextFormField(
                            controller: telefoneCtrl,
                            keyboardType: TextInputType.phone,
                            decoration: const InputDecoration(labelText: 'Telefone'),
                            validator: (v) => v!.isEmpty ? 'Campo obrigatório' : null,
                          ),
                          const SizedBox(height: 16),
                          CheckboxListTile(
                            title: const Text('Concordo com os termos e condições de uso'),
                            value: aceitarTermos,
                            onChanged: (v) => setState(() => aceitarTermos = v ?? false),
                          ),
                          const SizedBox(height: 16),
                          Center(
                            child: ElevatedButton(
                              style: ElevatedButton.styleFrom(
                                backgroundColor: const Color(0xFF222222),
                                foregroundColor: const Color(0xFFD9C66B),
                                padding: const EdgeInsets.symmetric(horizontal: 28, vertical: 12),
                                textStyle: const TextStyle(fontWeight: FontWeight.bold, fontSize: 16),
                              ),
                              onPressed: _enviar,
                              child: const Text('Enviar reserva'),
                            ),
                          ),
                          const SizedBox(height: 12),
                          if (mensagem != null)
                            Center(
                              child: Text(
                                mensagem!,
                                style: TextStyle(
                                  fontWeight: FontWeight.bold,
                                  color: sucesso ? const Color(0xFFD9C66B) : Colors.red,
                                ),
                              ),
                            ),
                        ],
                      ),
                    ),
                  ),
                ),
              ],
            ),
          ),
        ),
      ),
    );
  }

  Widget _radioEspaco(String valor) {
    return Row(
      mainAxisSize: MainAxisSize.min,
      children: [
        Radio<String>(
          value: valor,
          groupValue: _espacoSelecionado,
          activeColor: const Color(0xFFD9C66B),
          onChanged: (v) => setState(() => _espacoSelecionado = v),
        ),
        Text(valor),
      ],
    );
  }
}
