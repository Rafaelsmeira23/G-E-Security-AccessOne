import 'package:flutter/material.dart';

class ReservaResidencialPage extends StatefulWidget {
  const ReservaResidencialPage({super.key});

  @override
  State<ReservaResidencialPage> createState() => _ReservaResidencialPageState();
}

class _ReservaResidencialPageState extends State<ReservaResidencialPage> {
  final _formKey = GlobalKey<FormState>();

  final TextEditingController _dateController = TextEditingController();
  final TextEditingController _startTimeController = TextEditingController();
  final TextEditingController _endTimeController = TextEditingController();
  final TextEditingController _nameController = TextEditingController();
  final TextEditingController _emailController = TextEditingController();
  final TextEditingController _phoneController = TextEditingController();

  String? _selectedSpace;
  bool _acceptedTerms = false;
  String _message = '';
  Color _messageColor = Colors.transparent;

  final List<Map<String, dynamic>> _reservations = [];

  final List<String> _spaces = [
    "Salão de festas",
    "Churrasqueira",
    "Piscina",
    "Área pet",
    "Coworking",
    "Brinquedoteca",
    "Lavanderia",
    "Spa"
  ];

  void _addReservation(Map<String, dynamic> newRes) {
    setState(() {
      _reservations.insert(0, {
        ...newRes,
        "id": DateTime.now().millisecondsSinceEpoch,
      });
      _message = 'Reserva realizada com sucesso!';
      _messageColor = Colors.green.shade700;
    });
  }

  void _deleteReservation(int id) {
    setState(() {
      _reservations.removeWhere((r) => r['id'] == id);
      _message = 'Reserva removida.';
      _messageColor = Colors.red.shade700;
    });
  }

  void _submitForm() {
    setState(() => _message = '');

    if (!_formKey.currentState!.validate()) {
      setState(() {
        _message = 'Preencha todos os campos obrigatórios.';
        _messageColor = Colors.red.shade700;
      });
      return;
    }

    if (_selectedSpace == null) {
      setState(() {
        _message = 'Selecione um espaço.';
        _messageColor = Colors.red.shade700;
      });
      return;
    }

    if (!_acceptedTerms) {
      setState(() {
        _message = 'Aceite os termos e condições.';
        _messageColor = Colors.red.shade700;
      });
      return;
    }

    final start = _startTimeController.text;
    final end = _endTimeController.text;

    if (start.isNotEmpty && end.isNotEmpty) {
      final startParts = start.split(':').map(int.parse).toList();
      final endParts = end.split(':').map(int.parse).toList();

      final startMinutes = startParts[0] * 60 + startParts[1];
      final endMinutes = endParts[0] * 60 + endParts[1];

      if (endMinutes <= startMinutes) {
        setState(() {
          _message =
              'O horário final deve ser maior que o inicial (mesmo dia).';
          _messageColor = Colors.red.shade700;
        });
        return;
      }

      if (endMinutes > (24 * 60) - 1) {
        setState(() {
          _message = 'A reserva não pode ultrapassar 23:59 do mesmo dia.';
          _messageColor = Colors.red.shade700;
        });
        return;
      }
    }

    final newRes = {
      "space": _selectedSpace!,
      "date": _dateController.text,
      "start": _startTimeController.text,
      "end": _endTimeController.text,
      "name": _nameController.text,
      "email": _emailController.text,
      "phone": _phoneController.text,
    };

    _addReservation(newRes);
    _formKey.currentState!.reset();
    _selectedSpace = null;
    _acceptedTerms = false;
    _dateController.clear();
    _startTimeController.clear();
    _endTimeController.clear();
    _nameController.clear();
    _emailController.clear();
    _phoneController.clear();
  }

  InputDecoration _decoration(String label) => InputDecoration(
        labelText: label,
        border: const OutlineInputBorder(),
        labelStyle: const TextStyle(color: Colors.black),
      );

  // 🔹 Função de logout com confirmação
  void _logout() {
    showDialog(
      context: context,
      builder: (context) => AlertDialog(
        title: const Text('Sair'),
        content: const Text('Tem certeza de que deseja sair do sistema?'),
        actions: [
          TextButton(
            onPressed: () => Navigator.pop(context),
            child: const Text('Cancelar'),
          ),
          TextButton(
            onPressed: () {
              Navigator.pop(context);
              Navigator.pushReplacementNamed(context, '/login');
            },
            child: const Text(
              'Sair',
              style: TextStyle(color: Colors.red),
            ),
          ),
        ],
      ),
    );
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      backgroundColor: const Color(0xFFFDFDFB),
      appBar: AppBar(
        title: const Text(
          'Reserva - Condomínio Residencial',
          style: TextStyle(fontWeight: FontWeight.bold),
        ),
        centerTitle: true,
        backgroundColor: Colors.black,
        foregroundColor: const Color(0xFFD9C66B),
        leading: IconButton(
          icon: const Icon(Icons.arrow_back),
          onPressed: () => Navigator.pop(context),
        ),
        actions: [
          IconButton(
            icon: const Icon(Icons.logout),
            tooltip: 'Sair',
            onPressed: _logout,
          ),
        ],
      ),
      body: SingleChildScrollView(
        padding: const EdgeInsets.all(16),
        child: Column(
          children: [
            Form(
              key: _formKey,
              child: Column(
                crossAxisAlignment: CrossAxisAlignment.start,
                children: [
                  const Text(
                    'Selecione o espaço:',
                    style: TextStyle(
                        fontWeight: FontWeight.bold,
                        fontSize: 16,
                        color: Colors.black),
                  ),
                  const SizedBox(height: 8),
                  Wrap(
                    spacing: 8,
                    children: _spaces
                        .map(
                          (space) => ChoiceChip(
                            label: Text(space),
                            selectedColor: const Color(0xFFD9C66B),
                            labelStyle: TextStyle(
                              color: _selectedSpace == space
                                  ? Colors.black
                                  : Colors.grey[800],
                              fontWeight: _selectedSpace == space
                                  ? FontWeight.bold
                                  : FontWeight.normal,
                            ),
                            selected: _selectedSpace == space,
                            onSelected: (_) {
                              setState(() => _selectedSpace = space);
                            },
                          ),
                        )
                        .toList(),
                  ),
                  const SizedBox(height: 20),
                  // Campos de data e hora
                  TextFormField(
                    controller: _dateController,
                    decoration: _decoration('Data'),
                    readOnly: true,
                    validator: (v) =>
                        v == null || v.isEmpty ? 'Escolha uma data' : null,
                    onTap: () async {
                      final picked = await showDatePicker(
                        context: context,
                        firstDate: DateTime.now(),
                        lastDate: DateTime(2100),
                        initialDate: DateTime.now(),
                      );
                      if (picked != null) {
                        _dateController.text =
                            "${picked.day.toString().padLeft(2, '0')}/${picked.month.toString().padLeft(2, '0')}/${picked.year}";
                      }
                    },
                  ),
                  const SizedBox(height: 16),
                  Row(
                    children: [
                      Expanded(
                        child: TextFormField(
                          controller: _startTimeController,
                          decoration: _decoration('Início'),
                          readOnly: true,
                          validator: (v) => v == null || v.isEmpty
                              ? 'Informe o horário inicial'
                              : null,
                          onTap: () async {
                            final picked = await showTimePicker(
                              context: context,
                              initialTime: TimeOfDay.now(),
                            );
                            if (picked != null) {
                              _startTimeController.text =
                                  "${picked.hour.toString().padLeft(2, '0')}:${picked.minute.toString().padLeft(2, '0')}";
                            }
                          },
                        ),
                      ),
                      const SizedBox(width: 12),
                      Expanded(
                        child: TextFormField(
                          controller: _endTimeController,
                          decoration: _decoration('Término'),
                          readOnly: true,
                          validator: (v) => v == null || v.isEmpty
                              ? 'Informe o horário final'
                              : null,
                          onTap: () async {
                            final picked = await showTimePicker(
                              context: context,
                              initialTime: TimeOfDay.now(),
                            );
                            if (picked != null) {
                              _endTimeController.text =
                                  "${picked.hour.toString().padLeft(2, '0')}:${picked.minute.toString().padLeft(2, '0')}";
                            }
                          },
                        ),
                      ),
                    ],
                  ),
                  const SizedBox(height: 16),
                  TextFormField(
                    controller: _nameController,
                    decoration: _decoration('Nome completo'),
                    validator: (v) =>
                        v == null || v.isEmpty ? 'Digite seu nome' : null,
                  ),
                  const SizedBox(height: 16),
                  TextFormField(
                    controller: _emailController,
                    decoration: _decoration('E-mail'),
                    validator: (v) =>
                        v != null && v.contains('@') ? null : 'E-mail inválido',
                  ),
                  const SizedBox(height: 16),
                  TextFormField(
                    controller: _phoneController,
                    decoration: _decoration('Telefone')
                        .copyWith(hintText: '(00) 00000-0000'),
                    keyboardType: TextInputType.phone,
                    validator: (v) {
                      if (v == null || v.isEmpty) return 'Digite seu telefone';
                      final phoneRegex = RegExp(r'^\(\d{2}\)\s?\d{4,5}-\d{4}$');
                      if (!phoneRegex.hasMatch(v)) {
                        return 'Formato inválido. Use (00) 00000-0000';
                      }
                      return null;
                    },
                  ),
                  const SizedBox(height: 16),
                  Row(
                    children: [
                      Checkbox(
                        value: _acceptedTerms,
                        onChanged: (v) {
                          setState(() => _acceptedTerms = v ?? false);
                        },
                      ),
                      const Expanded(
                        child: Text('Concordo com os termos e condições'),
                      ),
                    ],
                  ),
                  const SizedBox(height: 10),
                  Center(
                    child: ElevatedButton(
                      onPressed: _submitForm,
                      style: ElevatedButton.styleFrom(
                        backgroundColor: Colors.black,
                        foregroundColor: const Color(0xFFD9C66B),
                        padding: const EdgeInsets.symmetric(
                          horizontal: 28,
                          vertical: 14,
                        ),
                      ),
                      child: const Text(
                        'Enviar reserva',
                        style: TextStyle(
                          fontSize: 16,
                          fontWeight: FontWeight.bold,
                        ),
                      ),
                    ),
                  ),
                  const SizedBox(height: 16),
                  Center(
                    child: Text(
                      _message,
                      style: TextStyle(
                        color: _messageColor,
                        fontWeight: FontWeight.bold,
                        fontSize: 16,
                      ),
                    ),
                  ),
                  const Divider(thickness: 1.5, height: 30),
                  const Text(
                    'Reservas realizadas:',
                    style: TextStyle(
                        fontWeight: FontWeight.bold,
                        fontSize: 18,
                        color: Colors.black),
                  ),
                ],
              ),
            ),
            if (_reservations.isEmpty)
              const Padding(
                padding: EdgeInsets.only(top: 10),
                child: Text(
                  'Nenhuma reserva realizada ainda.',
                  style: TextStyle(fontSize: 16, color: Colors.grey),
                ),
              )
            else
              ListView.builder(
                shrinkWrap: true,
                physics: const NeverScrollableScrollPhysics(),
                itemCount: _reservations.length,
                itemBuilder: (_, index) {
                  final res = _reservations[index];
                  return Card(
                    color: const Color(0xFFD9C66B).withOpacity(0.25),
                    margin: const EdgeInsets.symmetric(vertical: 6),
                    child: ListTile(
                      title: Text(
                        res['space'],
                        style: const TextStyle(fontWeight: FontWeight.bold),
                      ),
                      subtitle: Text(
                        '${res['date']} | ${res['start']} - ${res['end']}\n${res['name']} • ${res['phone']}',
                      ),
                      isThreeLine: true,
                      trailing: IconButton(
                        icon: const Icon(Icons.delete, color: Colors.red),
                        onPressed: () => _deleteReservation(res['id']),
                      ),
                    ),
                  );
                },
              ),
          ],
        ),
      ),
    );
  }
}
