import 'package:flutter/material.dart';

// Import das páginas
import 'pages/login_page.dart';
import 'pages/home_page.dart';
import 'pages/reserva_comercial_page.dart';
import 'pages/reserva_residencial_page.dart';

// Dashboards (arquivos que você mostrou na pasta)
import 'pages/residencial_dashboard_page.dart';
import 'pages/comercial_dashboard_page.dart';

void main() {
  runApp(const GESecurityApp());
}

class GESecurityApp extends StatelessWidget {
  const GESecurityApp({super.key});

  @override
  Widget build(BuildContext context) {
    return MaterialApp(
      debugShowCheckedModeBanner: false,
      title: 'AccessOne | G&E Security',
      theme: ThemeData(
        brightness: Brightness.dark,
        scaffoldBackgroundColor: const Color(0xFF121212),
        colorScheme: const ColorScheme(
          brightness: Brightness.dark,
          primary: Color(0xFFD4AF37), // dourado metálico
          onPrimary: Colors.black,
          secondary: Color(0xFFBDBDBD),
          onSecondary: Colors.black,
          error: Colors.redAccent,
          onError: Colors.white,
          background: Color(0xFF1C1C1C),
          onBackground: Colors.white,
          surface: Color(0xFF2C2C2C),
          onSurface: Colors.white,
        ),
        appBarTheme: const AppBarTheme(
          backgroundColor: Color(0xFF1C1C1C),
          titleTextStyle: TextStyle(
            color: Color(0xFFD4AF37),
            fontWeight: FontWeight.bold,
            fontSize: 20,
          ),
          iconTheme: IconThemeData(color: Color(0xFFD4AF37)),
        ),
        floatingActionButtonTheme: const FloatingActionButtonThemeData(
          backgroundColor: Color(0xFFD4AF37),
          foregroundColor: Colors.black,
        ),
        textTheme: const TextTheme(
          bodyLarge: TextStyle(color: Color(0xFFE0E0E0)),
          bodyMedium: TextStyle(color: Color(0xFFBDBDBD)),
          titleLarge: TextStyle(
            color: Color(0xFFD4AF37),
            fontWeight: FontWeight.bold,
            fontSize: 22,
          ),
        ),
      ),

      // Página inicial (abre no login)
      initialRoute: '/login',

      // Rotas nomeadas
      routes: {
        '/login': (context) => const LoginPage(),
        '/': (context) => const HomePage(),

        // Reservas
        '/reserva_residencial': (context) => const ReservaResidencialPage(),
        '/reserva_comercial': (context) => const ReservaComercialPage(),

        // Dashboards (ajustados para os nomes dos arquivos que você mostrou)
        // IMPORTANTE: confirme que as classes abaixo realmente se chamam
        // ResidencialDashboardPage e ComercialDashboardPage dentro dos arquivos.
        // Se as classes tiverem outro nome, troque aqui pelo nome correto.
        '/dashboard_morador': (context) => const  MoradorDashboardPage(),
        '/dashboard_comercial': (context) => const ComercialDashboardPage(),
      },
    );
  }
}