import 'package:flutter/material.dart';

class LoginPage extends StatefulWidget {
  const LoginPage({super.key});

  @override
  State<LoginPage> createState() => _LoginPageState();
}

class _LoginPageState extends State<LoginPage> {
  final _emailController = TextEditingController();
  final _senhaController = TextEditingController();
  bool _mostrarSenha = false;
  String? _erroLogin;

  void _fazerLogin() {
    final email = _emailController.text.trim().toLowerCase();
    final senha = _senhaController.text.trim();

    setState(() => _erroLogin = null);

    if (email.isEmpty || senha.isEmpty) {
      setState(() => _erroLogin = 'Preencha e-mail e senha.');
      return;
    }

    if (email == 'morador@gmail.com' && senha == '123456') {
      Navigator.pushReplacementNamed(context, '/dashboard_morador');
    } else if (email == 'comercial@gmail.com' && senha == '123456') {
      Navigator.pushReplacementNamed(context, '/dashboard_comercial');
    } else if (email == 'admin@gmail.com' && senha == 's3nh4Adm1N') {
      Navigator.pushReplacementNamed(context, '/');
    } else {
      setState(() => _erroLogin = 'Usuário ou senha incorretos.');
    }
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      backgroundColor: Colors.black,
      body: Center(
        child: Padding(
          padding: const EdgeInsets.all(32.0),
          child: SingleChildScrollView(
            child: Column(
              mainAxisAlignment: MainAxisAlignment.center,
              children: [
                // --- LOGO ACCESSONE ---
                Image.asset(
                  'lib/images/logo_accessone2.png',
                  height: 170,
                  fit: BoxFit.contain,
                ),
                const SizedBox(height: 25),

                const Text(
                  'AccessOne',
                  style: TextStyle(
                    color: Color(0xFFFFD700),
                    fontSize: 30, // um pouquinho maior
                    fontWeight: FontWeight.bold,
                  ),
                ),
                const SizedBox(height: 45),

                // --- CAMPO E-MAIL ---
                TextField(
                  controller: _emailController,
                  keyboardType: TextInputType.emailAddress,
                  style: const TextStyle(color: Colors.white),
                  decoration: InputDecoration(
                    labelText: 'E-mail',
                    labelStyle: const TextStyle(color: Color(0xFFFFD700)),
                    enabledBorder: OutlineInputBorder(
                      borderSide: const BorderSide(color: Color(0xFFFFD700)),
                      borderRadius: BorderRadius.circular(12),
                    ),
                    focusedBorder: OutlineInputBorder(
                      borderSide: const BorderSide(
                        color: Color(0xFFFFD700),
                        width: 2,
                      ),
                      borderRadius: BorderRadius.circular(12),
                    ),
                    prefixIcon: const Icon(
                      Icons.email,
                      color: Color(0xFFFFD700),
                    ),
                  ),
                ),
                const SizedBox(height: 20),

                // --- CAMPO SENHA ---
                TextField(
                  controller: _senhaController,
                  obscureText: !_mostrarSenha,
                  style: const TextStyle(color: Colors.white),
                  decoration: InputDecoration(
                    labelText: 'Senha',
                    labelStyle: const TextStyle(color: Color(0xFFFFD700)),
                    enabledBorder: OutlineInputBorder(
                      borderSide: const BorderSide(color: Color(0xFFFFD700)),
                      borderRadius: BorderRadius.circular(12),
                    ),
                    focusedBorder: OutlineInputBorder(
                      borderSide: const BorderSide(
                        color: Color(0xFFFFD700),
                        width: 2,
                      ),
                      borderRadius: BorderRadius.circular(12),
                    ),
                    prefixIcon: const Icon(
                      Icons.lock,
                      color: Color(0xFFFFD700),
                    ),
                    suffixIcon: IconButton(
                      icon: Icon(
                        _mostrarSenha ? Icons.visibility_off : Icons.visibility,
                        color: const Color(0xFFFFD700),
                      ),
                      onPressed: () {
                        setState(() => _mostrarSenha = !_mostrarSenha);
                      },
                    ),
                  ),
                ),
                const SizedBox(height: 20),

                if (_erroLogin != null)
                  Text(
                    _erroLogin!,
                    style: const TextStyle(
                      color: Colors.redAccent,
                      fontSize: 14,
                    ),
                  ),

                const SizedBox(height: 30),

                // --- BOTÃO LOGIN ---
                SizedBox(
                  width: double.infinity,
                  height: 50,
                  child: ElevatedButton(
                    style: ElevatedButton.styleFrom(
                      backgroundColor: const Color(0xFFFFD700),
                      foregroundColor: Colors.black,
                      shape: RoundedRectangleBorder(
                        borderRadius: BorderRadius.circular(12),
                      ),
                    ),
                    onPressed: _fazerLogin,
                    child: const Text(
                      'ENTRAR',
                      style: TextStyle(
                        fontWeight: FontWeight.bold,
                        fontSize: 18,
                      ),
                    ),
                  ),
                ),

                const SizedBox(height: 40),

                // --- POWERED BY G&E SECURITY ---
                Column(
                  children: [
                    const Text(
                      'Powered by',
                      style: TextStyle(
                        color: Colors.white70,
                        fontSize: 15,
                        fontStyle: FontStyle.italic,
                      ),
                    ),
                    const SizedBox(height: 8),
                    Image.asset(
                      'lib/images/logo_ge_security.png',
                      height: 100,
                      fit: BoxFit.contain,
                      opacity: const AlwaysStoppedAnimation(0.9),
                    ),
                  ],
                ),
              ],
            ),
          ),
        ),
      ),
    );
  }
}
