import 'package:flutter/material.dart';

class ReservaResidencialPage extends StatefulWidget {
  const ReservaResidencialPage({super.key});

  @override
  State<ReservaResidencialPage> createState() => _ReservaResidencialPageState();
}

class _ReservaResidencialPageState extends State<ReservaResidencialPage> {
  final _formKey = GlobalKey<FormState>();

  final TextEditingController _dateController = TextEditingController();
  final TextEditingController _startTimeController = TextEditingController();
  final TextEditingController _endTimeController = TextEditingController();
  final TextEditingController _nameController = TextEditingController();
  final TextEditingController _emailController = TextEditingController();
  final TextEditingController _phoneController = TextEditingController();

  String? _selectedSpace;
  bool _acceptedTerms = false;
  String _message = '';
  Color _messageColor = Colors.transparent;

  final List<Map<String, dynamic>> _reservations = [];

  final List<String> _spaces = [
    "Salão de festas",
    "Churrasqueira",
    "Piscina",
    "Área pet",
    "Coworking",
    "Brinquedoteca",
    "Lavanderia",
    "Spa",
  ];

  void _addReservation(Map<String, dynamic> newRes) {
    setState(() {
      _reservations.insert(0, {
        ...newRes,
        "id": DateTime.now().millisecondsSinceEpoch,
      });
      _message = 'Reserva realizada com sucesso!';
      _messageColor = Colors.green.shade700;
    });
  }

  void _deleteReservation(int id) {
    setState(() {
      _reservations.removeWhere((r) => r['id'] == id);
      _message = 'Reserva removida.';
      _messageColor = Colors.red.shade700;
    });
  }

  void _submitForm() {
    setState(() => _message = '');

    if (!_formKey.currentState!.validate()) {
      setState(() {
        _message = 'Preencha todos os campos obrigatórios.';
        _messageColor = Colors.red.shade700;
      });
      return;
    }

    if (_selectedSpace == null) {
      setState(() {
        _message = 'Selecione um espaço.';
        _messageColor = Colors.red.shade700;
      });
      return;
    }

    if (!_acceptedTerms) {
      setState(() {
        _message = 'Aceite os termos e condições.';
        _messageColor = Colors.red.shade700;
      });
      return;
    }

    final start = _startTimeController.text;
    final end = _endTimeController.text;

    if (start.isNotEmpty && end.isNotEmpty) {
      final startParts = start.split(':').map(int.parse).toList();
      final endParts = end.split(':').map(int.parse).toList();

      final startMinutes = startParts[0] * 60 + startParts[1];
      final endMinutes = endParts[0] * 60 + endParts[1];

      if (endMinutes <= startMinutes) {
        setState(() {
          _message =
              'O horário final deve ser maior que o inicial (mesmo dia).';
          _messageColor = Colors.red.shade700;
        });
        return;
      }

      if (endMinutes > (24 * 60) - 1) {
        setState(() {
          _message = 'A reserva não pode ultrapassar 23:59 do mesmo dia.';
          _messageColor = Colors.red.shade700;
        });
        return;
      }
    }

    final newRes = {
      "space": _selectedSpace!,
      "date": _dateController.text,
      "start": _startTimeController.text,
      "end": _endTimeController.text,
      "name": _nameController.text,
      "email": _emailController.text,
      "phone": _phoneController.text,
    };

    _addReservation(newRes);

    _formKey.currentState!.reset();
    _selectedSpace = null;
    _acceptedTerms = false;
    _dateController.clear();
    _startTimeController.clear();
    _endTimeController.clear();
    _nameController.clear();
    _emailController.clear();
    _phoneController.clear();
  }

  // DECORAÇÃO PADRÃO PARA TODOS OS CAMPOS (fundo + bordas + label/hint escuros)
  InputDecoration _dec(String label, {String? hint}) => InputDecoration(
    labelText: label,
    hintText: hint,
    filled: true,
    // fillColor do campo inteiro (fundo)
    fillColor: const Color(0xFFF1F2F4), // fundo cinza claro e legível
    border: const OutlineInputBorder(),
    enabledBorder: OutlineInputBorder(
      borderSide: BorderSide(color: Colors.black26),
      borderRadius: BorderRadius.circular(4),
    ),
    focusedBorder: OutlineInputBorder(
      borderSide: BorderSide(color: Colors.black54, width: 1.2),
      borderRadius: BorderRadius.circular(4),
    ),
    labelStyle: const TextStyle(color: Colors.black87),
    hintStyle: const TextStyle(color: Colors.black54),
    contentPadding: const EdgeInsets.symmetric(
      vertical: 14.0,
      horizontal: 12.0,
    ),
  );

  void _logout() {
    showDialog(
      context: context,
      builder:
          (context) => AlertDialog(
            title: const Text('Sair'),
            content: const Text('Tem certeza de que deseja sair do sistema?'),
            actions: [
              TextButton(
                onPressed: () => Navigator.pop(context),
                child: const Text('Cancelar'),
              ),
              TextButton(
                onPressed: () {
                  Navigator.pop(context);
                  Navigator.pushReplacementNamed(context, '/login');
                },
                child: const Text('Sair', style: TextStyle(color: Colors.red)),
              ),
            ],
          ),
    );
  }

  @override
  Widget build(BuildContext context) {
    // Para garantir checkbox com cor consistente:
    final checkboxFill = MaterialStateProperty.resolveWith<Color?>((states) {
      if (states.contains(MaterialState.selected)) return Colors.black;
      return Colors.black26; // cor da caixa quando não marcada
    });

    return Scaffold(
      backgroundColor: const Color(0xFFFDFDFB),
      appBar: AppBar(
        title: const Text(
          'Reserva - Condomínio Residencial',
          style: TextStyle(fontWeight: FontWeight.bold),
        ),
        centerTitle: true,
        backgroundColor: Colors.black,
        foregroundColor: const Color(0xFFD9C66B),
        leading: IconButton(
          icon: const Icon(Icons.arrow_back),
          onPressed: () => Navigator.pop(context),
        ),
        actions: [
          IconButton(
            icon: const Icon(Icons.logout),
            tooltip: 'Sair',
            onPressed: _logout,
          ),
        ],
      ),

      body: SingleChildScrollView(
        padding: const EdgeInsets.all(16),
        child: Column(
          children: [
            Form(
              key: _formKey,
              child: Column(
                crossAxisAlignment: CrossAxisAlignment.start,
                children: [
                  const Text(
                    'Selecione o espaço:',
                    style: TextStyle(
                      fontWeight: FontWeight.bold,
                      fontSize: 16,
                      color: Colors.black,
                    ),
                  ),
                  const SizedBox(height: 8),

                  Wrap(
                    spacing: 8,
                    children:
                        _spaces
                            .map(
                              (space) => ChoiceChip(
                                label: Text(space),
                                labelStyle: TextStyle(
                                  color:
                                      _selectedSpace == space
                                          ? Colors.black
                                          : Colors.white,
                                ),
                                backgroundColor: Colors.black,
                                selectedColor: const Color(0xFFD9C66B),
                                selected: _selectedSpace == space,
                                onSelected: (_) {
                                  setState(() => _selectedSpace = space);
                                },
                              ),
                            )
                            .toList(),
                  ),

                  const SizedBox(height: 20),

                  // DATA
                  TextFormField(
                    controller: _dateController,
                    style: const TextStyle(color: Colors.black87),
                    cursorColor: Colors.black87,
                    decoration: _dec('Data'),
                    readOnly: true,
                    validator:
                        (v) =>
                            v == null || v.isEmpty ? 'Escolha uma data' : null,
                    onTap: () async {
                      final picked = await showDatePicker(
                        context: context,
                        firstDate: DateTime.now(),
                        lastDate: DateTime(2100),
                        initialDate: DateTime.now(),
                      );
                      if (picked != null) {
                        _dateController.text =
                            "${picked.day.toString().padLeft(2, '0')}/${picked.month.toString().padLeft(2, '0')}/${picked.year}";
                      }
                    },
                  ),

                  const SizedBox(height: 16),

                  // HORÁRIOS
                  Row(
                    children: [
                      Expanded(
                        child: TextFormField(
                          controller: _startTimeController,
                          style: const TextStyle(color: Colors.black87),
                          cursorColor: Colors.black87,
                          decoration: _dec('Início'),
                          readOnly: true,
                          validator:
                              (v) =>
                                  v == null || v.isEmpty
                                      ? 'Informe o início'
                                      : null,
                          onTap: () async {
                            final picked = await showTimePicker(
                              context: context,
                              initialTime: TimeOfDay.now(),
                            );
                            if (picked != null) {
                              _startTimeController.text =
                                  "${picked.hour.toString().padLeft(2, '0')}:${picked.minute.toString().padLeft(2, '0')}";
                            }
                          },
                        ),
                      ),

                      const SizedBox(width: 12),

                      Expanded(
                        child: TextFormField(
                          controller: _endTimeController,
                          style: const TextStyle(
                            color: Colors.black87,
                            fontSize: 15,
                          ),
                          cursorColor: Colors.black87,
                          decoration: _dec('Término'),
                          readOnly: true,
                          validator:
                              (v) =>
                                  v == null || v.isEmpty
                                      ? 'Informe o término'
                                      : null,
                          onTap: () async {
                            final picked = await showTimePicker(
                              context: context,
                              initialTime: TimeOfDay.now(),
                            );
                            if (picked != null) {
                              _endTimeController.text =
                                  "${picked.hour.toString().padLeft(2, '0')}:${picked.minute.toString().padLeft(2, '0')}";
                            }
                          },
                        ),
                      ),
                    ],
                  ),

                  const SizedBox(height: 16),

                  // NOME
                  TextFormField(
                    controller: _nameController,
                    style: const TextStyle(color: Colors.black87),
                    cursorColor: Colors.black87,
                    decoration: _dec('Nome completo'),
                    validator:
                        (v) =>
                            v == null || v.isEmpty ? 'Digite seu nome' : null,
                  ),

                  const SizedBox(height: 16),

                  // EMAIL
                  TextFormField(
                    controller: _emailController,
                    style: const TextStyle(color: Colors.black87),
                    cursorColor: Colors.black87,
                    decoration: _dec('E-mail'),
                    validator:
                        (v) =>
                            v != null && v.contains('@')
                                ? null
                                : 'E-mail inválido',
                  ),

                  const SizedBox(height: 16),

                  // TELEFONE
                  TextFormField(
                    controller: _phoneController,
                    style: const TextStyle(color: Colors.black87),
                    cursorColor: Colors.black87,
                    decoration: _dec('Telefone', hint: '(00) 00000-0000'),
                    keyboardType: TextInputType.phone,
                    validator: (v) {
                      if (v == null || v.isEmpty) return 'Digite seu telefone';
                      final phoneRegex = RegExp(r'^\(\d{2}\)\s?\d{4,5}-\d{4}$');
                      if (!phoneRegex.hasMatch(v)) {
                        return 'Formato inválido. Use (00) 00000-0000';
                      }
                      return null;
                    },
                  ),

                  const SizedBox(height: 16),

                  // CHECKBOX COM COR DO BACKGROUND MAIS ESCURA
                  Row(
                    children: [
                      Checkbox(
                        value: _acceptedTerms,
                        onChanged:
                            (v) => setState(() => _acceptedTerms = v ?? false),
                        checkColor: Colors.white,
                        // preenche a caixa; quando marcada fica preta, quando não marcada fica cinza escuro
                        fillColor: checkboxFill,
                      ),
                      const Expanded(
                        child: Text(
                          'Concordo com os termos e condições',
                          style: TextStyle(color: Colors.black87),
                        ),
                      ),
                    ],
                  ),

                  const SizedBox(height: 10),

                  Center(
                    child: ElevatedButton(
                      onPressed: _submitForm,
                      style: ElevatedButton.styleFrom(
                        backgroundColor: Colors.black,
                        foregroundColor: Colors.white,
                        padding: const EdgeInsets.symmetric(
                          horizontal: 28,
                          vertical: 14,
                        ),
                      ),
                      child: const Text(
                        'Enviar reserva',
                        style: TextStyle(
                          fontSize: 16,
                          fontWeight: FontWeight.bold,
                        ),
                      ),
                    ),
                  ),

                  const SizedBox(height: 16),

                  Center(
                    child: Text(
                      _message,
                      style: TextStyle(
                        color: _messageColor,
                        fontWeight: FontWeight.bold,
                        fontSize: 16,
                      ),
                    ),
                  ),

                  const Divider(thickness: 1.5, height: 30),

                  const Text(
                    'Reservas realizadas:',
                    style: TextStyle(
                      fontWeight: FontWeight.bold,
                      fontSize: 18,
                      color: Colors.black,
                    ),
                  ),
                ],
              ),
            ),

            if (_reservations.isEmpty)
              const Padding(
                padding: EdgeInsets.only(top: 10),
                child: Text(
                  'Nenhuma reserva realizada ainda.',
                  style: TextStyle(
                    fontSize: 16,
                    color: Color.fromARGB(255, 63, 63, 63),
                  ),
                ),
              )
            else
              ListView.builder(
                shrinkWrap: true,
                physics: const NeverScrollableScrollPhysics(),
                itemCount: _reservations.length,
                itemBuilder: (_, index) {
                  final res = _reservations[index];
                  return Card(
                    elevation: 0,
                    color: Colors.white,
                    shape: RoundedRectangleBorder(
                      borderRadius: BorderRadius.circular(8),
                      side: const BorderSide(
                        color: Color(0xFFD9C66B), // borda dourada
                        width: 1.4,
                      ),
                    ),
                    margin: const EdgeInsets.symmetric(vertical: 8),
                    child: Padding(
                      padding: const EdgeInsets.all(12),
                      child: Column(
                        crossAxisAlignment: CrossAxisAlignment.start,
                        children: [
                          Text(
                            res['space'],
                            style: const TextStyle(
                              fontWeight: FontWeight.bold,
                              fontSize: 16,
                              color: Colors.black,
                            ),
                          ),

                          const SizedBox(height: 6),

                          Text(
                            '${res['date']} | ${res['start']} - ${res['end']}',
                            style: const TextStyle(
                              color: Colors.black87,
                              fontSize: 14,
                            ),
                          ),

                          const SizedBox(height: 4),

                          Text(
                            '${res['name']} • ${res['phone']}',
                            style: const TextStyle(
                              color: Colors.black87,
                              fontSize: 14,
                            ),
                          ),

                          const SizedBox(height: 4),

                          Text(
                              res['email'] ?? '',
                            style: const TextStyle(
                              color: Colors.black87,
                              fontSize: 14,
                            ),
                          ),

                          const SizedBox(height: 8),

                          Align(
                            alignment: Alignment.centerRight,
                            child: IconButton(
                              icon: const Icon(Icons.delete, color: Colors.red),
                              onPressed: () => _deleteReservation(res['id']),
                            ),
                          ),
                        ],
                      ),
                    ),
                  );
                }
              ),
            ],
          ),
        ),
      );
    }
  }
