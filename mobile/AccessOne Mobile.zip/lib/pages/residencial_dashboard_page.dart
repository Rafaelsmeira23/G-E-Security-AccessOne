import 'package:flutter/material.dart';

class MoradorDashboardPage extends StatelessWidget {
  const MoradorDashboardPage({super.key});

  // Paleta fixa
  static const Color gold = Color(0xFFD4AF37);
  static const Color silver = Color(0xFFC0C0C0);
  static const Color silverBackground = Color(0xFFF4F4F4);
  static const Color black = Colors.black;

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      backgroundColor: silverBackground,
      appBar: AppBar(
        title: const Text(
          'Painel do Morador',
          style: TextStyle(
            fontWeight: FontWeight.w600,
            color: gold,
          ),
        ),
        backgroundColor: black,
        iconTheme: const IconThemeData(color: gold),
        foregroundColor: gold,
        centerTitle: true,
        elevation: 4,
        actions: [
          IconButton(
            icon: const Icon(Icons.logout),
            tooltip: 'Sair',
            onPressed: () {
              Navigator.pushReplacementNamed(context, '/login');
            },
          ),
        ],
      ),
      body: Padding(
        padding: const EdgeInsets.all(24.0),
        child: Center(
          child: Column(
            mainAxisAlignment: MainAxisAlignment.center,
            children: [
              const Text(
                'Escolha uma ação:',
                style: TextStyle(
                  fontSize: 22,
                  fontWeight: FontWeight.bold,
                  color: black,
                ),
              ),
              const SizedBox(height: 40),

              _buildMainButton(
                context,
                icon: Icons.event_available_rounded,
                title: 'Solicitar Reserva',
                subtitle: 'Agende espaços comuns do condomínio.',
                route: '/reserva_residencial',
              ),
              const SizedBox(height: 25),

              _buildMainButton(
                context,
                icon: Icons.support_agent_rounded,
                title: 'Abrir Chamado',
                subtitle: 'Informe problemas ou solicitações ao síndico.',
                route: '/abrir_chamado',
              ),
              const SizedBox(height: 25),

              _buildMainButton(
                context,
                icon: Icons.notifications_active_rounded,
                title: 'Notificações de Encomendas',
                subtitle: 'Visualize entregas e avisos da portaria.',
                route: '/encomendas_residencial',
              ),

              const SizedBox(height: 50),
              Text(
                'AccessOne • Sistema Integrado de Portaria e Estacionamento',
                textAlign: TextAlign.center,
                style: TextStyle(
                  color: Colors.grey.shade700,
                  fontSize: 13,
                ),
              ),
            ],
          ),
        ),
      ),
    );
  }

  Widget _buildMainButton(
    BuildContext context, {
    required IconData icon,
    required String title,
    required String subtitle,
    required String route,
  }) {
    return InkWell(
      onTap: () => Navigator.pushNamed(context, route),
      borderRadius: BorderRadius.circular(16),
      child: Ink(
        decoration: BoxDecoration(
          color: Colors.white,
          borderRadius: BorderRadius.circular(16),
          border: Border.all(color: silver, width: 1.2),
          boxShadow: [
            BoxShadow(
              color: Colors.black12,
              blurRadius: 8,
              offset: const Offset(0, 3),
            ),
          ],
        ),
        child: Padding(
          padding: const EdgeInsets.symmetric(vertical: 20, horizontal: 18),
          child: Row(
            children: [
              CircleAvatar(
                radius: 28,
                backgroundColor: gold.withOpacity(0.18),
                child: const Icon(Icons.star, size: 34, color: gold),
              ),
              const SizedBox(width: 18),
              Expanded(
                child: Column(
                  crossAxisAlignment: CrossAxisAlignment.start,
                  children: [
                    Text(
                      title,
                      style: const TextStyle(
                        fontSize: 18,
                        fontWeight: FontWeight.w600,
                        color: black,
                      ),
                    ),
                    const SizedBox(height: 5),
                    Text(
                      subtitle,
                      style: TextStyle(color: Colors.grey.shade600),
                    ),
                  ],
                ),
              ),
              const Icon(
                Icons.arrow_forward_ios_rounded,
                color: black,
                size: 18,
              ),
            ],
          ),
        ),
      ),
    );
  }
}
