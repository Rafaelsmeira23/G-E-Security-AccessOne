import 'package:flutter/material.dart';

class EncomendasComercialPage extends StatelessWidget {
  const EncomendasComercialPage({super.key});

  @override
  Widget build(BuildContext context) {
    // Demo data (substitua por dados reais vindo do backend)
    const destinatario = 'Ricardo Fagundes Moreira';
    const sala = 'Sala 608';
    const descricao = 'Um pacote amarelo';
    const transportadora = 'Loggi';
    const codigo = 'CAE-16375012-1';
    const recebidoPor = 'Miguel';

    return Scaffold(
      appBar: AppBar(
        title: const Text('Encomendas - Comercial'),
        backgroundColor: Colors.black,
        foregroundColor: Color(0xFFD4AF37),
        centerTitle: true,
      ),
      backgroundColor: const Color(0xFFF4F6F8),
      body: SingleChildScrollView(
        padding: const EdgeInsets.all(16),
        child: Column(
          children: [
            Card(
              shape: RoundedRectangleBorder(
                side: const BorderSide(color: Color(0xFFD4AF37), width: 1.4),
                borderRadius: BorderRadius.circular(12),
              ),
              elevation: 4,
              color: Colors.white,
              child: Padding(
                padding: const EdgeInsets.all(14),
                child: Row(
                  crossAxisAlignment: CrossAxisAlignment.start,
                  children: [
                    Expanded(
                      child: Column(
                        crossAxisAlignment: CrossAxisAlignment.start,
                        children: [
                          Text('Destinatário',
                              style: TextStyle(
                                  color: Colors.grey.shade700,
                                  fontWeight: FontWeight.w600)),
                          const SizedBox(height: 6),
                          Text(destinatario,
                              style: const TextStyle(
                                  color: Colors.black,
                                  fontSize: 16,
                                  fontWeight: FontWeight.bold)),

                          const SizedBox(height: 10),
                          Text('Local',
                              style: TextStyle(
                                  color: Colors.grey.shade700,
                                  fontWeight: FontWeight.w600)),
                          const SizedBox(height: 6),
                          Text(sala,
                              style: const TextStyle(color: Colors.black87)),

                          const SizedBox(height: 10),
                          Text('Descrição',
                              style: TextStyle(
                                  color: Colors.grey.shade700,
                                  fontWeight: FontWeight.w600)),
                          const SizedBox(height: 6),
                          Text(descricao,
                              style: const TextStyle(color: Colors.black87)),

                          const SizedBox(height: 10),
                          Text('Transportadora',
                              style: TextStyle(
                                  color: Colors.grey.shade700,
                                  fontWeight: FontWeight.w600)),
                          const SizedBox(height: 6),
                          Text(transportadora,
                              style: const TextStyle(color: Colors.black87)),

                          const SizedBox(height: 10),
                          Text('Código de identificação',
                              style: TextStyle(
                                  color: Colors.grey.shade700,
                                  fontWeight: FontWeight.w600)),
                          const SizedBox(height: 6),
                          Text(codigo,
                              style: const TextStyle(color: Colors.black87)),

                          const SizedBox(height: 10),
                          Text('Recebido por',
                              style: TextStyle(
                                  color: Colors.grey.shade700,
                                  fontWeight: FontWeight.w600)),
                          const SizedBox(height: 6),
                          Text(recebidoPor,
                              style: const TextStyle(color: Colors.black87)),

                          const SizedBox(height: 20),

                          // Botão "Marcar como Entregue"
                          ElevatedButton(
                            onPressed: () {},
                            style: ElevatedButton.styleFrom(
                              backgroundColor: Colors.black,
                              foregroundColor: const Color(0xFFD4AF37),
                              padding: const EdgeInsets.symmetric(
                                  horizontal: 18, vertical: 12),
                              shape: RoundedRectangleBorder(
                                borderRadius: BorderRadius.circular(10),
                              ),
                            ),
                            child: const Text(
                              "Marcar como Entregue",
                              style: TextStyle(fontWeight: FontWeight.bold),
                            ),
                          ),
                        ],
                      ),
                    ),

                    const SizedBox(width: 12),

                    ClipRRect(
                      borderRadius: BorderRadius.circular(8),
                      child: Container(
                        width: 120,
                        height: 120,
                        color: Colors.grey.shade200,
                        child: Image.asset(
                          'lib/images/encomenda_demo.jpeg',
                          fit: BoxFit.cover,
                          errorBuilder: (context, error, stackTrace) {
                            return const Center(
                              child: Icon(Icons.image_not_supported_rounded,
                                  size: 36, color: Colors.grey),
                            );
                          },
                        ),
                      ),
                    ),
                  ],
                ),
              ),
            ),

            const SizedBox(height: 18),
            const Text(
              'Exemplo demonstrativo — insira aqui a lista real de encomendas.',
              textAlign: TextAlign.center,
              style: TextStyle(color: Colors.black54),
            ),
          ],
        ),
      ),
    );
  }
}
