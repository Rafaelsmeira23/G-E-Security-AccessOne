import 'package:flutter/material.dart';

class EncomendasResidencialPage extends StatelessWidget {
  const EncomendasResidencialPage({super.key});

  @override
  Widget build(BuildContext context) {
    // Demo data
    const destinatario = 'Mariana Astori Prestes';
    const apartamento = '110';
    const descricao = 'Um Pacote Amarelo';
    const transportadora = 'Loggi';
    const codigo = 'CAE-16375012-1';
    const recebidoPor = 'Rafael Santos';

    return Scaffold(
      appBar: AppBar(
        title: const Text('Encomendas - Residencial'),
        backgroundColor: Colors.black,
        foregroundColor: const Color(0xFFD4AF37),
        centerTitle: true,
      ),
      backgroundColor: const Color(0xFFF4F6F8),
      body: SingleChildScrollView(
        padding: const EdgeInsets.all(16),
        child: Column(
          children: [
            // Card fixo
            Card(
              shape: RoundedRectangleBorder(
                side: const BorderSide(color: Color(0xFFD4AF37), width: 1.4),
                borderRadius: BorderRadius.circular(12),
              ),
              elevation: 4,
              color: Colors.white,
              child: Padding(
                padding: const EdgeInsets.all(14),
                child: Row(
                  crossAxisAlignment: CrossAxisAlignment.start,
                  children: [
                    // Dados
                    Expanded(
                      child: Column(
                        crossAxisAlignment: CrossAxisAlignment.start,
                        children: [
                          Text(
                            'Destinatário',
                            style: TextStyle(
                              color: Colors.grey.shade700,
                              fontWeight: FontWeight.w600,
                            ),
                          ),
                          const SizedBox(height: 6),
                          const Text(
                            destinatario,
                            style: TextStyle(
                              color: Colors.black,
                              fontSize: 16,
                              fontWeight: FontWeight.bold,
                            ),
                          ),

                          const SizedBox(height: 10),
                          Text(
                            'Apto',
                            style: TextStyle(
                              color: Colors.grey.shade700,
                              fontWeight: FontWeight.w600,
                            ),
                          ),
                          const SizedBox(height: 6),
                          const Text(
                            apartamento,
                            style: TextStyle(color: Colors.black87),
                          ),

                          const SizedBox(height: 10),
                          Text(
                            'Descrição',
                            style: TextStyle(
                              color: Colors.grey.shade700,
                              fontWeight: FontWeight.w600,
                            ),
                          ),
                          const SizedBox(height: 6),
                          const Text(
                            descricao,
                            style: TextStyle(color: Colors.black87),
                          ),

                          const SizedBox(height: 10),
                          Text(
                            'Transportadora',
                            style: TextStyle(
                              color: Colors.grey.shade700,
                              fontWeight: FontWeight.w600,
                            ),
                          ),
                          const SizedBox(height: 6),
                          const Text(
                            transportadora,
                            style: TextStyle(color: Colors.black87),
                          ),

                          const SizedBox(height: 10),
                          Text(
                            'Código de identificação',
                            style: TextStyle(
                              color: Colors.grey.shade700,
                              fontWeight: FontWeight.w600,
                            ),
                          ),
                          const SizedBox(height: 6),
                          const Text(
                            codigo,
                            style: TextStyle(color: Colors.black87),
                          ),

                          const SizedBox(height: 10),
                          Text(
                            'Recebido por',
                            style: TextStyle(
                              color: Colors.grey.shade700,
                              fontWeight: FontWeight.w600,
                            ),
                          ),
                          const SizedBox(height: 6),
                          const Text(
                            recebidoPor,
                            style: TextStyle(color: Colors.black87),
                          ),
                        ],
                      ),
                    ),

                    const SizedBox(width: 12),

                    // Imagem da encomenda
                    ClipRRect(
                      borderRadius: BorderRadius.circular(8),
                      child: Container(
                        width: 120,
                        height: 120,
                        color: Colors.grey.shade200,
                        child: Image.asset(
                          'lib/images/encomenda_demo.jpeg',
                          fit: BoxFit.cover,
                          errorBuilder: (context, error, stackTrace) {
                            return const Center(
                              child: Icon(
                                Icons.image_not_supported_rounded,
                                size: 36,
                                color: Colors.grey,
                              ),
                            );
                          },
                        ),
                      ),
                    ),
                  ],
                ),
              ),
            ),

            const SizedBox(height: 18),

            // BOTÃO MARCAR COMO ENTREGUE
            SizedBox(
              width: double.infinity,
              child: ElevatedButton(
                onPressed: () {
                  ScaffoldMessenger.of(context).showSnackBar(
                    const SnackBar(
                      content: Text(
                        'Encomenda marcada como entregue!',
                        style: TextStyle(color: Colors.white),
                      ),
                      backgroundColor: Colors.black,
                      duration: Duration(seconds: 2),
                    ),
                  );
                },
                style: ElevatedButton.styleFrom(
                  backgroundColor: Colors.black,
                  foregroundColor: const Color(0xFFD4AF37),
                  padding: const EdgeInsets.symmetric(vertical: 14),
                  shape: RoundedRectangleBorder(
                    borderRadius: BorderRadius.circular(10),
                    side: const BorderSide(color: Color(0xFFD4AF37), width: 1),
                  ),
                ),
                child: const Text(
                  'Marcar como Entregue',
                  style: TextStyle(fontSize: 16, fontWeight: FontWeight.bold),
                ),
              ),
            ),

            const SizedBox(height: 24),

            const Text(
              'Exemplo de encomenda demonstrativa. Os dados acima são apenas uma simulação.',
              textAlign: TextAlign.center,
              style: TextStyle(color: Colors.black54),
            ),
          ],
        ),
      ),
    );
  }
}
