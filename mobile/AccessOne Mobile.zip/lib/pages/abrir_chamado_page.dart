import 'package:flutter/material.dart';
import 'package:flutter/services.dart';

class AbrirChamadoPage extends StatefulWidget {
  const AbrirChamadoPage({super.key});

  @override
  State<AbrirChamadoPage> createState() => _AbrirChamadoPageState();
}

class _AbrirChamadoPageState extends State<AbrirChamadoPage> {
  final _formKey = GlobalKey<FormState>();

  final TextEditingController _tituloController = TextEditingController();
  final TextEditingController _descricaoController = TextEditingController();

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        title: const Text("Abertura de Chamado"),
        centerTitle: true,
        backgroundColor: Colors.black,
        foregroundColor: Color(0xFFD4AF37),
      ),
      body: Padding(
        padding: const EdgeInsets.all(16),
        child: Form(
          key: _formKey,
          child: Column(
            crossAxisAlignment: CrossAxisAlignment.start,
            children: [
              const Text(
                "Título do chamado",
                style: TextStyle(color: Color(0xFFD4AF37), fontSize: 16),
              ),
              const SizedBox(height: 6),

              TextFormField(
                controller: _tituloController,
                decoration: const InputDecoration(
                  border: OutlineInputBorder(),
                  filled: true,
                  fillColor: Color(0xFF2C2C2C),
                ),
                inputFormatters: [
                  FilteringTextInputFormatter.allow(RegExp(r".*")),
                ],
                validator: (v) =>
                    v == null || v.trim().isEmpty ? "Informe um título" : null,
              ),

              const SizedBox(height: 18),

              const Text(
                "Descrição",
                style: TextStyle(color: Color(0xFFD4AF37), fontSize: 16),
              ),
              const SizedBox(height: 6),

              TextFormField(
                controller: _descricaoController,
                maxLines: 4,
                decoration: const InputDecoration(
                  border: OutlineInputBorder(),
                  filled: true,
                  fillColor: Color(0xFF2C2C2C),
                ),
                inputFormatters: [
                  FilteringTextInputFormatter.allow(RegExp(r".*")),
                ],
                validator: (v) =>
                    v == null || v.trim().isEmpty ? "Descreva o problema" : null,
              ),

              const SizedBox(height: 25),

              Center(
                child: ElevatedButton(
                  style: ElevatedButton.styleFrom(
                    backgroundColor: const Color(0xFFD4AF37),
                    foregroundColor: Colors.black,
                    padding: const EdgeInsets.symmetric(
                      horizontal: 24,
                      vertical: 12,
                    ),
                  ),
                  onPressed: () {
                    if (_formKey.currentState!.validate()) {
                      _showChamadoPopup(context);
                    }
                  },
                  child: const Text(
                    "Enviar chamado",
                    style: TextStyle(
                      fontWeight: FontWeight.bold,
                      fontSize: 16,
                    ),
                  ),
                ),
              ),
            ],
          ),
        ),
      ),
    );
  }

  /// POP-UP FIXO COM AS INFORMAÇÕES DO CHAMADO
  void _showChamadoPopup(BuildContext context) {
    showDialog(
      context: context,
      barrierDismissible: false, // NÃO FECHA AO CLICAR FORA
      builder: (context) {
        return AlertDialog(
          backgroundColor: const Color(0xFF1C1C1C),
          shape: RoundedRectangleBorder(
            borderRadius: BorderRadius.circular(16),
          ),
          title: const Text(
            "Chamado Registrado",
            style: TextStyle(
              color: Color(0xFFD4AF37),
              fontWeight: FontWeight.bold,
            ),
          ),
          content: Column(
            mainAxisSize: MainAxisSize.min,
            crossAxisAlignment: CrossAxisAlignment.start,
            children: [
              const Text(
                "Título:",
                style: TextStyle(
                  color: Color(0xFFD4AF37),
                  fontWeight: FontWeight.bold,
                ),
              ),
              Text(
                _tituloController.text,
                style: const TextStyle(color: Colors.white70),
              ),
              const SizedBox(height: 12),

              const Text(
                "Descrição:",
                style: TextStyle(
                  color: Color(0xFFD4AF37),
                  fontWeight: FontWeight.bold,
                ),
              ),
              Text(
                _descricaoController.text,
                style: const TextStyle(color: Colors.white70),
              ),
            ],
          ),
          actions: [
            Center(
              child: ElevatedButton(
                style: ElevatedButton.styleFrom(
                  backgroundColor: const Color(0xFFD4AF37),
                  foregroundColor: Colors.black,
                ),
                onPressed: () {
                  Navigator.pop(context); // fecha o pop-up
                  Navigator.pop(context); // volta para a tela anterior
                },
                child: const Text("Fechar"),
              ),
            ),
            const SizedBox(height: 8),
          ],
        );
      },
    );
  }
}
