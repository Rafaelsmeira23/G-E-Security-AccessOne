import 'package:flutter/material.dart';

// Import das páginas
import 'pages/login_page.dart';
import 'pages/home_page.dart';
import 'pages/reserva_comercial_page.dart';
import 'pages/reserva_residencial_page.dart';
import 'pages/abrir_chamado_page.dart';
import 'pages/encomendas_residencial_page.dart';
import 'pages/encomendas_comercial_page.dart';
import 'pages/notificacoes_page.dart';

// Dashboards
import 'pages/residencial_dashboard_page.dart';
import 'pages/comercial_dashboard_page.dart';

void main() {
  runApp(const GESecurityApp());
}

class GESecurityApp extends StatelessWidget {
  const GESecurityApp({super.key});

  @override
  Widget build(BuildContext context) {
    return MaterialApp(
      debugShowCheckedModeBanner: false,
      title: 'AccessOne | G&E Security',

      // ============================
      //       🎨 TEMA GLOBAL
      // ============================
      theme: ThemeData(
        brightness: Brightness.dark,
        fontFamily: 'Roboto',                          // <-- Corrige acentuação
        scaffoldBackgroundColor: const Color(0xFF121212),

        colorScheme: const ColorScheme(
          brightness: Brightness.dark,
          primary: Color(0xFFD4AF37),
          onPrimary: Colors.black,
          secondary: Color(0xFFBDBDBD),
          onSecondary: Colors.black,
          error: Colors.redAccent,
          onError: Colors.white,
          background: Color(0xFF1C1C1C),
          onBackground: Colors.white,
          surface: Color(0xFF2C2C2C),
          onSurface: Colors.white,
        ),

        appBarTheme: const AppBarTheme(
          backgroundColor: Color(0xFF1C1C1C),
          elevation: 3,
          titleTextStyle: TextStyle(
            color: Color(0xFFD4AF37),
            fontWeight: FontWeight.bold,
            fontSize: 20,
          ),
          iconTheme: IconThemeData(color: Color(0xFFD4AF37)),
        ),

        inputDecorationTheme: const InputDecorationTheme(
          filled: true,
          fillColor: Color(0xFF2C2C2C),
          border: OutlineInputBorder(),
        ),

        textSelectionTheme: const TextSelectionThemeData(
          cursorColor: Color(0xFFD4AF37),
          selectionColor: Color(0x55D4AF37),
          selectionHandleColor: Color(0xFFD4AF37),
        ),

        floatingActionButtonTheme: const FloatingActionButtonThemeData(
          backgroundColor: Color(0xFFD4AF37),
          foregroundColor: Colors.black,
        ),

        textTheme: const TextTheme(
          bodyLarge: TextStyle(color: Color(0xFFE0E0E0)),
          bodyMedium: TextStyle(color: Color(0xFFBDBDBD)),
          titleLarge: TextStyle(
            color: Color(0xFFD4AF37),
            fontWeight: FontWeight.bold,
            fontSize: 22,
          ),
        ),
      ),

      // ============================
      //          ROTAS
      // ============================
      initialRoute: '/login',
      routes: {
        '/login': (context) => const LoginPage(),
        '/': (context) => const HomePage(),

        // Reservas
        '/reserva_residencial': (context) => const ReservaResidencialPage(),
        '/reserva_comercial': (context) => const ReservaComercialPage(),

        // Dashboards
        '/dashboard_morador': (context) => const MoradorDashboardPage(),
        '/dashboard_comercial': (context) => const ComercialDashboardPage(),

        // Chamados
        '/abrir_chamado': (context) => const AbrirChamadoPage(),

        // Encomendas / notificações
        '/encomendas_residencial': (context) => const EncomendasResidencialPage(),
        '/encomendas_comercial': (context) => const EncomendasComercialPage(),
        '/notificacoes': (context) => const NotificacoesPage(),
      },
    );
  }
}
