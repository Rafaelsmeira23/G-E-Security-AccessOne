import 'package:flutter/material.dart';

class NotificacoesEncomendasResidencial extends StatelessWidget {
  const NotificacoesEncomendasResidencial({super.key});

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        title: const Text('Notificações de Encomendas - Residencial'),
        backgroundColor: const Color(0xFF0a3d62),
        foregroundColor: Colors.white,
      ),
      body: ListView(
        padding: const EdgeInsets.all(16),
        children: [
          Card(
            elevation: 3,
            child: ListTile(
              leading: const Icon(Icons.markunread_mailbox_rounded, color: Colors.indigo),
              title: const Text('Encomenda entregue na portaria'),
              subtitle: const Text('Apartamento 203 • 04/11/2025 - 16:45'),
              trailing: const Icon(Icons.check_circle, color: Colors.green),
            ),
          ),
          const SizedBox(height: 10),
          Card(
            elevation: 3,
            child: ListTile(
              leading: const Icon(Icons.local_shipping, color: Colors.orange),
              title: const Text('Encomenda a caminho'),
              subtitle: const Text('Apartamento 305 • 04/11/2025 - 12:20'),
              trailing: const Icon(Icons.pending, color: Colors.grey),
            ),
          ),
        ],
      ),
    );
  }
}
