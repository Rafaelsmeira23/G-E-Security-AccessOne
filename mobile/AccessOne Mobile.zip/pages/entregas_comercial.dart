import 'package:flutter/material.dart';

class NotificacoesEncomendasComercial extends StatelessWidget {
  const NotificacoesEncomendasComercial({super.key});

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        title: const Text('Notificações de Encomendas - Comercial'),
        backgroundColor: Colors.teal.shade700,
        foregroundColor: Colors.white,
      ),
      body: ListView(
        padding: const EdgeInsets.all(16),
        children: [
          Card(
            elevation: 3,
            child: ListTile(
              leading: const Icon(Icons.inventory_2_rounded, color: Colors.teal),
              title: const Text('Entrega recebida na recepção'),
              subtitle: const Text('Sala 504 • 04/11/2025 - 15:10'),
              trailing: const Icon(Icons.check_circle, color: Colors.green),
            ),
          ),
          const SizedBox(height: 10),
          Card(
            elevation: 3,
            child: ListTile(
              leading: const Icon(Icons.delivery_dining, color: Colors.orange),
              title: const Text('Encomenda em transporte'),
              subtitle: const Text('Sala 302 • 04/11/2025 - 10:30'),
              trailing: const Icon(Icons.pending, color: Colors.grey),
            ),
          ),
        ],
      ),
    );
  }
}
