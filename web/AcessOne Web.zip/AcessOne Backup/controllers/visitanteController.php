<?php 
require_once '../models/visitanteModel.php'; 

class VisitanteController { 
    private $model; 
    
    // Construtor que instancia o model do morador
    public function __construct() { 
        $this->model = new VisitanteModel(); 
    } 
    
    // Método para cadastrar um morador no banco
    public function cadastrar($dados) { 
        if ($this->model->inserir($dados)) { 
            echo "<script>alert('Visitante cadastrado com sucesso!'); window.history.back();</script>"; 
        } else { 
            echo "<script>alert('Erro ao cadastrar visitante.'); window.history.back();</script>"; 
        } 
    } 
} 

// Se o formulário foi submetido via POST
if ($_SERVER['REQUEST_METHOD'] === 'POST') {
     $controller = new VisitanteController(); 
     
     $uploadDir = __DIR__ . '/../public/uploads/'; 
     $urlFoto = ''; 
     
     // Cria o diretório de upload se não existir
     if (!is_dir($uploadDir)) { 
        mkdir($uploadDir, 0755, true); 
    } 
    
    if (isset($_FILES['foto']) && $_FILES['foto']['error'] === UPLOAD_ERR_OK) { 
        $fileTmpPath = $_FILES['foto']['tmp_name']; 
        $fileName = basename($_FILES['foto']['name']); 
        $fileExtension = strtolower(pathinfo($fileName, PATHINFO_EXTENSION)); 
        $allowedExtensions = ['jpeg', 'jpg', 'png']; 
        
        if (in_array($fileExtension, $allowedExtensions)) { 
            $newFileName = uniqid('foto_') . '.' . $fileExtension; 
            $destPath = $uploadDir . $newFileName; 
            
            if (move_uploaded_file($fileTmpPath, $destPath)) { 
                // Caminho relativo para salvar no banco
                $urlFoto = '/public/uploads/' . $newFileName; 
            } 
        } 
    } 
    
    $dados = [ 
    'id_condominio' => $_POST['id_condominio'] ?? null, 
    'email' => $_POST['email'] ?? null, 
    'tipo_visitante' => $_POST['tipo_visitante'] ?? null, 
    'nome' => $_POST['nome_visitante'] ?? null, 
    'url_foto' => $urlFoto, 
    'documento' => $_POST['documento_visitante'] ?? null, 
    'telefone' => $_POST['telefone'] ?? null, 
    'empresa' => $_POST['empresa'] ?? null, 
    'cargo' => $_POST['cargo'] ?? null,    
    'bloco_torre' => $_POST['bloco_torre'] ?? null, 
    'apartamento' => $_POST['apartamento'] ?? null, 
    'observacoes' => $_POST['observacoes'] ?? null 
]; 
    
    $controller->cadastrar($dados); 
} 