<?php
require_once '../models/encomendaModel.php';

class EncomendaController {
    private $model;

    public function __construct() {
        $this->model = new EncomendaModel();
    }

    public function cadastrar($dados) {
        if ($this->model->inserir($dados)) {
            echo "<script>alert('Encomenda cadastrada com sucesso!'); window.history.back();</script>";
        } else {
            echo "<script>alert('Erro ao cadastrar encomenda.'); window.history.back();</script>";
        }
    }
}

// Se o formulário foi submetido via POST
if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $controller = new EncomendaController();

    // Upload da foto
    $uploadDir = __DIR__ . '/../public/uploads/';
    $urlFoto = '';

    if (!is_dir($uploadDir)) {
        mkdir($uploadDir, 0755, true);
    }

    if (isset($_FILES['foto']) && $_FILES['foto']['error'] === UPLOAD_ERR_OK) {
        $fileTmpPath = $_FILES['foto']['tmp_name'];
        $fileName = basename($_FILES['foto']['name']);
        $fileExtension = strtolower(pathinfo($fileName, PATHINFO_EXTENSION));
        $allowedExtensions = ['jpeg', 'jpg', 'png'];

        if (in_array($fileExtension, $allowedExtensions)) {
            $newFileName = uniqid('encomenda_') . '.' . $fileExtension;
            $destPath = $uploadDir . $newFileName;
            if (move_uploaded_file($fileTmpPath, $destPath)) {
                $urlFoto = '/public/uploads/' . $newFileName;
            }
        }
    }

    // Dados do formulário
    $dados = [
        'id_condominio'       => isset($_POST['id_condominio']) ? (int)$_POST['id_condominio'] : null,
        'id_usuario'          => null, // se você tiver vinculação com morador/funcionário, preencher aqui
        'url_foto'            => $urlFoto,
        'descricao'           => $_POST['descricaoEncomenda'] ?? '',
        'codigo_rastreamento' => $_POST['codigoRastreio'] ?? '',
        'status'              => 'Recebida',
        'data_prevista_entrega'=> $_POST['data_prevista_entrega'] ?? null, // <- corrigido!
        'status_encomenda'    => 'Aguardando Retirada',
        'observacoes'         => $_POST['observacoes'] ?? ''
    ];

    $controller->cadastrar($dados);
}
