<?php
// Importa a conexão com o banco de dados e o model responsável pela lógica de login
require_once '../models/conectaBD.php';
require_once '../models/loginModel.php';

// Estabelece a conexão com o banco
$conn = getConexao();

// Cria uma instância do controlador de login
$loginController = new LoginController($conn);

// Verifica se o formulário de login foi enviado via método POST
if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $email = $_POST['email'];   // Captura o e-mail do formulário
    $senha = $_POST['senha'];   // Captura a senha do formulário

    // Chama a função de login do controlador
    $loginController->login($email, $senha);
}

// Controlador responsável pelas ações de login e logout
class LoginController {
    private $model;

    // Construtor recebe a conexão e instancia o model
    public function __construct($conn) {
        $this->model = new LoginModel($conn);
    }

    // Função de login: autentica e redireciona conforme o tipo de usuário
    public function login($email, $senha) {
        $usuario = $this->model->autenticar($email, $senha);

        if ($usuario) {
            // Inicia a sessão e armazena dados do usuário
            session_start();
            $_SESSION['id_usuario'] = $usuario['id_usuario'];
            $_SESSION['nome'] = $usuario['nome'];
            $_SESSION['tipo_usuario'] = $usuario['tipo_usuario'];
            $_SESSION['id_condominio'] = $usuario['id_condominio'];  // Identifica o condomínio
            $_SESSION['tipo_condominio'] = $usuario['tipo_condominio']; // Residencial ou Comercial

            // Redireciona com base no tipo de usuário e tipo de condomínio
            switch ($_SESSION['tipo_usuario']) {
                case 'Administrador':
                    header('Location: /views/dashboards/dashBoardAdmin.php');
                    break;
                case 'Zelador':
                    header('Location: /views/cadPorteiro.php');
                    break;
                case 'Porteiro':
                    if ($_SESSION['tipo_condominio'] === 'Residencial') {
                        header('Location: /views/condResidencial.php');
                    } else {
                        header('Location: /views/condComercial.php');
                    }
                    break;
                default:
                    header('Location: /index.php');
            }
            exit;
        } else {
            // Mensagem de erro caso as credenciais estejam incorretas
            echo "E-mail ou senha incorretos.";
        }
    }

    // Função de logout: encerra a sessão
    public function logout() {
        session_start();
        session_unset();
        session_destroy();
        header('Location: /index.php');
        exit;
    }
}
?>