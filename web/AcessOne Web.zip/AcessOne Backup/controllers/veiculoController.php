<?php
require_once '../models/veiculoModel.php';

class VeiculoController {
    private $model;

    // Construtor que instancia o model de veículo
    public function __construct() {
        $this->model = new VeiculoModel();
    }

    // Método para cadastrar veículo no banco
    public function cadastrar($dados) {
        if ($this->model->inserir($dados)) {
            echo "<script>alert('Veículo cadastrado com sucesso!'); window.history.back();</script>";
        } else {
            echo "<script>alert('Erro ao cadastrar veículo.'); window.history.back();</script>";
        }
    }
}

// Se o formulário foi submetido via POST
if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $controller = new VeiculoController();

    // Dados vindos do formulário
    $dados = [
        'id_usuario'  => isset($_POST['id_usuario']) ? (int)$_POST['id_usuario'] : null, 
        'placa'       => $_POST['placa'] ?? '',
        'marca'       => $_POST['marca'] ?? '',
        'modelo'      => $_POST['modelo'] ?? '',
        'cor'         => $_POST['cor'] ?? '',
        'vaga_idoso'  => isset($_POST['vaga_idoso']) ? (int)$_POST['vaga_idoso'] : 0
    ];

    $controller->cadastrar($dados);
}
