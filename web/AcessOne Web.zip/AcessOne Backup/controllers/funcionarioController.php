<?php
require_once '../models/funcionarioModel.php';

class FuncionarioController {
    private $model;

    public function __construct() {
        $this->model = new FuncionarioModel();
    }

    public function cadastrar($dados) {
        if ($this->model->inserir($dados)) {
            echo "<script>alert('Funcionário cadastrado com sucesso!'); window.history.back();</script>";
        } else {
            echo "<script>alert('Erro ao cadastrar Funcionário.'); window.history.back();</script>";
        }
    }
}

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $controller = new FuncionarioController();

    $uploadDir = __DIR__ . '/../public/uploads/';
    if (!is_dir($uploadDir)) mkdir($uploadDir, 0755, true);

    $urlFoto = '';
    if (isset($_FILES['foto']) && $_FILES['foto']['error'] === UPLOAD_ERR_OK) {
        $ext = strtolower(pathinfo($_FILES['foto']['name'], PATHINFO_EXTENSION));
        $allowed = ['jpeg', 'jpg', 'png'];
        if (in_array($ext, $allowed)) {
            $newFile = uniqid('foto_') . '.' . $ext;
            $dest = $uploadDir . $newFile;
            if (move_uploaded_file($_FILES['foto']['tmp_name'], $dest)) {
                $urlFoto = '/public/uploads/' . $newFile;
            }
        }
    }

    $dados = [
        'nome'         => $_POST['nome_funcionario'] ?? '',
        'documento'    => $_POST['documento_funcionario'] ?? '',
        'telefone'     => $_POST['telefone_funcionario'] ?? '',
        'empresa'      => $_POST['empresa_funcionario'] ?? '',
        'cargo'        => $_POST['cargo_funcionario'] ?? '',
        'observacoes'  => $_POST['observacoes'] ?? '',
        'url_foto'     => $urlFoto,
        'id_condominio'=> isset($_POST['id_condominio']) ? (int)$_POST['id_condominio'] : null
    ];

    $controller->cadastrar($dados);
}
