<?php
// Inclui o model responsável por interagir com o banco de dados da empresa
require_once '../models/empresaModel.php';

// Verifica se o formulário foi enviado via método POST
if ($_SERVER['REQUEST_METHOD'] === 'POST') {

    // Captura os dados enviados via formulário (método POST)
    $nome = $_POST['nome_empresa'];               // Nome da empresa
    $responsavel = $_POST['responsavel_empresa']; // Nome do responsável pela empresa
    $conjunto = $_POST['Conjunto_empresa'];       // Conjunto ou sala da empresa
    $cnpj = $_POST['cnpj_empresa'];               // CNPJ da empresa
    $telefone = $_POST['telefone_empresa'];       // Telefone para contato
    $email = $_POST['email_empresa'];             // E-mail da empresa
    $endereco = $_POST['endereco_empresa'];       // Endereço completo da empresa

    // Chama a função do model para cadastrar a empresa no banco de dados
    cadastrarEmpresa($nome, $responsavel, $conjunto, $cnpj, $telefone, $email, $endereco);

    // Redireciona o usuário para uma página de sucesso após o cadastro
    header('Location: ../views/sucesso.html');
    exit;
}