<?php
session_start();
require_once '../models/usuarioModel.php';

class UsuarioController {
    private $model;

    public function __construct() {
        // Instancia o model de usuário para acessar os métodos do banco
        $this->model = new UsuarioModel();
    }

    // Método para realizar o login do usuário
    public function login($email, $senha) {
        // Busca o usuário no banco pelo email informado
        $usuario = $this->model->buscarPorEmail($email);

        // Verifica se o usuário foi encontrado
        if (!$usuario) {
            // Retorna erro caso o usuário não exista
            return ['erro' => 'Usuário não encontrado'];
        }

        // Compara o hash MD5 da senha informada com o hash armazenado
        if ($usuario['senha_hash'] === md5($senha)) {
            // Se a senha estiver correta, inicia a sessão e guarda dados do usuário
            $_SESSION['usuario_logado'] = true;
            $_SESSION['tipo_usuario'] = $usuario['tipo_usuario'];
            $_SESSION['id_usuario'] = $usuario['id_usuario'];
            // Retorna sucesso para a camada que chamou o método
            return ['sucesso' => true];
        } else {
            // Retorna erro caso a senha esteja incorreta
            return ['erro' => 'Senha incorreta'];
        }
    }

    // Método para cadastrar um novo usuário
    public function cadastrar($email, $senha, $tipo) {
        // Verifica se já existe um usuário com o email informado
        if ($this->model->buscarPorEmail($email)) {
            // Retorna erro se o email já estiver em uso
            return ['erro' => 'E-mail já está em uso'];
        }

        // Gera o hash MD5 da senha para armazenar no banco
        $senhaHash = md5($senha);

        // Chama o método do model para inserir o novo usuário no banco
        return $this->model->inserirUsuario($email, $senhaHash, $tipo);
    }
}