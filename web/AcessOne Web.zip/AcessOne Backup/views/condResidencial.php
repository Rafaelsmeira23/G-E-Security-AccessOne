<?php
    // conexão com o banco de dados
    $conn = new mysqli("localhost", "root", "", "sistema_ge");
    if ($conn->connect_error) {
        // termina o script e mostra erro se não conseguir conectar
        die("Erro na conexão com o banco: " . $conn->connect_error);
    }

    // consulta para buscar os condomínios e popular o select
    $condominios = $conn->query("SELECT id_condominio, nome FROM cad_condominio");

    session_start(); // inicia a sessão para controle de usuário

    // verifica se o usuário está logado e se é do tipo 'Porteiro'
    if (!isset($_SESSION['tipo_usuario']) || $_SESSION['tipo_usuario'] !== 'Porteiro') {
        header("Location: /index.php"); // redireciona para página principal se não for admin
        exit;
    }

    require_once '../models/conectaBD.php';
    $conn = getConexao();

    $condominios = [];
    $result = $conn->query("SELECT id_condominio, nome FROM cad_condominio");

    if ($result) {
        while ($row = $result->fetch_assoc()) {
            $condominios[] = $row;
        }
    }
?>
<!DOCTYPE html>
<html lang="pt-BR">
<head>
    <meta charset="UTF-8" />
    <meta name="viewport" content="width=device-width, initial-scale=1" />
    <title>Condomínio Residencial</title>
    <!-- Link para o arquivo CSS externo -->
    <link rel="stylesheet" href="/public/CSS/residencialStyle.css" />
</head>
<body>
    <nav>
        <!-- Botões para mostrar o formulário correspondente -->
        <button onclick="mostrarFormulario('morador-form')">Morador</button>
        <button onclick="mostrarFormulario('visitante-form')">Visitante</button>
        <button onclick="mostrarFormulario('funcionario-form')">Funcionário</button>
        <button onclick="mostrarFormulario('veiculo-form')">Veículo</button>
        <button onclick="mostrarFormulario('encomenda-form')">Encomenda</button>
    </nav>

    <!-- Cadastro de Morador -->
    <div class="form-section morador-form hidden">
        <h3>Cadastro de Morador</h3>
        <form method="POST" action="../../controllers/moradorController.php" enctype="multipart/form-data">
            <!-- Campo para nome do morador -->
            <label for="nome_morador">Nome:</label>
            <input type="text" class="nome_morador" name="nome_morador" required />

            <!-- Campo para seleção do tipo de documento -->
            <label for="tipo_documento_morador">Tipo de Documento:</label>
            <select class="tipo_documento_morador" name="tipo_documento_morador" required>
                <option value="">--Selecione--</option>
                <option value="CPF">CPF</option>
                <option value="RG">RG</option>
            </select>

            <!-- Campo para número do documento -->
            <label for="documento_morador">Documento:</label>
            <input type="text" class="documento_morador" name="documento_morador" required />

            <!-- Campo para telefone -->
            <label for="telefone_morador">Telefone:</label>
            <input type="text" class="telefone_morador" name="telefone_morador" required />

            <!-- Campo para email -->
            <label for="email_morador">Email:</label>
            <input type="email" class="email_morador" name="email_morador" required />

            <!-- Campo para bloco ou torre -->
            <label for="bloco_torre">Bloco/Torre:</label>
            <input type="text" class="bloco_torre" name="bloco_torre" required />

            <!-- Campo para número do apartamento -->
            <label for="apartamento">Apartamento:</label>
            <input type="number" class="apartamento" name="apartamento" min="101" max="1100" required />

            <!-- Campo para definir o vínculo do morador com o apartamento -->
            <label for="vinculo_morador">Vínculo com o Apartamento:</label>
            <select class="vinculo_morador" name="vinculo_morador" required>
                <option value="">--Selecione--</option>
                <option value="proprietario">Proprietário Titular</option>
                <option value="dependente">Dependente</option>
            </select>

            <!-- Campo para upload da foto do morador -->
            <label for="foto">Foto:</label>
            <input type="file" id="foto" name="foto" accept="image/*" required>

            <label for="id_condominio">Condomínio:</label>
            <select id="id_condominio" name="id_condominio" required>
                <option value="">--Selecione um condomínio--</option>
                <?php foreach ($condominios as $row): ?>
                    <option value="<?= $row['id_condominio'] ?>"><?= htmlspecialchars($row['nome']) ?></option>
                <?php endforeach; ?>
            </select>

            <!-- Botão para enviar o formulário -->
            <button type="submit">Cadastrar Morador</button>
        </form>
    </div>

    
    <!-- Cadastro de Visitante -->
    <div class="form-section visitante-form hidden">
        <h3>Cadastro de Visitante</h3>
        <form method="POST" action="../../controllers/visitanteController.php" enctype="multipart/form-data">
            <label for="nome_visitante">Nome:</label>
            <input type="text" name="nome_visitante" required />

            <label for="tipo_visitante">Tipo de Visitante: </label>
            <select name="tipo_visitante" required>
                <option value="">--Selecione--</option>
                <option value="Familiar">Familiar</option>
                <option value="Conhecido">Conhecido</option>
                <option value="Prestador de Servico">Prestador de Serviço</option>
                <option value="Outros">Outros</option>
            </select>

            <label for="tipo_documento_visitante">Tipo de Documento:</label>
                <select class="tipo_documento_visitante" name="tipo_documento_visitante" required>
                    <option value="">--Selecione--</option>
                    <option value="CPF">CPF</option>
                    <option value="RG">RG</option>
                </select>    

            <label for="documento_visitante">Documento:</label>
            <input type="text" name="documento_visitante" required />

            <label for="telefone">Telefone:</label>
            <input type="text" name="telefone" required />

            <label for="bloco_torre">Bloco/Torre:</label>
            <input type="text" name="bloco_torre" required />

            <label for="apartamento">Apartamento:</label>
            <input type="text" name="apartamento" required />

            <label for="foto">Foto:</label>
            <input type="file" name="foto" accept="image/*" required     />

            <label for="observacoes">Observações:</label>

            <textarea name="observacoes" rows="4" cols="50"></textarea>

            <label for="id_condominio">Condomínio:</label>
            <select id="id_condominio" name="id_condominio" required>
                <option value="">--Selecione um condomínio--</option>
                    <?php foreach ($condominios as $row): ?>
                <option value="<?= $row['id_condominio'] ?>"><?= htmlspecialchars($row['nome']) ?></option>
                <?php endforeach; ?>
            </select>

            <button type="submit">Cadastrar Visitante</button>
        </form>
    </div>


    <!-- Cadastro de Funcionário -->
    <div class="form-section funcionario-form hidden">
        <h3>Cadastro de Funcionário</h3>
        <form method="POST" action="../../controllers/funcionarioController.php" enctype="multipart/form-data">
            <label for="nome">Nome:</label>
            <input type="text" name="nome_funcionario" required />

            <label for="tipo_documento_funcionario">Tipo de Documento:</label>
            <select class="tipo_documento_funcionario" name="tipo_documento_funcionario" required>
                <option value="">--Selecione--</option>
                <option value="CPF">CPF</option>
                <option value="RG">RG</option>
            </select>

            <label for="documento">Documento:</label>
            <input type="text" name="documento_funcionario" required />

            <label for="telefone">Telefone:</label>
            <input type="text" name="telefone_funcionario" required />

            <label for="cargo">Cargo:</label>
            <input type="text" name="cargo_funcionario" required />

            <label for="foto">Foto:</label>
            <input type="file" name="foto" accept="image/*" required />

            <label for="id_condominio">Condomínio:</label>
            <select id="id_condominio" name="id_condominio" required>
                <option value="">--Selecione um condomínio--</option>
                <?php foreach ($condominios as $row): ?>
                    <option value="<?= $row['id_condominio'] ?>"><?= htmlspecialchars($row['nome']) ?></option>
                <?php endforeach; ?>
            </select>

            <label for="observacoes">Observações:</label>
            <textarea name="observacoes" rows="4" cols="50"></textarea>

            <button type="submit">Cadastrar Funcionário</button>
        </form>
    </div>


    <!-- Cadastro de Veículo -->
    <div class="form-section veiculo-form hidden">
        <h3>Cadastro de Veículo</h3>
        <form method="POST" action="../../controllers/veiculoController.php">
            <!-- Campo para nome do proprietário do veículo -->
            <label for="proprietario">Proprietário:</label>
            <input type="text" class="proprietario" name="proprietario" required />

            <!-- Campo para placa do veículo -->
            <label for="placa">Placa:</label>
            <input type="text" class="placa" name="placa" required />

            <!-- Campo para marca do veículo -->
            <label for="marca">Marca:</label>
            <input type="text" class="marca" name="marca" />

            <!-- Campo para modelo do veículo -->
            <label for="modelo">Modelo:</label>
            <input type="text" class="modelo" name="modelo" />

            <!-- Campo para cor do veículo -->
            <label for="cor">Cor:</label>
            <input type="text" class="cor" name="cor" />

            <label for="id_condominio">Condomínio:</label>
            <select id="id_condominio" name="id_condominio" required>
                <option value="">--Selecione um condomínio--</option>
                <?php foreach ($condominios as $row): ?>
                    <option value="<?= $row['id_condominio'] ?>"><?= htmlspecialchars($row['nome']) ?></option>
                <?php endforeach; ?>
            </select>

            <!-- Botão para enviar o formulário -->
            <button type="submit">Cadastrar</button>
        </form>
    </div>

    <!-- Cadastro de Encomenda -->
    <div class="form-section encomenda-form hidden">
        <h3>Cadastro de Encomenda</h3>
        <form method="POST" action="../../controllers/encomendaController.php" enctype="multipart/form-data">
            <!-- Campo para nome do destinatário da encomenda -->
            <label for="nomeDestinatario">Nome do Destinatário:</label>
            <input type="text" class="nomeDestinatario" name="nomeDestinatario" required />

            <!-- Campo para número do apartamento do destinatário -->
            <label for="numeroApto">Número do Apartamento:</label>
            <input type="text" class="numeroApto" name="numeroApto" required />

            <!-- Campo para descrição da encomenda -->
            <label for="descricaoEncomenda">Descrição da Encomenda:</label>
            <input type="text" class="descricaoEncomenda" name="descricaoEncomenda" required />

            <!-- Campo para transportadora -->
            <label for="transportadora">Transportadora:</label>
            <input type="text" class="transportadora" name="transportadora" />

            <!-- Campo para código de rastreio -->
            <label for="codigoRastreio">Código de Rastreio:</label>
            <input type="text" class="codigoRastreio" name="codigoRastreio" />

            <!-- Campo para data prevista de entrega/recebimento -->
            <label for="dataRecebimento">Data de Recebimento:</label>
            <input type="date" name="data_prevista_entrega" required>

            <!-- Campo para informar qual funcionário recebeu a encomenda -->
            <label for="recebidoPor">Recebido por (funcionário):</label>
            <input type="text" class="recebidoPor" name="recebidoPor" required />

            <!-- Campo para upload da foto da encomenda -->
            <label for="foto">Foto da Encomenda:</label>
            <input type="file" id="foto" name="foto" accept="image/*" required>

            <label for="id_condominio">Condomínio:</label>
            <select id="id_condominio" name="id_condominio" required>
                <option value="">--Selecione um condomínio--</option>
                <?php foreach ($condominios as $row): ?>
                    <option value="<?= $row['id_condominio'] ?>"><?= htmlspecialchars($row['nome']) ?></option>
                <?php endforeach; ?>
            </select>

            <!-- Botão para enviar o formulário -->
            <button type="submit">Cadastrar Encomenda</button>
        </form>
    </div>

    <!-- Inclusão do arquivo JavaScript externo -->
    <script src="/public/JS/formScript.js"></script>

    <!-- Script para popular os selects de andar e apartamento -->
    <script>
        // Popula o select dos andares de 1 a 100 no cadastro de visitante
        const selectAndar = document.getElementById("andar_visita");
        for (let i = 1; i <= 100; i++) {
            const option = document.createElement("option");
            option.value = i; // Valor do option (número do andar)
            option.textContent = ${i}º andar; // Texto exibido no option
            selectAndar.appendChild(option);
        }

        // Função para atualizar o select de apartamentos com base no andar escolhido
        function atualizarApartamentos() {
            const andar = parseInt(document.getElementById("andar_visita").value);
            const apartamentoSelect = document.getElementById("apartamento_visita");

            // Limpa as opções atuais do select de apartamentos
            apartamentoSelect.innerHTML = '<option value="">--Selecione o Apartamento--</option>';

            // Se o andar for válido, cria opções de apartamento de 01 a 10 para aquele andar
            if (!isNaN(andar)) {
                for (let apt = 1; apt <= 10; apt++) {
                    // Monta o número do apartamento no formato andar + 2 dígitos (ex: 101, 102, ..., 110)
                    const aptNumero = ${andar}${apt.toString().padStart(2, "0")};
                    const option = document.createElement("option");
                    option.value = aptNumero; // Valor do option (número do apartamento)
                    option.textContent = Apt ${aptNumero}; // Texto exibido no option
                    apartamentoSelect.appendChild(option);
                }
            }
        }
    </script>
</body>
</html>