<?php
  // Inicia a sessão para verificar informações de login
  session_start();

  // Verifica se a variável de sessão 'tipo_usuario' existe e se é igual a 'Porteiro'
  // Caso contrário, redireciona para a página inicial (index.php) e encerra o script
  if (!isset($_SESSION['tipo_usuario']) || $_SESSION['tipo_usuario'] !== 'Porteiro') {
      header("Location: /index.php");
      exit;
  }
?>

<!DOCTYPE html>
<html lang="pt-br">
<head>
  <meta charset="UTF-8">
  <title>Consulta Geral</title>
  <!-- Link para arquivo CSS que estiliza a página -->
  <link rel="stylesheet" href="/public/CSS/consultaStyle.css">
</head>
<body>

  <div class="container">
    <h1>Consulta Geral</h1>

    <div class="abas">
      <!-- Botões para trocar entre as abas Morador, Funcionário, Visitante e Encomenda -->
      <!-- A classe 'ativa' indica a aba selecionada -->
      <button class="aba ativa" onclick="trocarAba('morador')">Morador</button>
      <button class="aba" onclick="trocarAba('funcionario')">Funcionário</button>
      <button class="aba" onclick="trocarAba('visitante')">Visitante</button>
      <button class="aba" onclick="trocarAba('encomenda')">Encomenda</button>
    </div>

    <!-- Formulário para enviar a consulta -->
    <form method="POST" action="consulta_dados.php">
      <!-- Campo oculto que armazena o tipo de consulta atual (morador, funcionario, etc) -->
      <input type="hidden" name="tipoConsulta" id="tipoConsulta" value="morador">

      <!-- Área onde o conteúdo do formulário muda dinamicamente conforme a aba selecionada -->
      <div id="conteudo-dinamico">
        <!-- O JavaScript vai inserir aqui os campos correspondentes -->
      </div>

      <!-- Botão para enviar o formulário -->
      <button type="submit">Buscar</button>
    </form>

    <!-- Tabela onde os resultados da consulta serão exibidos -->
    <table id="resultado-tabela">
      <thead>
        <tr>
          <th>Nome</th>
          <th>Tipo</th>
          <th>Informações</th>
        </tr>
      </thead>
      <tbody>
        <!-- Os dados retornados pelo PHP serão inseridos aqui -->
      </tbody>
    </table>

  </div>

  <!-- Script JavaScript que controla a troca das abas e atualização do formulário -->
  <script src="/public/JS/consultaScript.js"></script>
</body>
</html>