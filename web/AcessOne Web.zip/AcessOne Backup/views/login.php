<!DOCTYPE html>
<html lang="pt-br">
<head>
    <meta charset="UTF-8"> <!-- Define a codificação de caracteres da página -->
    <meta http-equiv="X-UA-Compatible" content="IE=edge"> <!-- Garante compatibilidade com o IE -->
    <meta name="viewport" content="width=device-width, initial-scale=1.0"> <!-- Responsividade para dispositivos móveis -->
    <title>Login</title> <!-- Título da página que aparece na aba do navegador -->
    
    <!-- Link para o arquivo CSS que estiliza a página -->
    <link rel="stylesheet" href="/public/CSS/loginStyle.css">

    <!-- Importa o pacote de ícones Boxicons para usar ícones na interface -->
    <link href='https://unpkg.com/boxicons@2.1.4/css/boxicons.min.css' rel='stylesheet'>
</head>
<body>

    <div class="wrapper">
        <!-- Formulário que envia dados via método POST para o controlador de login -->
        <form method="POST" action="../../controllers/loginController.php" >
            <h1>Login</h1>

            <!-- Caixa de input para o e-mail do usuário -->
            <div class="input-box">
                <input type="email" name="email" placeholder="Email" required>
                <!-- Ícone de usuário ao lado do campo -->
                <i class='bx bxs-user'></i>
            </div>

            <!-- Caixa de input para a senha do usuário -->
            <div class="input-box">
                <input type="password" name="senha" placeholder="Senha" required>
                <!-- Ícone de cadeado ao lado do campo -->
                <i class='bx bxs-lock-alt'></i>
            </div>

            <!-- Botão para enviar o formulário e realizar o login -->
            <button type="submit" class="btn-enviar">Login</button><br></br>
            
        </form>
    </div>
    
</body>
</html>