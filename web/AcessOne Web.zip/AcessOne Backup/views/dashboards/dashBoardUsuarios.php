<?php
session_start();

// Verificação de sessão
if (!isset($_SESSION['id_usuario']) || $_SESSION['tipo_usuario'] !== 'Administrador') {
    header("Location: login.php");
    exit();
}

// Nome do usuário logado
$nomeUsuario = $_SESSION['nome_usuario'] ?? 'Administrador';

// Conexão com o banco
$conn = new mysqli("localhost", "root", "", "sistema_ge");
if ($conn->connect_error) {
    die("Erro na conexão com o banco: " . $conn->connect_error);
}

// Filtro de tipo e busca
$filtroTipo = $_GET['tipo_usuario'] ?? '';
$busca = $_GET['busca'] ?? '';

// Query principal
$query = "SELECT url_foto, nome, tipo_usuario, email, telefone, documento, data_cadastro
          FROM cad_usuario
          WHERE 1=1";

if (!empty($filtroTipo)) {
    $query .= " AND tipo_usuario = '$filtroTipo'";
}

if (!empty($busca)) {
    $busca = $conn->real_escape_string($busca);
    $query .= " AND (nome LIKE '%$busca%' OR email LIKE '%$busca%' OR documento LIKE '%$busca%' OR telefone LIKE '%$busca%')";
}

$query .= " ORDER BY data_cadastro DESC";
$result = $conn->query($query);
?>
<!DOCTYPE html>
<html lang="pt-BR">
<head>
  <meta charset="UTF-8">
  <meta name="viewport" content="width=device-width, initial-scale=1.0">
  <title>Usuários Cadastrados - Administrador</title>
  <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.2/dist/css/bootstrap.min.css" rel="stylesheet">
  <link href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.5.0/css/all.min.css" rel="stylesheet">
  <link rel="stylesheet" href="/public/CSS/dshBoardAdmStyle.css">
  <style>
    /* === Foto dos usuários na tabela === */
    .user-foto {
      width: 55px;
      height: 55px;
      object-fit: cover;
      border-radius: 50%;
      border: 2px solid #FFD700;
      box-shadow: 0 2px 5px rgba(0,0,0,0.4);
    }
  </style>
</head>
<body>
  <div class="d-flex">
    <!-- Sidebar -->
    <nav class="sidebar p-3">
      <h4><i class="fas fa-shield-alt"></i> Painel Admin</h4>
      <ul class="nav flex-column">
        <li class="nav-item"><a href="dashBoardAdmin.php" class="active"><i class="fas fa-user"></i> Usuários</a></li>
        <li class="nav-item"><a href="/views/dashboards/dashBoardCondominios.php"><i class="fas fa-building"></i> Condomínios</a></li>
      </ul>

      <div class="logo-container">
        <img src="/public/Image/img2.png" alt="Logo G&E Security">
      </div>
    </nav>

    <!-- Conteúdo Principal -->
    <div class="main-content w-100">
      <div class="d-flex justify-content-between align-items-center mb-4">
        <h2><i class="fas fa-users"></i> Usuários Cadastrados</h2>  
      </div>

      <!-- Filtros -->
      <form method="GET" class="mb-4 d-flex flex-wrap gap-3 align-items-center">
        <div class="form-group">
          <label class="text-light">Tipo de Usuário:</label>
          <select name="tipo_usuario" class="form-select">
            <option value="">Todos</option>
            <option value="Administrador" <?= $filtroTipo == 'Administrador' ? 'selected' : '' ?>>Administrador</option>
            <option value="Zelador" <?= $filtroTipo == 'Zelador' ? 'selected' : '' ?>>Zelador</option>
            <option value="Porteiro" <?= $filtroTipo == 'Porteiro' ? 'selected' : '' ?>>Porteiro</option>
            <option value="Morador" <?= $filtroTipo == 'Morador' ? 'selected' : '' ?>>Morador</option>
            <option value="Visitante" <?= $filtroTipo == 'Visitante' ? 'selected' : '' ?>>Visitante</option>
            <option value="Funcionario" <?= $filtroTipo == 'Funcionario' ? 'selected' : '' ?>>Funcionário</option>
          </select>
        </div>

        <div class="form-group flex-grow-1">
          <label class="text-light">Busca:</label>
          <input type="text" name="busca" class="form-control" placeholder="Buscar por nome, e-mail, documento..." value="<?= htmlspecialchars($busca) ?>">
        </div>

        <button type="submit" class="btn btn-primary align-self-end"><i class="fas fa-search"></i> Filtrar</button>
        <a href="dashBoardUsuarios.php" class="btn btn-secondary align-self-end"><i class="fas fa-undo"></i> Limpar</a>
      </form>

      <!-- Tabela com Foto -->
      <div class="card p-4 shadow">
        <div class="table-responsive">
          <table class="table table-dark table-striped table-hover align-middle text-center">
            <thead>
              <tr>
                <th>Foto</th>
                <th>Nome</th>
                <th>Tipo</th>
                <th>Email</th>
                <th>Documento</th>
                <th>Telefone</th>
                <th>Data Cadastro</th>
              </tr>
            </thead>
            <tbody>
              <?php if ($result && $result->num_rows > 0): ?>
                <?php while($row = $result->fetch_assoc()): ?>
                  <tr>
                    <td>
                      <?php if (!empty($row['url_foto'])): ?>
                        <img src="<?= htmlspecialchars($row['url_foto']) ?>" alt="Foto de <?= htmlspecialchars($row['nome']) ?>" class="user-foto">
                      <?php else: ?>
                        <img src="/public/Image/default-user.png" alt="Sem foto" class="user-foto">
                      <?php endif; ?>
                    </td>
                    <td><?= htmlspecialchars($row['nome']) ?></td>
                    <td><?= htmlspecialchars($row['tipo_usuario']) ?></td>
                    <td><?= htmlspecialchars($row['email']) ?></td>
                    <td><?= htmlspecialchars($row['documento']) ?></td>
                    <td><?= htmlspecialchars($row['telefone']) ?></td>
                    <td><?= date('d/m/Y H:i', strtotime($row['data_cadastro'])) ?></td>
                    </td>
                  </tr>
                <?php endwhile; ?>
              <?php else: ?>
                <tr><td colspan="8" class="text-center text-light">Nenhum usuário encontrado.</td></tr>
              <?php endif; ?>
            </tbody>
          </table>
        </div>
      </div>
    </div>
  </div>

  <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.2/dist/js/bootstrap.bundle.min.js"></script>
</body>
</html>
