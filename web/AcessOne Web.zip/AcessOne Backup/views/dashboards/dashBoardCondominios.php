<?php
session_start();

// Verificação de sessão
if (!isset($_SESSION['id_usuario']) || $_SESSION['tipo_usuario'] !== 'Administrador') {
    header("Location: login.php");
    exit();
}

// Nome do usuário logado
$nomeUsuario = $_SESSION['nome_usuario'] ?? 'Administrador';

// Conexão com o banco
$conn = new mysqli("localhost", "root", "", "sistema_ge");
if ($conn->connect_error) {
    die("Erro na conexão com o banco: " . $conn->connect_error);
}

// Consulta de condomínios
$query = "SELECT * FROM cad_condominio ORDER BY data_cadastro DESC";
$result = $conn->query($query);

// Separar por tipo
$residenciais = [];
$comerciais = [];

if ($result && $result->num_rows > 0) {
    while ($row = $result->fetch_assoc()) {
        if ($row['tipo'] === 'Residencial') {
            $residenciais[] = $row;
        } else {
            $comerciais[] = $row;
        }
    }
}
?>
<!DOCTYPE html>
<html lang="pt-BR">
<head>
  <meta charset="UTF-8">
  <meta name="viewport" content="width=device-width, initial-scale=1.0">
  <title>Central de Condomínios - Administrador</title>
  <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.2/dist/css/bootstrap.min.css" rel="stylesheet">
  <link href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.5.0/css/all.min.css" rel="stylesheet">
  <link rel="stylesheet" href="/public/CSS/dshBoardCondominios.css">
</head>
<body>
  <div class="d-flex">
    <!-- Sidebar -->
    <nav class="sidebar p-3">
      <h4><i class="fas fa-shield-alt"></i> Painel Admin</h4>
      <ul class="nav flex-column">
        <li class="nav-item"><a href="/views/dashboards/dashBoardUsuarios.php"><i class="fas fa-user"></i> Usuários</a></li>
        <li class="nav-item"><a href="/views/dashboards/dashBoardAdmin.php" class="active"><i class="fas fa-building"></i> Condomínios</a></li>
      </ul>

      <div class="logo-container">
        <img src="/public/Image/img2.png" alt="Logo G&E Security">
      </div>
    </nav>

    <!-- Conteúdo Principal -->
    <div class="main-content w-100">
      <div class="d-flex justify-content-between align-items-center mb-4">
        <h2><i class="fas fa-building"></i> Central de Condomínios</h2>
      </div>

      <!-- Consulta de Condomínios -->
      <div class="card p-4 mb-5 shadow">
        <h5 class="mb-4 text-center text-dark"><i class="fas fa-search"></i> Consulta de Condomínios</h5>

        <div class="row g-4">
          <div class="col-md-6">
            <a href="javascript:void(0)" id="btnResidencial" class="clickable-card card-residencial text-center p-5 shadow">
              <i class="fas fa-home fa-3x mb-3"></i>
              <h6>Condomínios Residenciais</h6>
            </a>
          </div>

          <div class="col-md-6">
            <a href="javascript:void(0)" id="btnComercial" class="clickable-card card-comercial text-center p-5 shadow">
              <i class="fas fa-city fa-3x mb-3"></i>
              <h6>Condomínios Comerciais</h6>
            </a>
          </div>
        </div>
      </div>

      <!-- Lista de Condomínios Residenciais -->
      <div id="listaResidencial" class="card p-4 shadow mb-4" style="display:none;">
        <h5 class="mb-3 text-center text-dark"><i class="fas fa-list"></i> Condomínios Residenciais</h5>
        <div class="table-responsive">
          <table class="table table-dark table-striped table-hover align-middle text-center">
            <thead>
              <tr>
                <th>Nome</th>
                <th>Endereço</th>
                <th>Telefone</th>
                <th>CNPJ</th>
                <th>Data de Cadastro</th>
                <th>Ações</th>
              </tr>
            </thead>
            <tbody>
              <?php if (!empty($residenciais)): ?>
                <?php foreach ($residenciais as $cond): ?>
                  <tr>
                    <td><?= htmlspecialchars($cond['nome']) ?></td>
                    <td><?= htmlspecialchars($cond['endereco']) ?></td>
                    <td><?= htmlspecialchars($cond['telefone']) ?></td>
                    <td><?= htmlspecialchars($cond['cnpj']) ?></td>
                    <td><?= date('d/m/Y H:i', strtotime($cond['data_cadastro'])) ?></td>
                    <td>
                      <button class="btn btn-sm btn-warning"><i class="fas fa-search"></i></button>
                      <button class="btn btn-sm btn-danger"><i class="fas fa-trash"></i></button>
                    </td>
                  </tr>
                <?php endforeach; ?>
              <?php else: ?>
                <tr><td colspan="6" class="text-center text-light">Nenhum condomínio residencial cadastrado.</td></tr>
              <?php endif; ?>
            </tbody>
          </table>
        </div>
      </div>

      <!-- Lista de Condomínios Comerciais -->
      <div id="listaComercial" class="card p-4 shadow mb-4" style="display:none;">
        <h5 class="mb-3 text-center text-dark"><i class="fas fa-list"></i> Condomínios Comerciais</h5>
        <div class="table-responsive">
          <table class="table table-dark table-striped table-hover align-middle text-center">
            <thead>
              <tr>
                <th>Nome</th>
                <th>Endereço</th>
                <th>Telefone</th>
                <th>CNPJ</th>
                <th>Data de Cadastro</th>
                <th>Ações</th>
              </tr>
            </thead>
            <tbody>
              <?php if (!empty($comerciais)): ?>
                <?php foreach ($comerciais as $cond): ?>
                  <tr>
                    <td><?= htmlspecialchars($cond['nome']) ?></td>
                    <td><?= htmlspecialchars($cond['endereco']) ?></td>
                    <td><?= htmlspecialchars($cond['telefone']) ?></td>
                    <td><?= htmlspecialchars($cond['cnpj']) ?></td>
                    <td><?= date('d/m/Y H:i', strtotime($cond['data_cadastro'])) ?></td>
                    <td>
                      <button class="btn btn-sm btn-warning"><i class="fas fa-search"></i></button>
                      <button class="btn btn-sm btn-danger"><i class="fas fa-trash"></i></button>
                    </td>
                  </tr>
                <?php endforeach; ?>
              <?php else: ?>
                <tr><td colspan="6" class="text-center text-light">Nenhum condomínio comercial cadastrado.</td></tr>
              <?php endif; ?>
            </tbody>
          </table>
        </div>
      </div>
    </div>
  </div>

  <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.2/dist/js/bootstrap.bundle.min.js"></script>
  <script src="/public/JS/dashBoardCondominios.js"></script>
</body>
</html>