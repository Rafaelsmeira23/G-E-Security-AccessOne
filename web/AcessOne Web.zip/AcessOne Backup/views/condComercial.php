<!DOCTYPE html>
<html lang="pt-BR">
<head>
    <meta charset="UTF-8" />
    <meta name="viewport" content="width=device-width, initial-scale=1" />
    <title>Condomínio Comercial</title>
    <link rel="stylesheet" href="/public/CSS/residencialStyle.css" />
</head>
<body>

    <!-- Navegação entre os formulários -->
    <nav>
        <button onclick="mostrarFormulario('empresa-form')">Empresa</button>
        <button onclick="mostrarFormulario('visitante-form')">Visitante</button>
        <button onclick="mostrarFormulario('funcionario-form')">Funcionário</button>
        <button onclick="mostrarFormulario('veiculo-form')">Veículo</button>
        <button onclick="mostrarFormulario('encomenda-form')">Encomenda</button>
    </nav>

    <!-- Cadastro de Empresa -->
    <div class="form-section empresa-form hidden">
        <h3>Cadastro de Empresa</h3>
        <form method="POST" action="cadastrar_empresa.php">
            <label for="nome_empresa">Nome da Empresa:</label>
            <input type="text" name="nome_empresa" required />

            <label for="responsavel_empresa">Responsável:</label>
            <input type="text" name="responsavel_empresa" required />

            <label for="Conjunto_empresa">Conjunto:</label>
            <input type="text" name="Conjunto_empresa" required />

            <label for="cnpj_empresa">CNPJ:</label>
            <input type="text" name="cnpj_empresa" />

            <label for="telefone_empresa">Telefone:</label>
            <input type="text" name="telefone_empresa" placeholder="(XX) XXXX-XXXX" />

            <label for="email_empresa">Email:</label>
            <input type="email" name="email_empresa" />

            <label for="endereco_empresa">Endereço:</label>
            <input type="text" name="endereco_empresa" />

            <button type="submit">Cadastrar</button>
        </form>
    </div>

    <!-- Cadastro de Visitante -->
    <div class="form-section visitante-form hidden">
        <h3>Cadastro de Visitante</h3>
        <form method="POST" action="../../controllers/visitanteController.php">
            <label for="nome_visitante">Nome:</label>
            <input type="text" name="nome_visitante" required />

            <label for="tipo_documento_visitante">Tipo de Documento:</label>
            <select name="tipo_documento_visitante" required>
                <option value="">--Selecione--</option>
                <option value="CPF">CPF</option>
                <option value="RG">RG</option>
            </select>

            <label for="documento_visitante">Documento:</label>
            <input type="text" name="documento_visitante" required />

            <label for="data_visita">Data:</label>
            <input type="date" name="data_visita" />

            <label for="hora_visita">Hora:</label>
            <input type="time" name="hora_visita" />

            <!-- Andar e conjunto vinculados -->
            <label for="andar_visita">Andar:</label>
            <select id="andar_visita" name="andar_visita" required onchange="atualizarConjuntos()">
                <option value="">--Selecione o Andar--</option>
            </select>

            <label for="conjunto_visita">Conjunto/Sala:</label>
            <select id="conjunto_visita" name="conjunto_visita" required>
                <option value="">--Selecione o Conjunto/Sala--</option>
            </select>

            <!-- Captura imagem do visitante -->
            <label for="foto">Foto:</label>
            <input type="file" id="foto" name="foto" accept="image/*" required>

            <button type="submit">Cadastrar</button>
        </form>
    </div>

    <!-- Cadastro de Funcionário -->
    <div class="form-section funcionario-form hidden">
        <h3>Cadastro de Funcionário</h3>
        <form method="POST" action="cadastrar_funcionario.php">
            <label for="nome_funcionario">Nome:</label>
            <input type="text" name="nome_funcionario" required />

	    <label for="tipo_documento_funcionario">Tipo de Documento:</label>
            <select name="tipo_documento_funcionario" required>
                <option value="">--Selecione--</option>
                <option value="CPF">CPF</option>
                <option value="RG">RG</option>
            </select>

            <label for="documento_funcionario">Documento:</label>
            <input type="text" name="documento_funcionario" required />

            <label for="cargo">Cargo:</label>
            <input type="text" name="cargo" />

            <label for="nome_empresa">Empresa:</label>
            <input type="text" name="nome_empresa" required />

            <label for="telefone_funcionario">Telefone:</label>
            <input type="text" name="telefone_funcionario" />

            <!-- Captura imagem do funcionário -->
            <label for="foto">Foto:</label>
            <input type="file" id="foto" name="foto" accept="image/*" required>

            <button type="submit">Cadastrar</button>
        </form>
    </div>

    <!-- Cadastro de Veículo -->
    <div class="form-section veiculo-form hidden">
        <h3>Cadastro de Veículo</h3>
        <form method="POST" action="cadastrar_veiculo.php">
            <label for="proprietario">Proprietário:</label>
            <input type="text" name="proprietario" required />

            <label for="placa">Placa:</label>
            <input type="text" name="placa" required />

            <label for="marca">Marca:</label>
            <input type="text" name="marca" />

            <label for="modelo">Modelo:</label>
            <input type="text" name="modelo" />

            <label for="cor">Cor:</label>
            <input type="text" name="cor" />

            <button type="submit">Cadastrar</button>
        </form>
    </div>

    <!-- Cadastro de Encomenda -->
    <div class="form-section encomenda-form hidden">
        <h3>Cadastro de Encomenda</h3>
        <form method="POST" action="cadastrar_encomenda.php" enctype="multipart/form-data">
            <label for="nomeDestinatario">Nome do Destinatário:</label>
            <input type="text" name="nomeDestinatario" required />

            <label for="numeroApto">Número do Conjunto:</label>
            <input type="text" name="numeroApto" required />

            <label for="descricaoEncomenda">Descrição da Encomenda:</label>
            <input type="text" name="descricaoEncomenda" required />

            <label for="transportadora">Transportadora:</label>
            <input type="text" name="transportadora" />

            <label for="codigoRastreio">Código de Rastreio:</label>
            <input type="text" name="codigoRastreio" />

            <label for="dataRecebimento">Data de Recebimento:</label>
            <input type="date" name="dataRecebimento" required />

            <label for="recebidoPor">Recebido por (funcionário):</label>
            <input type="text" name="recebidoPor" required />

            <!-- Câmera para capturar foto -->
            <label for="foto">Foto da Encomenda:</label>
            <input type="file" id="foto" name="foto" accept="image/*" required>

            <button type="submit">Cadastrar</button>
        </form>
    </div>

    <!-- Script externo -->
    <script src="/public/JS/formScript.js"></script>

    <script>
        // Preenche automaticamente os andares no select com valores numéricos limpos (1, 2, 3...) e texto com 'º andar'
        const selectAndar = document.getElementById("andar_visita");
        for (let i = 1; i <= 100; i++) {
            const option = document.createElement("option");
            option.value = i; // valor numérico puro para facilitar cálculo
            option.textContent = `${i}º andar`;
            selectAndar.appendChild(option);
        }

        // Atualiza as opções de conjunto conforme o andar escolhido
        function atualizarConjuntos() {
            const andarStr = document.getElementById("andar_visita").value;
            const andar = parseInt(andarStr, 10); // força número inteiro base 10
            const conjuntoSelect = document.getElementById("conjunto_visita");

            // Reseta as opções do conjunto
            conjuntoSelect.innerHTML = '<option value="">--Selecione o Conjunto/Sala--</option>';

            if (!isNaN(andar)) {
                let inicio, fim;

                if (andar < 10) {
                    // Andares de 1 a 9: código = andar * 100 + 1 até andar * 100 + 10
                    inicio = andar * 100 + 1;
                    fim = andar * 100 + 10;
                } else {
                    // A partir do 10º andar, seguir mesma regra (exemplo: andar 10 => 1001 a 1010)
                    inicio = andar * 100 + 1;
                    fim = andar * 100 + 10;
                }

                for (let i = inicio; i <= fim; i++) {
                    const option = document.createElement("option");
                    option.value = i;
                    option.textContent = `Conjunto ${i}`;
                    conjuntoSelect.appendChild(option);
                }
            }
        }
    </script>
</body>
</html>