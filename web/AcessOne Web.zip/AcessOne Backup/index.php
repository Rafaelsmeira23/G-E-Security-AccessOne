<?php 
  session_start();
?>

<!DOCTYPE html>
<html lang="pt-br">
    <head>
      <meta charset="UTF-8" />
        <meta name="viewport" content="width=device-width, initial-scale=1.0" />
          <title>G&E Security</title>
          <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.5.0/css/all.min.css" />
          <link href="https://fonts.googleapis.com/css2?family=Poppins:wght@400;600&display=swap" rel="stylesheet" />
          <link rel="stylesheet" href="/public/CSS/mainStyle.css" />
    </head>
<body>
  <nav>
    <div class="container">
      <div class="logo">
        <a href="#">
          <img src="/public/Image/img2.png" alt="Logo G&E Security" />
        </a>
      </div>

      <ul>
        <?php if (isset($_SESSION['id_usuario']) && isset($_SESSION['nome'])): ?>
          <li><a href="/controllers/logout.php">Logout</a></li><br>
        <?php else: ?>
          <li><a href="/views/login.php">Login</a></li>
        <?php endif; ?>
      </ul>

      <!-- Redes Sociais -->
      <div class="social-icons">
        <a href="https://www.facebook.com/senaisp.pirituba/?locale=pt_BR" target="_blank"><i class="fab fa-facebook-f"></i></a>
        <a href="https://www.instagram.com/senai.sp/" target="_blank"><i class="fab fa-instagram"></i></a>
        <a href="https://x.com/senainacional" target="_blank"><i class="fab fa-twitter"></i></a>
      </div>
    </div>
  </nav>

  <!-- Banner -->
  <section class="banner">
    <img src="/public/Image/geesec.jpg" alt="Gee">
  </section>

  <!-- Cabeçalho -->
  <header>
    <div class="center">
      <section class="carousel-container">
        <div class="carousel">
          <button class="prev" onclick="mudarSlide(-1)">&#10094;</button>
          <img id="slide" src="/public/Image/foto1.jpg" alt="Imagem 1">
          <button class="next" onclick="mudarSlide(1)">&#10095;</button>
        </div>
        <div class="selectors"></div>
      </section>

      <div class="info-text">
        <h1>Quem Somos</h1>
        <div class="sobre-nós">
          <div class="texto">
            <p>
              A G&E Security é uma empresa inovadora no setor de segurança e
              tecnologia, especializada em soluções avançadas para controle de
              acesso, monitoramento e proteção patrimonial. Contamos com uma
              equipe altamente qualificada e utilizamos tecnologias de última
              geração para oferecer sistemas eficazes e adaptáveis a
              residências, comércios, indústrias e outros estabelecimentos.
              Nosso compromisso é garantir a proteção de bens, pessoas e
              informações sensíveis — proporcionando tranquilidade,
              confiabilidade e eficiência.
            </p>
          </div>
        </div>
      </div>
    </div>

    <div class="quem-somos-section">
      <div class="imagem-fundo"></div>
      <div class="quem-somos-texto">
        <h1>Diferenciais</h1>
        <p>
          Nosso grande diferencial está na união entre personalização e
          inovação. Desenvolvemos soluções sob medida com tecnologias como
          biometria, reconhecimento facial, inteligência artificial e sistemas
          integrados de controle de acesso. Um dos principais destaques da G&E
          Security é a integração entre o sistema de cadastro da portaria e o
          controle de estacionamento. Essa unificação elimina a necessidade de
          múltiplos sistemas e fornecedores, oferecendo uma solução
          centralizada que agiliza processos, reduz custos operacionais e
          aumenta a eficiência no controle de entradas e saídas. Além disso,
          nossas plataformas são escaláveis e inteligentes, adaptando-se ao
          ambiente e evoluindo conforme as necessidades de cada cliente.
          Estamos sempre à frente das demandas do mercado, entregando
          tecnologia de ponta com foco total em segurança e desempenho.
        </p>
      </div>
    </div>

    <div class="info-cards">
      <div class="card">
        <div class="card-title">Missão</div>
        <div class="card-text">
          <p>
            Proporcionar soluções inteligentes e eficazes que integrem
            segurança física e digital, com foco em excelência, inovação e
            suporte contínuo. Buscamos ser um parceiro estratégico que entrega
            mais do que proteção: entregamos confiança, tranquilidade e valor.
          </p>
        </div>
      </div>

      <div class="card">
        <div class="card-title">Visão</div>
        <div class="card-text">
          <p>
            Ser referência no mercado nacional de segurança e tecnologia,
            antecipando tendências e oferecendo soluções que evoluam junto com
            as necessidades dos nossos clientes. Queremos transformar a
            segurança tradicional em uma experiência mais tecnológica,
            conectada e eficiente.
          </p>
        </div>
      </div>

      <div class="card">
        <div class="card-title">Valores</div>
        <div class="card-text">
          <p>
            - Inovação contínua: Estamos sempre em busca de novas tecnologias
            para oferecer o melhor. <br />
            - Comprometimento com o cliente: Segurança com atendimento
            próximo, suporte dedicado e soluções personalizadas. <br />
            - Transparência: Todas as etapas dos nossos processos são claras,
            registradas e rastreáveis. <br />
            - Eficiência: Unimos tecnologia e inteligência operacional para
            otimizar recursos e gerar economia. <br />
            - Confiança: Construímos relações sólidas com nossos clientes,
            baseadas em resultados e responsabilidade.
          </p>
        </div>
      </div>
    </div>
  </header>

  <!-- Rodapé -->
  <footer>
    <p>&copy; 2025 G&E Security</p>
  </footer>

  <script src="/public/JS/imageScript.js"></script>
</body>
</html>