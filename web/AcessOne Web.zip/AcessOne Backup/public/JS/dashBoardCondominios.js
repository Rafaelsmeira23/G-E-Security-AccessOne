document.addEventListener("DOMContentLoaded", function () {
  const btnResidencial = document.getElementById("btnResidencial");
  const btnComercial = document.getElementById("btnComercial");
  const listaResidencial = document.getElementById("listaResidencial");
  const listaComercial = document.getElementById("listaComercial");

  btnResidencial.addEventListener("click", () => {
    listaResidencial.style.display = "block";
    listaComercial.style.display = "none";
  });

  btnComercial.addEventListener("click", () => {
    listaResidencial.style.display = "none";
    listaComercial.style.display = "block";
  });
});
