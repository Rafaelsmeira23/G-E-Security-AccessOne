function finalizarCadastro(event) {
    event.preventDefault(); // Impede o envio padrão do formulário

    const tipo = document.getElementById('tipo').value; // Obtém o tipo de condomínio
    let destino = '';

    if (tipo === 'Residencial') {
        destino = 'residencial.php';
    } else if (tipo === 'Comercial') {
        destino = 'comercial.php';
    } else {
        alert('Por favor, selecione um tipo de condomínio antes de continuar.');
        return;
    }

    window.location.href = destino; // Redireciona para a página correspondente
}
