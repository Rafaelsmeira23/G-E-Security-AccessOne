navigator.mediaDevices.getUserMedia({ video: true })
    .then((stream) => {
        document.querySelectorAll('.camera').forEach(camera => {
            const video = camera.querySelector('video');
            const canvas = camera.querySelector('canvas');
            const ctx = canvas.getContext('2d');
            const btnTirarFoto = camera.querySelector('.tirarFoto');
            const inputFile = camera.querySelector('.fotoUpload');

            video.srcObject = stream;

            btnTirarFoto.addEventListener('click', () => {
                canvas.width = video.videoWidth;
                canvas.height = video.videoHeight;

                ctx.drawImage(video, 0, 0, canvas.width, canvas.height);

                video.style.display = 'none';
                canvas.style.display = 'block';

                // Transforma o canvas em arquivo blob (imagem)
                canvas.toBlob(blob => {
                    const file = new File([blob], 'foto.png', { type: 'image/png' });

                    // Cria um DataTransfer para simular o input file
                    const dataTransfer = new DataTransfer();
                    dataTransfer.items.add(file);
                    inputFile.files = dataTransfer.files;
                }, 'image/png');
            });
        });
    })
    .catch((error) => {
        console.error('Erro ao acessar a câmera: ', error);
    });
