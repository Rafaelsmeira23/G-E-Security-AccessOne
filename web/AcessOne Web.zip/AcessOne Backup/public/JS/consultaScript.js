const conteudo = document.getElementById("conteudo-dinamico");
const tipoInput = document.getElementById("tipoConsulta");

function trocarAba(tipo) {
  tipoInput.value = tipo;

  // Muda estilo das abas
  const abas = document.querySelectorAll(".aba");
  abas.forEach(aba => aba.classList.remove("ativa"));
  document.querySelector(`.aba[onclick="trocarAba('${tipo}')"]`).classList.add("ativa");

  // Atualiza filtros de acordo com a aba
  let html = '';
  if (tipo === "morador") {
    html = `
      <label for="nome">Nome:</label>
      <input type="text" name="nome" placeholder="Digite o nome do morador">

      <label for="veiculo">Possui veículo?</label>
      <select name="veiculo">
        <option value="">Todos</option>
        <option value="sim">Sim</option>
        <option value="nao">Não</option>
      </select>
    `;
  } else if (tipo === "funcionario") {
    html = `
      <label for="nome">Nome:</label>
      <input type="text" name="nome" placeholder="Digite o nome do funcionário">

      <label for="funcao">Função:</label>
      <input type="text" name="funcao" placeholder="Ex: Limpeza, Porteiro...">
    `;
  } else if (tipo === "visitante") {
    html = `
      <label for="nome">Nome:</label>
      <input type="text" name="nome" placeholder="Digite o nome do visitante">

      <label for="dataVisita">Data da visita:</label>
      <input type="date" name="dataVisita">
    `;
  } else if (tipo === "encomenda") {
    html = `
      <label for="destinatario">Destinatário:</label>
      <input type="text" name="destinatario" placeholder="Nome do destinatário">
    `;
  }

  conteudo.innerHTML = html;
}

// Inicializa com a aba "morador"
trocarAba('morador');
