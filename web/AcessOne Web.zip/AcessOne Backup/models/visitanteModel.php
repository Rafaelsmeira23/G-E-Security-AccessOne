<?php 
require_once '../models/conectaBD.php'; 

class VisitanteModel { 
    private $conn; public function __construct() { 
        $this->conn = getConexao(); 
    } 
    
    public function inserir($dados) { 
        $stmt = $this->conn->prepare("INSERT INTO cad_usuario ( id_condominio, email, tipo_usuario, tipo_visitante, nome, url_foto, documento, telefone, empresa, cargo, bloco_torre, apartamento, observacoes ) 
        VALUES (?, ?, 'Visitante', ?, ?, ?, ?, ?, ?, ?, ?, ?, ?)"); 

        if (!$stmt) { 
            die("Erro ao preparar statement: " . $this->conn->error); 
        }
         $stmt->bind_param("isssssssssss", 
         $dados['id_condominio'], 
         $dados['email'], 
         $dados['tipo_visitante'], 
         $dados['nome'], 
         $dados['url_foto'], 
         $dados['documento'], 
         $dados['telefone'], 
         $dados['empresa'], 
         $dados['cargo'], 
         $dados['bloco_torre'], 
         $dados['apartamento'], 
         $dados['observacoes'] ); 
         return $stmt->execute(); 
        } 
    }