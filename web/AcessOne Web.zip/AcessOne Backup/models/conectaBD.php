<?php
function getConexao() { //Função que faz a conexão com o banco de dados
    $host = 'localhost';
    $usuario = 'root';
    $senha = ''; 
    $banco = 'sistema_GE';

    $conn = new mysqli($host, $usuario, $senha, $banco);

    if ($conn->connect_error) {
        die("Erro de conexão com o banco: " . $conn->connect_error);
    }

    $conn->set_charset("utf8mb4");

    return $conn;
}
