<?php
require_once '../models/conectaBD.php';

class VeiculoModel {
    private $conn;

    public function __construct() {
        $this->conn = getConexao();
    }

    public function inserir($dados) {
        $stmt = $this->conn->prepare(
            "INSERT INTO cad_veiculo (id_usuario, placa, marca, modelo, cor, vaga_idoso)
             VALUES (?, ?, ?, ?, ?, ?)"
        );

        if (!$stmt) {
            die("Erro ao preparar statement: " . $this->conn->error);
        }

        // Garante que vaga_idoso vem como 0 ou 1
        $vaga_idoso = isset($dados['vaga_idoso']) ? (int) $dados['vaga_idoso'] : 0;

        $stmt->bind_param("issssi",
            $dados['id_usuario'],   // ID do morador/usuário dono do veículo
            $dados['placa'],
            $dados['marca'],
            $dados['modelo'],
            $dados['cor'],
            $vaga_idoso
        );

        if (!$stmt->execute()) {
            echo "Erro ao inserir veículo: " . $stmt->error;
            return false;
        }

        $stmt->close();
        return true;
    }
}
