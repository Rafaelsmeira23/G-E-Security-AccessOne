<?php
require_once '../models/conectaBD.php';

class ZeladorModel {
    private $conn;

    // Construtor que inicializa a conexão com o banco de dados
    public function __construct() {
        $this->conn = getConexao();
    }

    // Método para inserir um novo zelador na tabela cad_usuario
    public function inserir($dados) {
        // Gera o hash MD5 da senha enviada no array $dados
        $senha_hash = md5($dados['senha']);

        // Prepara a query SQL para inserir os dados do zelador
        $stmt = $this->conn->prepare("INSERT INTO cad_usuario (id_condominio, nome, documento, url_foto, email, senha_hash, empresa, tipo_usuario) VALUES (?, ?, ?, ?, ?, ?, ?, 'Zelador')");

        // Verifica se a preparação da query foi bem-sucedida
        if (!$stmt) {
            die("Erro ao preparar statement: " . $this->conn->error);
        }

        // Vincula os parâmetros da query com os dados recebidos
        // "i" para integer, "s" para string
        $stmt->bind_param("issssss",
            $dados['id_condominio'],  // ID do condomínio
            $dados['nome'],           // Nome do zelador
            $dados['documento'],      // Documento do zelador
            $dados['url_foto'],       // URL da foto
            $dados['email'],          // Email do zelador
            $senha_hash,              // Senha criptografada
            $dados['empresa']         // Empresa associada ao zelador
        );

        // Executa o statement e retorna true se sucesso ou false caso contrário
        if ($stmt->execute()) {
            return true;
        } else {
            // Exibe erro caso haja falha na inserção
            echo "Erro ao inserir: " . $stmt->error;
            return false;
        }
    }
}