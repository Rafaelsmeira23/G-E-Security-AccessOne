<?php
require_once '../models/conectaBD.php';

class EncomendaModel {
    private $conn;

    // Construtor que inicializa a conexão com o banco de dados
    public function __construct() {
        $this->conn = getConexao();
    }

    // Método para inserir uma nova encomenda na tabela 'cad_encomenda'
    public function inserir($dados) {
        $stmt = $this->conn->prepare("INSERT INTO cad_encomenda 
            (id_condominio, id_usuario, url_foto, descricao, codigo_rastreamento, status, data_prevista_entrega, status_encomenda, observacoes)
            VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?)");

        if (!$stmt) {
            // Exibe erro e encerra a execução se falha na preparação do statement
            die("Erro: " . $this->conn->error);
        }

        // Vincula os parâmetros recebidos ao statement SQL com seus respectivos tipos
        $stmt->bind_param("iisssssss",
            $dados['id_condominio'],          // inteiro
            $dados['id_usuario'],              // inteiro
            $dados['url_foto'],                // string (URL da foto)
            $dados['descricao'],               // string (descrição da encomenda)
            $dados['codigo_rastreamento'],    // string (código de rastreamento)
            $dados['status'],                  // string (status atual)
            $dados['data_prevista_entrega'],  // string (data prevista para entrega)
            $dados['status_encomenda'],        // string (status da encomenda, possivelmente duplicado ou campo específico)
            $dados['observacoes']              // string (observações adicionais)
        );

        // Executa o statement e retorna true se sucesso, false caso contrário
        return $stmt->execute();
    }
}