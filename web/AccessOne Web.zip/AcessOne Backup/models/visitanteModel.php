<?php 
require_once '../models/conectaBD.php'; 

class VisitanteModel {

    private $conn; 

    public function __construct() { 
        $this->conn = getConexao(); 
    } 
    
    public function inserir($dados) { 

        $stmt = $this->conn->prepare("
    INSERT INTO cad_usuario 
    (id_condominio, tipo_usuario, tipo_visitante, nome, url_foto, documento,
     empresa, bloco_torre, apartamento, observacoes)
    VALUES (?, 'Visitante', ?, ?, ?, ?, ?, ?, ?, ?)
");

$stmt->bind_param(
    "issssssss",
    $dados['id_condominio'],
    $dados['tipo_visitante'],
    $dados['nome'],
    $dados['url_foto'],
    $dados['documento'],
    $dados['empresa'],       // conjunto no comercial
    $dados['bloco_torre'],   // residencial
    $dados['apartamento'],   // residencial
    $dados['observacoes']
);

        return $stmt->execute(); 
    } 
}
