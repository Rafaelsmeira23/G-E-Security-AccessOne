<?php require_once '../models/conectaBD.php'; 

class PorteiroModel { 
    private $conn; 

    // Construtor que obtém a conexão com o banco de dados
    public function __construct() { 
        $this->conn = getConexao(); 
    } 
    
    // Método para inserir um novo porteiro na tabela cad_usuario
    public function inserir($dados) { 
        // Criptografa a senha recebida usando md5 antes de armazenar
        $senha_hash = md5($dados['senha']); 

        // Prepara a query SQL para inserção dos dados do porteiro, fixando tipo_usuario como 'Porteiro'
        $stmt = $this->conn->prepare("INSERT INTO cad_usuario (id_condominio, nome, documento, url_foto, email, empresa, senha_hash, tipo_usuario) VALUES (?, ?, ?, ?, ?, ?, ?, 'Porteiro')"); 
        
        // Verifica se o statement foi preparado corretamente, caso contrário interrompe com mensagem de erro
        if (!$stmt) { 
            die("Erro ao preparar statement: " . $this->conn->error); 
        }

        // Vincula os parâmetros recebidos ao statement
        $stmt->bind_param("issssss", 
            $dados['id_condominio'],  // inteiro (ID do condomínio)
            $dados['nome'],           // string
            $dados['documento'],      // string
            $dados['url_foto'],       // string (endereço URL da foto)
            $dados['email'],          // string (e-mail)
            $dados['empresa'],        // string (Empresa associada ao Porteiro)
            $senha_hash               // string (Senha criptografada padrão MD5)
        );

        // Executa o statement e retorna true se a inserção foi bem-sucedida, caso contrário exibe erro e retorna false
        if ($stmt->execute()) { 
            return true; 
        } else { 
            echo "Erro ao inserir: " . $stmt->error; 
            return false; 
        } 
    } 
}