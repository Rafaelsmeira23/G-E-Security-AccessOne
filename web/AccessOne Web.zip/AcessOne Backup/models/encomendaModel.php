<?php
require_once '../models/conectaBD.php';

class EncomendaModel {
    private $conn;

    public function __construct() {
        $this->conn = getConexao();
    }

    public function inserir($dados) {

        $stmt = $this->conn->prepare("
            INSERT INTO cad_encomenda 
            (id_condominio, id_usuario, url_foto, descricao, codigo_rastreamento, status)
            VALUES (?, ?, ?, ?, ?, ?)
        ");

        if (!$stmt) {
            die("Erro ao preparar statement: " . $this->conn->error);
        }

        // Tipos: i (int), i (int), s, s, s, s, s
        $stmt->bind_param(
            "iissss",
            $dados['id_condominio'],
            $dados['id_usuario'],
            $dados['url_foto'],
            $dados['descricao'],
            $dados['codigo_rastreamento'],
            $dados['status'],
        );

        return $stmt->execute();
    }
}
