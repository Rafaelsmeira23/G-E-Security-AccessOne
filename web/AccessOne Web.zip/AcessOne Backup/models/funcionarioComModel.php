<?php
require_once '../models/conectaBD.php';

class FuncionarioModel {
    private $conn;

    public function __construct() {
        $this->conn = getConexao();
    }

    public function inserir($dados) {
        $stmt = $this->conn->prepare("
            INSERT INTO cad_usuario (id_condominio, tipo_usuario, nome, url_foto, documento, empresa, observacoes)
            VALUES (?, 'Funcionario_Com', ?, ?, ?, ?, ?)
        ");

        if (!$stmt) {
            die("Erro ao preparar statement: " . $this->conn->error);
        }

        $stmt->bind_param("isssss",
            $dados['id_condominio'],
            $dados['nome'],
            $dados['url_foto'],
            $dados['documento'],
            $dados['empresa'],
            $dados['observacoes']
        );

        return $stmt->execute();
    }
}
