<?php
require_once '../models/conectaBD.php';

class CondominioModel {
    private $conn;

    // Construtor que inicializa a conexão com o banco de dados
    public function __construct() {
        $this->conn = getConexao();
    }

    // Método para listar todos os condomínios da tabela 'cad_condominio'
    public function listarTodos() {
        $sql = "SELECT * FROM cad_condominio";
        return $this->conn->query($sql);
    }

    // Método para buscar um condomínio específico pelo seu ID
    public function buscarPorId($id) {
        $stmt = $this->conn->prepare("SELECT * FROM cad_condominio WHERE id_condominio = ?");
        $stmt->bind_param("i", $id);
        $stmt->execute();
        // Retorna o resultado como um array associativo
        return $stmt->get_result()->fetch_assoc();
    }

    // Método para inserir um novo condomínio no banco de dados
    public function inserir($dados) {
        $stmt = $this->conn->prepare("INSERT INTO cad_condominio (nome, tipo, endereco, cep, telefone, cnpj) VALUES (?, ?, ?, ?, ?, ?)");

        if (!$stmt) {
            // Em caso de erro na preparação do statement, exibe mensagem e encerra execução
            die("Erro ao preparar statement: " . $this->conn->error);
        }

        // Vincula os parâmetros recebidos ao statement SQL
        $stmt->bind_param("ssssss",
            $dados['nome'],
            $dados['tipo'],
            $dados['endereco'],
            $dados['cep'],
            $dados['telefone'],
            $dados['cnpj']
        );

        // Executa o statement e retorna true se sucesso, senão exibe erro e retorna false
        if ($stmt->execute()) {
            return true;
        } else {
            // Exibe o erro ocorrido durante a inserção (ex: duplicidade de dados)
            echo "Erro ao inserir: " . $stmt->error;
            return false;
        }
    }
}