<?php
require_once '../models/conectaBD.php';

class UsuarioModel {
    private $conn;

    // Construtor que obtém a conexão com o banco de dados
    public function __construct() {
        $this->conn = getConexao();
    }

    // Método para buscar um usuário pelo e-mail no banco de dados
    public function buscarPorEmail($email) {
        $stmt = $this->conn->prepare("SELECT * FROM cad_usuario WHERE email = ?");
        $stmt->bind_param("s", $email); // Vincula o parâmetro do tipo string
        $stmt->execute();
        return $stmt->get_result()->fetch_assoc(); // Retorna os dados do usuário como array associativo
    }

    // Método para inserir um novo usuário com e-mail, senha e tipo
    public function inserirUsuario($email, $senha, $tipo) {
        $senhaHash = md5($senha); // Criptografa a senha usando md5
        $stmt = $this->conn->prepare("INSERT INTO cad_usuario (email, senha_hash, tipo_usuario) VALUES (?, ?, ?)");
        $stmt->bind_param("sss", $email, $senhaHash, $tipo); // Vincula os parâmetros como strings
        return $stmt->execute(); // Executa o statement e retorna o resultado (true ou false)
    }
}