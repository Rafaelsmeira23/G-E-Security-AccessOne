<?php
require_once '../models/conectaBD.php';

class MoradorModel {
    private $conn;

    // Construtor que obtém a conexão com o banco de dados
    public function __construct() {
        $this->conn = getConexao();
    }

    // Método para inserir um novo morador na tabela cad_usuario
    public function inserir($dados) {
        // Prepara a query SQL para inserção dos dados do morador
        $stmt = $this->conn->prepare("INSERT INTO cad_usuario 
            (id_condominio, nome, documento, telefone, url_foto, email, tipo_usuario, bloco_torre, apartamento, vinculo_apartamento) 
            VALUES (?, ?, ?, ?, ?, ?, 'Morador', ?, ?, ?)");

        // Verifica se a preparação falhou
        if (!$stmt) {
            die("Erro ao preparar statement: " . $this->conn->error);
        }

        // Se documento estiver vazio, usa NULL
        $documento = !empty($dados['documento']) ? $dados['documento'] : null;

        // Associa os valores aos placeholders da query
        $stmt->bind_param(
            "issssssss",
            $dados['id_condominio'],
            $dados['nome'],
            $documento,
            $dados['telefone'],
            $dados['url_foto'],
            $dados['email'],
            $dados['bloco_torre'],
            $dados['apartamento'],
            $dados['vinculo_apartamento']
        );

        // Executa e retorna true se sucesso, ou false e mensagem de erro
        if ($stmt->execute()) {
            return true;
        } else {
            echo "Erro ao inserir morador: " . $stmt->error;
            return false;
        }
    }
}
