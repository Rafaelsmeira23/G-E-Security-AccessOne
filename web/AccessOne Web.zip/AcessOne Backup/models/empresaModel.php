<?php
require_once '../models/conectaBD.php';

class EmpresaModel {
    private $conn;

    public function __construct() {
        $this->conn = getConexao();
    }

    public function inserir($dados) {
        // Insere empresa na tabela cad_usuario com tipo_usuario = 'Funcionario' ou um novo tipo 'Empresa'
        $stmt = $this->conn->prepare("
            INSERT INTO cad_usuario 
            (id_condominio, nome, empresa, bloco_torre, apartamento, conjunto, documento, telefone, email, tipo_usuario)
            VALUES (?, ?, ?, NULL, NULL, ?, ?, ?, ?, 'Empresa')
        ");

        if (!$stmt) {
            die('Erro ao preparar statement: ' . $this->conn->error);
        }

        // bind_param: i (int), s (string)
        $stmt->bind_param(
            "issssss",
            $dados['id_condominio'],
            $dados['nome'],
            $dados['empresa'],
            $dados['conjunto'],
            $dados['cnpj'],
            $dados['telefone'],
            $dados['email']
        );

        if ($stmt->execute()) {
            return true;
        } else {
            echo "Erro ao inserir empresa: " . $stmt->error;
            return false;
        }
    }
}
?>
