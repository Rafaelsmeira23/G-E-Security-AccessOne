<?php
require_once '../models/conectaBD.php';

class LoginModel {
    private $conn;

    // Recebe a conexão com o banco ao construir a instância
    public function __construct($conn) {
        $this->conn = $conn;
    }

    // Método para autenticar o usuário com email e senha
    public function autenticar($email, $senha) {
        // Gera o hash MD5 da senha fornecida para comparação segura
        $senha_hash = md5($senha);

        // Query SQL que faz join entre usuário e condomínio para obter também o tipo de condomínio
        $sql = "SELECT u.*, c.tipo AS tipo_condominio FROM cad_usuario u
            LEFT JOIN cad_condominio c ON u.id_condominio = c.id_condominio
            WHERE u.email = ? AND u.senha_hash = ?";

        // Prepara a query para evitar SQL Injection
        $stmt = $this->conn->prepare($sql);

        // Caso a preparação falhe, exibe erro e encerra
        if (!$stmt) {
            die("Erro na preparação da query: " . $this->conn->error);
        }

        // Vincula os parâmetros de email e senha hash à query
        $stmt->bind_param("ss", $email, $senha_hash);
        $stmt->execute();

        // Obtém o resultado da query
        $result = $stmt->get_result();

        // Se encontrar exatamente um usuário com esses dados, retorna os dados do usuário (array associativo)
        if ($result->num_rows === 1) {
            return $result->fetch_assoc(); 
        }

        // Caso não encontre usuário, retorna null
        return null;
    }
}
?>