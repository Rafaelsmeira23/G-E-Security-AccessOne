<?php
require_once 'conectaBD.php';

class ConjuntoModel {
    private $conn;

    public function __construct() {
        $this->conn = getConexao();
    }

    public function buscarConjuntosPorCondominio($idCondominio) {
        $sql = "SELECT conjunto_empresa AS conjunto, nome_empresa 
                FROM cad_empresa 
                WHERE id_condominio = ?";

        $stmt = $this->conn->prepare($sql);
        $stmt->bind_param("i", $idCondominio);
        $stmt->execute();

        return $stmt->get_result();
    }
}
    