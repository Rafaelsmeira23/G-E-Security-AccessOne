const imagens = [
            "/public/Image/foto1.jpg",
            "/public/Image/foto2.png",
            "/public/Image/foto4.jpg",
            "/public/Image/foto5.jpg",
            "/public/Image/foto6.jpg",
            "/public/Image/foto7.jpg",
            "/public/Image/foto8.jpg",
            "/public/Image/foto9.jpg",
            "/public/Image/foto10.jpg",
            "/public/Image/foto11.png"
        ];
    
        let index = 0;
        let autoSlideInterval;
    
        function atualizarSlide() {
            const slide = document.getElementById("slide");
            slide.style.opacity = 0;
    
            setTimeout(() => {
                slide.src = imagens[index];
                slide.style.opacity = 1;
            }, 200);
    
            document.querySelectorAll(".selector").forEach((btn, i) => {
                btn.style.background = i === index ? "#ffcc00" : "#fff";
            });
        }
    
        function mudarSlide(n) {
            index = (index + n + imagens.length) % imagens.length;
            atualizarSlide();
            resetarAutoSlide();
        }
    
        function selecionarSlide(n) {
            index = n;
            atualizarSlide();
            resetarAutoSlide();
        }
    
        function iniciarAutoSlide() {
            autoSlideInterval = setInterval(() => {
                mudarSlide(1);
            }, 3500); // troca a cada 5 segundos
        }
    
        function resetarAutoSlide() {
            clearInterval(autoSlideInterval);
            iniciarAutoSlide();
        }
    
        // Inicializa os botões de seleção, caso ainda não tenha isso no HTML
        const container = document.querySelector(".selectors");
        imagens.forEach((_, i) => {
            const btn = document.createElement("button");
            btn.className = "selector";
            btn.onclick = () => selecionarSlide(i);
            container.appendChild(btn);
        });
    
        atualizarSlide();
        iniciarAutoSlide(); // Inicia o carrossel automático