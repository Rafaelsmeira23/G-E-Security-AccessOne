function mostrarFormularios() {
    const tipo = document.getElementById('tipo').value;

    // Obtenha os elementos dos formulários
    const formResidencial = document.getElementById('formResidencial');
    const formComercial = document.getElementById('formComercial');
    const formVisitante = document.getElementById('formVisitante');
    const formFuncionario = document.getElementById('formFuncionario');
    const formVeiculo = document.getElementById('formVeiculo');
    const navegacao = document.getElementById('navegacao');
    const mensagemSucesso = document.getElementById('mensagemSucesso');

    // Inicialmente, esconda todos os formulários e a navegação
    formResidencial.classList.add('hidden');
    formComercial.classList.add('hidden');
    formVisitante.classList.add('hidden');
    formFuncionario.classList.add('hidden');
    formVeiculo.classList.add('hidden');
    navegacao.classList.add('hidden');
    mensagemSucesso.classList.add('hidden'); // Esconde a mensagem de sucesso

    // Limpar os botões de navegação antes de adicionar novos
    navegacao.innerHTML = '';

    // Exibir o formulário de cadastro de condomínio
    // Você pode querer exibir o formulário inicial do condomínio aqui, se necessário
}

function voltarParaPaginaInicial() {
    window.location.href = 'cadCondominio.php';  // Substitua 'index.html' pela URL desejada
}


function mostrarMensagemSucesso() {
    // Esconde o formulário de cadastro de condomínio após a conclusão
    document.getElementById('formCondominio').classList.add('hidden');

    // Exibe a mensagem de sucesso
    const mensagemSucesso = document.getElementById('mensagemSucesso');
    mensagemSucesso.classList.remove('hidden');

    // Rolagem suave para a mensagem de sucesso
    window.scrollTo({
        top: mensagemSucesso.offsetTop - 20,
        behavior: 'smooth'
    });

    // Agora, exiba os formulários e navegação baseados no tipo selecionado
    const tipo = document.getElementById('tipo').value;

    const navegacao = document.getElementById('navegacao');

    // Verifica o tipo selecionado e mostra os formulários correspondentes
    if (tipo === 'Residencial') {
        navegacao.classList.remove('hidden');
        navegacao.innerHTML = `
            <button onclick="trocarFormulario('formResidencial')">Cadastro de Morador</button>
            <button onclick="trocarFormulario('formVisitante')">Cadastro de Visitante</button>
            <button onclick="trocarFormulario('formFuncionario')">Cadastro de Funcionário</button>
            <button onclick="trocarFormulario('formVeiculo')">Cadastro de Veículo</button>
        `;
        document.getElementById('formResidencial').classList.remove('hidden');
    } else if (tipo === 'Comercial') {
        navegacao.classList.remove('hidden');
        navegacao.innerHTML = `
            <button onclick="trocarFormulario('formComercial')">Cadastro de Empresa</button>
            <button onclick="trocarFormulario('formVisitante')">Cadastro de Visitante</button>
            <button onclick="trocarFormulario('formFuncionario')">Cadastro de Funcionário</button>
            <button onclick="trocarFormulario('formVeiculo')">Cadastro de Veículo</button>
        `;
        document.getElementById('formComercial').classList.remove('hidden');
    }
}

// Função para trocar o formulário exibido
function trocarFormulario(formId) {
    const formulários = ['formResidencial', 'formComercial', 'formVisitante', 'formFuncionario', 'formVeiculo'];
    formulários.forEach(function (id) {
        const form = document.getElementById(id);
        if (form.id !== formId) {
            form.classList.add('hidden');
        } else {
            form.classList.remove('hidden');
        }
    });
}

// Adicionar evento de sucesso na submissão do formulário
document.getElementById('formCondominio').addEventListener('submit', function (event) {
    event.preventDefault(); // Evitar a submissão padrão do formulário

    // Simulação de sucesso, adicione sua lógica de cadastro aqui
    setTimeout(function () {
        mostrarMensagemSucesso();
    }, 1000); // Atraso de 1 segundo antes de mostrar a mensagem de sucesso
});
