function mostrarFormulario(id) {
    // Seleciona todos os formulários com a classe 'form-section'
    let formularios = document.querySelectorAll('.form-section');
    // Adiciona a classe 'hidden' a todos os formulários
    formularios.forEach(form => form.classList.add('hidden'));
    // Seleciona o formulário com a classe correspondente ao 'id' passado
    document.querySelector('.' + id).classList.remove('hidden');
}
