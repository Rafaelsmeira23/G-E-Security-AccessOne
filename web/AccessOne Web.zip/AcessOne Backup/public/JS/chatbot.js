const openBtn = document.getElementById("chatbot-open");
const closeBtn = document.getElementById("chatbot-close");
const box = document.getElementById("chatbot-box");
const form = document.getElementById("chatbot-form");
const input = document.getElementById("chatbot-input");
const messages = document.getElementById("chatbot-messages");

openBtn.onclick = () => box.classList.remove("closed");
closeBtn.onclick = () => box.classList.add("closed");

function addMessage(text, sender) {
    const div = document.createElement("div");
    div.classList.add("message", sender);
    div.textContent = text;
    messages.appendChild(div);
    messages.scrollTop = messages.scrollHeight;
}

form.addEventListener("submit", (e) => {
    e.preventDefault();
    const text = input.value.trim();
    if (!text) return;

    addMessage(text, "user");
    input.value = "";

    setTimeout(() => {
        const reply = responder(text);
        addMessage(reply, "bot");
    }, 500);
});


/* ------------------------------
   INTELIGÊNCIA — 16 RESPOSTAS
--------------------------------*/

function responder(msg) {
    msg = msg.toLowerCase();

    const faq = [
        {
            q: ["login", "entrar", "acessar sistema"],
            a: "Para acessar o AccessOne, clique em Login no topo da página e informe seu usuário e senha."
        },
        {
            q: ["cadastro", "registrar", "novo usuário"],
            a: "O cadastro é realizado pela administração através do módulo interno do AccessOne."
        },
        {
            q: ["portaria", "visitante", "visita"],
            a: "O AccessOne registra visitantes, horários, documentos e permissões, mantendo histórico completo."
        },
        {
            q: ["estacionamento", "vaga", "veiculo"],
            a: "O módulo de estacionamento controla placas autorizadas, horários e registros automáticos."
        },
        {
            q: ["empresa", "quem são", "sobre", "quem somos"],
            a: "A G&E Security é responsável pelo AccessOne, uma plataforma moderna de controle de acesso e gestão integrada."
        },
        {
            q: ["segurança", "proteção"],
            a: "O AccessOne utiliza processos auditáveis, logs completos e autenticação segura."
        },
        {
            q: ["morador", "condômino", "usuario"],
            a: "O sistema gerencia perfis de moradores, níveis de permissão e acessos específicos."
        },
        {
            q: ["relatorio", "exportar", "dados"],
            a: "O AccessOne permite gerar relatórios de visitantes, portaria, veículos e ocorrências."
        },
        {
            q: ["controle de acesso", "acesso", "entrada"],
            a: "O AccessOne centraliza todos os acessos, portaria, estacionamento e visitantes em tempo real."
        },
        {
            q: ["administração", "gestão", "painel"],
            a: "Administradores têm um painel completo para visualizar acessos, editar dados e acompanhar movimentações."
        },
        {
            q: ["limitação", "distribuidora", "mercado livre", "shopee", "entrega"],
            a: "O AccessOne não possui limitações quanto às distribuidoras. Mercado Livre, Shopee, Amazon e outras podem ser registradas normalmente como entregadores."
        },
        {
            q: ["despacho", "encomenda", "entrega interna"],
            a: "O despacho das encomendas é registrado pela portaria no AccessOne, vinculando morador/gestor, data e responsável pela retirada."
        },
        {
            q: ["multiplos dispositivos", "celular", "acesso remoto"],
            a: "O AccessOne pode ser acessado de diferentes dispositivos autorizados, mantendo segurança e logs."
        },
        {
            q: ["problema", "erro", "bug"],
            a: "Caso encontre algum problema, entre em contato com a administração ou equipe técnica responsável pelo sistema."
        },
        {
            q: ["horário", "funcionamento", "suporte"],
            a: "O AccessOne funciona 24h, e o suporte depende da estrutura do cliente/condomínio."
        },
        {
            q: ["chamado", "suporte", "abrir chamado", "atendimento"],
            a: "A abertura de chamados no AccessOne é feita pelo módulo de Chamados. O usuário descreve o problema, registra o local da ocorrência, e o sistema redireciona para a zeladoria."
        }
    ];

    for (let item of faq) {
        if (item.q.some(keyword => msg.includes(keyword))) {
            return item.a;
        }
    }

    return "Não consegui entender muito bem 😅 — tente perguntar de outra forma!";
}