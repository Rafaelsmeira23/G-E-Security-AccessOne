DROP DATABASE IF EXISTS sistema_GE;
CREATE DATABASE IF NOT EXISTS sistema_GE;
USE sistema_GE;

CREATE TABLE cad_condominio (
    id_condominio INT AUTO_INCREMENT PRIMARY KEY,
    nome VARCHAR(100) NOT NULL UNIQUE,
    tipo ENUM('Residencial', 'Comercial') NOT NULL,
    endereco VARCHAR(100) NOT NULL UNIQUE,
    cep VARCHAR(9) NOT NULL,
    telefone VARCHAR(20) NOT NULL UNIQUE,
    cnpj VARCHAR(20) NOT NULL UNIQUE,
    data_cadastro TIMESTAMP DEFAULT CURRENT_TIMESTAMP
);

INSERT INTO cad_condominio (id_condominio, nome, tipo, endereco, cep, telefone, cnpj)
VALUES (1, 'Village People', 'Residencial', 'R.Frei Caneca, 5623 - Consolação', '01307-003', '(11) 98733-0537', '02.786.972/0001-89');

CREATE TABLE cad_usuario (
    id_usuario INT AUTO_INCREMENT PRIMARY KEY,
    id_condominio INT,
    email VARCHAR(200) UNIQUE,
    senha_hash VARCHAR(255),
    tipo_usuario ENUM('Administrador', 'Zelador', 'Porteiro', 'Morador', 'Visitante', 'Funcionario', 'Funcionario_Com', 'Empresa') NOT NULL,
    tipo_visitante ENUM('Nenhum', 'Familiar', 'Conhecido', 'Cliente', 'Prestador de Servico', 'Outros') NOT NULL DEFAULT 'Nenhum',
    nome VARCHAR(50),
    url_foto VARCHAR(255),
    documento VARCHAR(20) UNIQUE,
    telefone VARCHAR(20) NULL,
    empresa VARCHAR(50),
    cargo VARCHAR(50),
    bloco_torre VARCHAR (2),
    apartamento VARCHAR(4),
    vinculo_apartamento VARCHAR(20),
    conjunto VARCHAR(4),
    observacoes TEXT,
    data_cadastro TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    FOREIGN KEY (id_condominio) REFERENCES cad_condominio(id_condominio) ON DELETE CASCADE ON UPDATE CASCADE    
);

INSERT INTO cad_usuario (id_condominio, email, senha_hash, tipo_usuario, nome, url_foto)
VALUES (1, 'admin@gmail.com', MD5('s3nh4Adm1N'), 'Administrador', 'Administrador Geral', '/public/uploads/adminPhoto.jpg');

CREATE TABLE cad_veiculo (
    id_veiculo INT AUTO_INCREMENT PRIMARY KEY,
    id_usuario INT, 
    placa VARCHAR(11) NOT NULL UNIQUE,
    marca VARCHAR(30) NOT NULL,
    modelo VARCHAR(30) NOT NULL,
    cor VARCHAR(30) NOT NULL,
    data_cadastro TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    FOREIGN KEY (id_usuario) REFERENCES cad_usuario(id_usuario) ON DELETE SET NULL ON UPDATE CASCADE
);

CREATE TABLE cad_encomenda (
    id_encomenda INT AUTO_INCREMENT PRIMARY KEY,
    id_condominio INT NOT NULL,
    id_usuario INT NULL,
    url_foto VARCHAR(255) NOT NULL,
    descricao VARCHAR(255) NOT NULL,
    codigo_rastreamento VARCHAR(50) UNIQUE,
    status ENUM('Aguardando', 'Recebida na Portaria', 'Retirada pelo Destinatario') DEFAULT 'Aguardando' NOT NULL,
    observacoes TEXT,
    data_recebimento TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    FOREIGN KEY (id_condominio) REFERENCES cad_condominio(id_condominio) ON DELETE CASCADE ON UPDATE CASCADE,
    FOREIGN KEY (id_usuario) REFERENCES cad_usuario(id_usuario) ON DELETE SET NULL ON UPDATE CASCADE
);

/* CREATE TABLE cad_reserva (
    id_reserva INT AUTO_INCREMENT PRIMARY KEY,
    id_usuario INT NOT NULL,
    id_condominio INT NOT NULL,
    area ENUM('Churrasqueira', 'Piscina', 'Brinquedoteca', 'Salao de Festas', 'Area Pet', 'Lavanderia', 'Academia', 'Auditorio', 'Sala de Reuniao') NOT NULL,
    data_reserva DATE NOT NULL,
    horario_inicio TIME NOT NULL,
    horario_fim TIME NOT NULL,
    FOREIGN KEY (id_usuario) REFERENCES cad_usuario(id_usuario) ON DELETE CASCADE ON UPDATE CASCADE,
    FOREIGN KEY (id_condominio) REFERENCES cad_condominio(id_condominio) ON DELETE CASCADE ON UPDATE CASCADE
); 

    SERÁ IMPLEMENTADO FUTURAMENTE
*/