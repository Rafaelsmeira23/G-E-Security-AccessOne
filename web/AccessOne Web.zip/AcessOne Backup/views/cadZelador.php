<?php
    // conexão com o banco de dados
    $conn = new mysqli("localhost", "root", "", "sistema_ge");
    if ($conn->connect_error) {
        // termina o script e mostra erro se não conseguir conectar
        die("Erro na conexão com o banco: " . $conn->connect_error);
    }

    // consulta para buscar os condomínios e popular o select
    $condominios = $conn->query("SELECT id_condominio, nome FROM cad_condominio");

    session_start(); // inicia a sessão para controle de usuário

    // verifica se o usuário está logado e se é do tipo 'Administrador'
    if (!isset($_SESSION['tipo_usuario']) || $_SESSION['tipo_usuario'] !== 'Administrador') {
        header("Location: /index.php"); // redireciona para página principal se não for admin
        exit;
    }

?>

<!DOCTYPE html>
<html lang="pt-BR">
<head>
    <meta charset="UTF-8"> <!-- charset para português -->
    <title>Cadastro de Zelador</title> <!-- título da página -->
    <link rel="stylesheet" href="/public/CSS/zeladorStyle.css"> <!-- CSS externo -->
</head>
<body>
    <div class="formulario">
        <h2>Cadastrar Zelador</h2>

        <!-- Formulário para cadastro de zelador -->
        <form action="../../controllers/zeladorController.php" method="POST" enctype="multipart/form-data" onsubmit="return validarFormulario(event)">
            
            <!-- Campo para nome completo -->
            <label for="nome">Nome Completo:</label>
            <input type="text" id="nome" name="nome" required>

            <!-- Select para escolher o tipo de documento (RG ou CPF) -->
            <label for="documento">Tipo de Documento</label>
            <select id="documento" name="documento" required onchange="atualizarCampoDocumento()">
                <option value="" disabled selected>--Selecione--</option>
                <option value="RG">RG</option>
                <option value="CPF">CPF</option>
            </select>

            <!-- Campo dinâmico para número do documento -->
            <div id="campoNumeroDocumento" style="display:none;">
                <label for="numeroDocumento" id="labelNumeroDocumento">Número do Documento:</label>
                <input type="text" id="numeroDocumento" name="numeroDocumento" placeholder="" required>
            </div>

            <!-- Upload da foto do zelador -->
            <label for="foto">Foto:</label>
            <input type="file" id="foto" name="foto" accept="image/*" onchange="previewFoto(event)" required>
            <img id="preview" alt="Pré-visualização" style="display:none; max-width:150px; margin-top:10px; border-radius:8px;">

            <!-- Email do zelador -->
            <label for="email">Email:</label>
            <input type="email" id="email" name="email" minlength="8" required>

            <!-- Campo para criar senha -->
            <label for="senha">Criar Senha:</label>
            <input type="password" id="senha" name="senha" minlength="6" required>

            <!-- Campo para empresa (opcional) -->
            <label for="empresa">Empresa:</label>
            <input type="text" id="empresa" name="empresa">

            <!-- Select para escolher o condomínio -->
            <label for="id_condominio">Condomínio:</label>
            <select id="id_condominio" name="id_condominio" required>
                <option value="">--Selecione um condomínio--</option>
                <?php while ($row = $condominios->fetch_assoc()): ?>
                    <option value="<?= $row['id_condominio'] ?>"><?= htmlspecialchars($row['nome']) ?></option>
                <?php endwhile; ?>
            </select>

            <br><br>
            <button type="submit">Cadastrar Zelador</button>
            <button type="button" onclick="window.location.href='/views/dashboards/Admin/dashBoardAdmin.php'">Voltar à página principal</button>
        </form>
    </div>

    <!-- Script para documento e pré-visualização -->
    <script>
        function atualizarCampoDocumento() {
            const select = document.getElementById("documento");
            const campo = document.getElementById("campoNumeroDocumento");
            const input = document.getElementById("numeroDocumento");
            const label = document.getElementById("labelNumeroDocumento");

            if (select.value === "RG") {
                campo.style.display = "block";
                label.textContent = "Número do RG:";
                input.placeholder = "00.000.000-0";
                input.pattern = "\\d{2}\\.\\d{3}\\.\\d{3}-[0-9A-Za-z]";
                input.title = "Digite no formato 00.000.000-0";
            } else if (select.value === "CPF") {
                campo.style.display = "block";
                label.textContent = "Número do CPF:";
                input.placeholder = "000.000.000-00";
                input.pattern = "\\d{3}\\.\\d{3}\\.\\d{3}-\\d{2}";
                input.title = "Digite no formato 000.000.000-00";
            } else {
                campo.style.display = "none";
                input.value = "";
            }
        }

        function previewFoto(event) {
            const preview = document.getElementById("preview");
            const file = event.target.files[0];

            if (file) {
                const reader = new FileReader();
                reader.onload = function(e) {
                    preview.src = e.target.result;
                    preview.style.display = "block";
                };
                reader.readAsDataURL(file);
            } else {
                preview.src = "";
                preview.style.display = "none";
            }
        }

        function validarFormulario(event) {
            const form = event.target;
            if (!form.checkValidity()) {
                event.preventDefault();
                alert("Preencha todos os campos obrigatórios corretamente!");
                return false;
            }
            return true;
        }
    </script>
</body>
</html>
