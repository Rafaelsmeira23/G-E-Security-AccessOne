<?php
session_start(); // Inicia a sessão para acessar variáveis de sessão

// Verifica se o usuário está logado e se é Administrador
if (!isset($_SESSION['tipo_usuario']) || $_SESSION['tipo_usuario'] !== 'Administrador') {
    // Se não for administrador, redireciona para a página inicial
    header("Location: /index.php");
    exit;
}
?>

<!DOCTYPE html>
<html lang="pt-BR">
<head>
    <meta charset="UTF-8"> <!-- Define codificação de caracteres -->
    <meta name="viewport" content="width=device-width, initial-scale=1.0"> <!-- Responsivo para dispositivos móveis -->
    <title>Cadastro Completo de Condomínio</title> <!-- Título da página -->
    <link rel="stylesheet" href="/public/CSS/cadastroStyle.css"> <!-- Link para o CSS externo -->
    <script src="/public/JS/cadastroScript.js" defer></script> <!-- Script JS carregado de forma assíncrona após o HTML -->
</head>
<body>

    <div class="container">
        <h2>Cadastro de Condomínio</h2>

        <!-- Formulário para cadastro do condomínio -->
        <form id="formCondominio" method="POST" action="../../controllers/cadCondominioController.php" onsubmit="return finalizarCadastro(event)">
            <!-- Campo para nome do condomínio -->
            <label for="nome">Nome do Condomínio:</label>
            <input type="text" id="nome" name="nome" required>

            <!-- Seleção do tipo de condomínio -->
            <label for="tipo">Tipo de Condomínio:</label>
            <select id="tipo" name="tipo" required>
                <option value=""disabled selected>--Selecione--</option>
                <option value="Residencial">Residencial</option>
                <option value="Comercial">Comercial</option>
            </select>

            <!-- Campo para endereço -->
            <label for="endereco">Endereço:</label>
            <input type="text" id="endereco" name="endereco" required>

            <!-- Campo para CEP (correção do 'for' para id correto) -->
            <label for="num_cep">CEP:</label>
            <input type="text" id="cep" name="cep" placeholder=" Informe o CEP do condomínio: 00000-000" pattern="\d{5}-\d{3}" title="Digite no formato 00000-000" required>

            <!-- Campo para telefone -->
            <label for="telefone">Telefone:</label>
            <input type="text" id="telefone" name="telefone" placeholder="Tel: (00) 00000-0000" pattern="\(\d{2}\) \d{5}-\d{4}" title="Digite no formato (00) 00000-0000" required>

            <!-- Campo para CNPJ -->
            <label for="cnpj">CNPJ:</label>
            <input type="text" id="cnpj" name="cnpj" placeholder="Informe o CNPJ: 00.000.000/0001-00" pattern="\d{2}\.\d{3}\.\d{3}/\d{4}-\d{2}" title="Digite no formato 00.000.000/0001-00" required>

            <br><br>
            
            <!-- Botão para enviar o formulário -->
            <button type="submit">Cadastrar Condomínio</button><br>

            <!-- Botão para voltar à página principal -->
            <button type="button" onclick="window.location.href='/views/dashboards/Admin/dashBoardAdmin.php'">Voltar à página principal</button>

        </form>
    </div>
</body>
</html>