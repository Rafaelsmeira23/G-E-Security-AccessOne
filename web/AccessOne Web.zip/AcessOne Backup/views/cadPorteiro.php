<?php
    // conexao.php - conexão com o banco de dados
    $conn = new mysqli("localhost", "root", "", "sistema_ge"); // conecta ao MySQL
    if ($conn->connect_error) { // checa erros na conexão
        die("Erro na conexão com o banco: " . $conn->connect_error);
    }

    // Consulta para buscar todos os condomínios para popular o select
    $condominios = $conn->query("SELECT id_condominio, nome FROM cad_condominio");

    session_start(); // inicia sessão para controle de usuário

    // Verifica se usuário está logado e é do tipo 'Zelador'
    if (!isset($_SESSION['tipo_usuario']) || $_SESSION['tipo_usuario'] !== 'Zelador') {
        header("Location: /index.php"); // se não for zelador, redireciona para home
        exit;
    }
?>

<!DOCTYPE html>
<html lang="pt-br">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <link rel="stylesheet" href="/public/CSS/portStyle.css">
    <title>Cadastro do Porteiro</title>
</head>
<body>

    <div class="container">

        <div class="form">
            <form id="cadastroForm" method="POST" action="../../controllers/porteiroController.php" enctype="multipart/form-data" onsubmit="return validarFormulario(event)">
                <div class="form-header">
                    <div class="title">
                        <h1>Cadastro do Porteiro</h1>
                    </div>
                </div>

                <div class="input-group">
                    <div class="input-box">
                        <label for="nome">Nome Completo</label>
                        <input id="nome" type="text" name="nome" required />
                    </div>

                    <div class="input-box">
                        <label for="email">E-mail</label>
                        <input id="email" type="email" name="email" placeholder="Ex: funcionariozel@gmail.com" minlength="8" required />
                    </div>
                </div>

                <!-- Documento -->
                <div class="input-group">
                    <div class="input-box">
                        <label for="tipoDocumento">Tipo de Documento</label>
                        <select id="tipoDocumento" name="tipoDocumento" required onchange="atualizarCampoDocumento()">
                            <option value="" disabled selected>--Selecione--</option>
                            <option value="RG">RG</option>
                            <option value="CPF">CPF</option>
                        </select>
                    </div>

                    <div class="input-box" id="campoNumeroDocumento" style="display:none;">
                        <label for="numeroDocumento" id="labelNumeroDocumento">Número do Documento:</label>
                        <input type="text" id="numeroDocumento" name="numeroDocumento" placeholder="" required>
                    </div>
                </div>

                <div class="input-group vertical">
                    <div class="input-box">
                        <label for="senha">Criar Senha:</label>
                        <input type="password" id="senha" name="senha" minlength="6" required />
                    </div>

                    <div class="input-box">
                        <label for="empresa">Empresa (opcional):</label>
                        <input type="text" id="empresa" name="empresa" />
                    </div>

                    <div class="input-box"> 
                        <label for="foto">Foto:</label>
                        <input type="file" name="foto" id="foto" accept="image/*" onchange="previewFoto(event)" required> 
                        <img id="preview" alt="Pré-visualização" style="display:none; max-width:150px; margin-top:10px; border-radius:8px;">
                    </div>

                    <br><br>

                    <div class="form-actions">
                        <button type="submit">Cadastrar</button>
                        <input type="button" value="Voltar a página principal" onclick="window.location.href='/views/dashboards/Zelador/dashBoardZelador.php'" />
                    </div>
                </div>
            </form>
        </div>
    </div>

    <!-- Script para validação e preview -->
    <script>
        function atualizarCampoDocumento() {
            const select = document.getElementById("tipoDocumento");
            const campo = document.getElementById("campoNumeroDocumento");
            const input = document.getElementById("numeroDocumento");
            const label = document.getElementById("labelNumeroDocumento");

            if (select.value === "RG") {
                campo.style.display = "block";
                label.textContent = "Número do RG:";
                input.placeholder = "00.000.000-0";
                input.pattern = "\\d{2}\\.\\d{3}\\.\\d{3}-[0-9A-Za-z]";
                input.title = "Digite no formato 00.000.000-0";
            } else if (select.value === "CPF") {
                campo.style.display = "block";
                label.textContent = "Número do CPF:";
                input.placeholder = "000.000.000-00";
                input.pattern = "\\d{3}\\.\\d{3}\\.\\d{3}-\\d{2}";
                input.title = "Digite no formato 000.000.000-00";
            } else {
                campo.style.display = "none";
                input.value = "";
            }
        }

        function previewFoto(event) {
            const preview = document.getElementById("preview");
            const file = event.target.files[0];

            if (file) {
                const reader = new FileReader();
                reader.onload = function(e) {
                    preview.src = e.target.result;
                    preview.style.display = "block";
                };
                reader.readAsDataURL(file);
            } else {
                preview.src = "";
                preview.style.display = "none";
            }
        }

        function validarFormulario(event) {
            const form = event.target;
            if (!form.checkValidity()) {
                event.preventDefault();
                alert("Preencha todos os campos obrigatórios corretamente!");
                return false;
            }
            return true;
        }
    </script>
</body>
</html>