<?php
session_start();

// Verificação de sessão
if (!isset($_SESSION['id_usuario']) || $_SESSION['tipo_usuario'] !== 'Porteiro') {
    header("Location: login.php");
    exit();
}

// Nome do usuário logado
$nomeUsuario = $_SESSION['nome_usuario'] ?? 'Porteiro';
?>
<!DOCTYPE html>
<html lang="pt-BR">
<head>
  <meta charset="UTF-8">
  <meta name="viewport" content="width=device-width, initial-scale=1.0">
  <title>Dashboard - Administrador</title>
  <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.2/dist/css/bootstrap.min.css" rel="stylesheet">
  <link href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.5.0/css/all.min.css" rel="stylesheet">
  <script src="https://cdn.jsdelivr.net/npm/chart.js"></script>
  <link rel="stylesheet" href="/public/CSS/dshBoardPorteiroStyle.css">
  
</head>
<body>
  <div class="d-flex">
    <!-- Sidebar -->
    <nav class="sidebar p-3">
      <h4><i class="fas fa-shield-alt"></i> Painel Admin</h4>
      <ul class="nav flex-column">
        <li class="nav-item"><a href="/views/dashboards/Porteiro/dashBoardCondominos.php"><i class="fas fa-user"></i> Condôminos</a></li>
        <li class="nav-item"><a href="/views/dashboards/Porteiro/dashBoardChamados.php"><i class="fas fa-bell"></i> Chamados</a></li>
      </ul>

      <div class="logo-container">
        <img src="/public/Image/img2.png" alt="Logo G&E Security">
      </div>
    </nav>

    <!-- Conteúdo Principal -->
    <div class="main-content w-100">
      <div class="d-flex justify-content-between align-items-center mb-4">
        <h2>Olá, <?php echo htmlspecialchars($nomeUsuario); ?> </h2>
        <div class="dropdown">
          <button class="btn-admin" data-bs-toggle="dropdown">
            <i class="fas fa-user-circle"></i> <?php echo htmlspecialchars($nomeUsuario); ?>
          </button>
          <ul class="dropdown-menu dropdown-menu-end">
            <li><a class="btn-logout" href="/controllers/logout.php"><i class="fas fa-sign-out-alt"></i> Logout</a></li>
          </ul>
        </div>
      </div>

        <a href="/views/cadPorteiro.php" class="btn-custom btn-zelador">
          <i class="fas fa-user-tie"></i> Cadastrar Porteiro
        </a>
      </div>

    <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.2/dist/js/bootstrap.bundle.min.js"></script>

</body>
</html>