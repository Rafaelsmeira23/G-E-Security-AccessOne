<?php
session_start();

// Verificação de sessão
if (!isset($_SESSION['id_usuario']) || $_SESSION['tipo_usuario'] !== 'Porteiro') {
    header("Location: /views/login.php");
    exit();
}

$nomeUsuario = $_SESSION['nome'] ?? 'Porteiro';

require_once __DIR__ . '/../../../models/conectaBD.php';
$conn = getConexao();
?>
<!DOCTYPE html>
<html lang="pt-BR">
  <head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Dashboard - Porteiro (Comercial)</title>

    <!-- Bootstrap e Font Awesome -->
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.2/dist/css/bootstrap.min.css" rel="stylesheet">
    <link href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.5.0/css/all.min.css" rel="stylesheet">

    <!-- CSS igual ao residencial -->
    <link rel="stylesheet" href="/public/CSS/dashBoardcondResi.css">
  </head>
  <body>
      <div class="d-flex">
        <!-- Sidebar -->
        <nav class="sidebar">
          <h4><i class="fas fa-building"></i> Painel Porteiro</h4>
          <ul class="nav flex-column">
            <li><a href="#"><i class="fas fa-home"></i> Dashboard</a></li>
            <li><a href="/controllers/logout.php" class="text-danger"><i class="fas fa-sign-out-alt"></i> Logout</a></li>
          </ul>
          <div class="logo-container">
            <img src="/public/Image/img2.png" alt="Logo G&E Security">
          </div>
        </nav>

        <!-- Conteúdo principal -->
        <div class="main-content w-100">
          <h2>Olá, <strong><?= htmlspecialchars($nomeUsuario) ?></strong></h2>

          <div class="menu-buttons">
            <button onclick="mostrarFormulario('empresa')"><i class="fas fa-building"></i> Empresa</button>
              <button onclick="mostrarFormulario('visitante')"><i class="fas fa-user"></i> Visitante</button>
                <button onclick="mostrarFormulario('funcionario')"><i class="fas fa-briefcase"></i> Funcionário</button>
                <button onclick="mostrarFormulario('funcionario_empresa')"><i class="fas fa-briefcase"></i> Funcionário de Empresa</button>
              <button onclick="mostrarFormulario('veiculo')"><i class="fas fa-car"></i> Veículo</button>
            <button onclick="mostrarFormulario('encomenda')"><i class="fas fa-box"></i> Encomenda</button>
          </div>

          <!-- === EMPRESA === -->
          <div id="empresa" class="form-section active">
            <h3>Cadastro de Empresa</h3>
              <form method="POST" action=" /controllers/empresaController.php" onsubmit="return validarEmpresa()">
                <label for="nome_empresa">Nome da Empresa:</label>
                <input type="text" id="nome_empresa" name="nome_empresa" placeholder="Ex: Tech Solutions Ltda" required>

                <label for="responsavel_empresa">Responsável:</label>
                <input type="text" id="responsavel_empresa" name="responsavel_empresa" placeholder="Nome do responsável" required>

                <label for="andar_empresa">Andar:</label>
                <input type="text" id="andar_empresa" name="andar_empresa" placeholder="Ex: 5º" required>

                <label for="conjunto_empresa">Conjunto:</label>
                <input type="text" id="conjunto_empresa" name="conjunto_empresa" placeholder="Ex: 504" required>

                <label for="cnpj_empresa">CNPJ:</label>
                <input type="text" id="cnpj_empresa" name="cnpj_empresa" placeholder="00.000.000/0000-00" 
                      pattern="^\d{2}\.\d{3}\.\d{3}/\d{4}-\d{2}$" 
                      title="Digite no formato 00.000.000/0000-00" required>

                <label for="telefone_empresa">Telefone:</label>
                <input type="text" id="telefone_empresa" name="telefone_empresa" placeholder="(11) 98765-4321"
                      pattern="^\(\d{2}\) \d{4,5}-\d{4}$"
                      title="Digite no formato (00) 00000-0000" required>

                <label for="email_empresa">Email:</label>
                <input type="email" id="email_empresa" name="email_empresa" placeholder="empresa@exemplo.com" required>

                <button type="submit">Cadastrar Empresa</button>
              </form>
          </div>


          <!-- === VISITANTE === -->
          <div id="visitante" class="form-section">
            <h3>Cadastro de Visitante</h3>
              <form method="POST" action="/../../../controllers/visitanteController.php" enctype="multipart/form-data">
                <label>Nome:</label><input type="text" name="nome_visitante" required>

                  <label>Tipo de Visitante:</label>
                  <select name="tipo_visitante" required>
                    <option value="">--Selecione--</option>
                      <option value="Prestador de Serviço">Prestador de Serviço</option>
                        <option value="Familiar">Familiar</option>
                      <option value="Cliente">Cliente</option>
                    <option value="Outros">Outros</option>
                  </select>

                  <label>Conjunto/Sala a ser visitada:</label>
                  <input type="text" name="conjunto" required>

                  <label>Tipo de Documento:</label>
                    <select id="tipoDocumentoVisitante" name="tipoDocumentoVisitante" required onchange="atualizarCampoDocumento('Visitante')">
                      <option value="" disabled selected>--Selecione--</option>
                        <option value="RG">RG</option>
                      <option value="CPF">CPF</option>
                    </select>

                  <div id="campoNumeroDocumentoVisitante" style="display:none;">
                    <label id="documento_visitante">Número do Documento:</label>
                    <input type="text" id="documento_visitante" name="documento_visitante" required>
                  </div>

                  <label>Foto:</label><input type="file" name="foto" accept="image/*" required>

                  <label>Observações:</label>
                  <textarea name="observacoes" rows="3"></textarea>

                  <button type="submit">Cadastrar Visitante</button>
              </form>
          </div>

          <!-- === FUNCIONÁRIO === -->
          <div id="funcionario" class="form-section">
            <h3>Cadastro de Funcionário</h3>
              <form method="POST" action=" /controllers/funcionarioController.php" enctype="multipart/form-data">
                <label>Nome:</label><input type="text" name="nome_funcionario" required>
                  <label>Cargo:</label><input type="text" name="cargo_funcionario" required>
                    <label>Tipo de Documento:</label>
                      <select id="tipoDocumentoFuncionario" name="tipoDocumentoFuncionario" required onchange="atualizarCampoDocumento('Funcionario')">
                        <option value="" disabled selected>--Selecione--</option>
                          <option value="RG">RG</option>
                        <option value="CPF">CPF</option>
                      </select>
                      <div id="campoNumeroDocumentoFuncionario" style="display:none;">
                        <label id="documento_funcionario">Número do Documento:</label><input type="text" id="documento_funcionario" name="documento_funcionario" required>
                      </div>
                     <label>Foto:</label><input type="file" name="foto" accept="image/*" required>
                    <label>Observações:</label>
                  <textarea name="observacoes" rows="3"></textarea>
                <button type="submit">Cadastrar Funcionário</button>
              </form>
          </div>

          <!-- === FUNCIONÁRIO  DE EMPRESA === -->
          <div id="funcionario_empresa" class="form-section">
            <h3>Cadastro de Funcionário Empresarial</h3>
              <form method="POST" action=" /controllers/funcionarioComController.php" enctype="multipart/form-data">
                <label>Nome:</label><input type="text" name="nome_funcionario_com" required>
                  <label>Empresa:</label><input type="text" name="empresa_funcionario_com" required>
                    <label>Tipo de Documento:</label>
                      <select id="tipoDocumentoFuncionarioCom" name="tipoDocumentoFuncionarioCom" required onchange="atualizarCampoDocumento('FuncionarioCom')">
                        <option value="" disabled selected>--Selecione--</option>
                          <option value="RG">RG</option>
                        <option value="CPF">CPF</option>
                      </select>
                      <div id="campoNumeroDocumentoFuncionarioCom" style="display:none;">
                        <label id="documento_funcionario_com">Número do Documento:</label><input type="text" id="documento_funcionario_com" name="documento_funcionario_com" required>
                      </div>
                     <label>Foto:</label><input type="file" name="foto" accept="image/*" required>
                    <label>Observações:</label>
                  <textarea name="observacoes" rows="3"></textarea>
                <button type="submit">Cadastrar Funcionário</button>
              </form>
          </div>

          <!-- === VEÍCULO === -->
          <div id="veiculo" class="form-section">
            <h3>Cadastro de Veículo</h3>
              <form method="POST" action=" /controllers/veiculoController.php">
                <label>Proprietário:</label><input type="text" name="proprietario" required>
                  <label>Placa:</label><input type="text" name="placa" required>
                    <label>Modelo:</label><input type="text" name="modelo">
                  <label>Cor:</label><input type="text" name="cor">
                <button type="submit">Cadastrar Veículo</button>
              </form>
          </div>

          <!-- === ENCOMENDA === -->
          <div id="encomenda" class="form-section">
              <h3>Cadastro de Encomenda</h3>
                <form method="POST" action=" /controllers/encomendaController.php" enctype="multipart/form-data">
                  <label>Nome do Destinatário:</label><input type="text" name="nomeDestinatario" required>
                    <label>Número do Apartamento:</label><input type="text" name="apartamento" required>
                      <label>Descrição da Encomenda:</label>
                        <textarea name="descricaoEncomenda" rows="2"></textarea>
                          <label>Transportadora:</label><input type="text"name="transportadora" required>
                          <label>Código de Identificação:</label><input type="text"name="codigoRastreio">
                        <label>Recebido por (funcionário):</label><input type="text" name="recebidoPor" required>
                      <label>Foto da Encomenda:</label><input type="file" name="foto" accept="image/*" required>
                    <button type="submit">Cadastrar Encomenda</button>
                </form>
          </div>
        </div>
      </div>

      <script>
      function mostrarFormulario(id) {
        document.querySelectorAll('.form-section').forEach(f => f.classList.remove('active'));
        document.getElementById(id).classList.add('active');
      }

      function atualizarCampoDocumento(tipo) {
        const select = document.getElementById("tipoDocumento" + tipo);
        const campo = document.getElementById("campoNumeroDocumento" + tipo);
        const input = document.getElementById("numeroDocumento" + tipo);
        const label = document.getElementById("labelNumeroDocumento" + tipo);

        if (select.value === "RG") {
          campo.style.display = "block";
          label.textContent = "Número do RG:";
          input.placeholder = "00.000.000-0";
          input.pattern = "\\d{2}\\.\\d{3}\\.\\d{3}-[0-9A-Za-z]";
        } else if (select.value === "CPF") {
          campo.style.display = "block";
          label.textContent = "Número do CPF:";
          input.placeholder = "000.000.000-00";
          input.pattern = "\\d{3}\\.\\d{3}\\.\\d{3}-\\d{2}";
        } else {
          campo.style.display = "none";
          input.value = "";
        }
      }
      </script>

      <script>
        // Máscara automática de CNPJ e Telefone
        document.getElementById("cnpj_empresa").addEventListener("input", function(e) {
          let v = e.target.value.replace(/\D/g, "");
          v = v.replace(/^(\d{2})(\d)/, "$1.$2");
          v = v.replace(/^(\d{2})\.(\d{3})(\d)/, "$1.$2.$3");
          v = v.replace(/\.(\d{3})(\d)/, ".$1/$2");
          v = v.replace(/(\d{4})(\d)/, "$1-$2");
          e.target.value = v.substring(0, 18);
        });

        document.getElementById("telefone_empresa").addEventListener("input", function(e) {
          let v = e.target.value.replace(/\D/g, "");
          v = v.replace(/^(\d{2})(\d)/g, "($1) $2");
          v = v.replace(/(\d{4,5})(\d{4})$/, "$1-$2");
          e.target.value = v.substring(0, 15);
        });

        // Validação final no envio
        function validarEmpresa() {
          const cnpj = document.getElementById("cnpj_empresa").value;
          const tel = document.getElementById("telefone_empresa").value;
          const cnpjValido = /^\d{2}\.\d{3}\.\d{3}\/\d{4}-\d{2}$/.test(cnpj);
          const telValido = /^\(\d{2}\) \d{4,5}-\d{4}$/.test(tel);

          if (!cnpjValido) {
            alert("CNPJ inválido! Digite no formato 00.000.000/0000-00.");
            return false;
          }
          if (!telValido) {
            alert("Telefone inválido! Digite no formato (00) 00000-0000.");
            return false;
          }
          return true;
        }
      </script>
  </body>
</html>