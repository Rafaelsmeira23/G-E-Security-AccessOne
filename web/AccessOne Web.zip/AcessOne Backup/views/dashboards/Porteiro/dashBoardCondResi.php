<?php
session_start();

// Verificação de sessão
if (!isset($_SESSION['id_usuario']) || $_SESSION['tipo_usuario'] !== 'Porteiro') {
    header("Location: login.php");
    exit();
}

$nomeUsuario = $_SESSION['nome'] ?? 'Porteiro';

require_once __DIR__ . '/../../../models/conectaBD.php';
$conn = getConexao();

// Buscar os condomínios para preencher selects
$condominios = [];
$result = $conn->query("SELECT id_condominio, nome FROM cad_condominio");
if ($result) {
    while ($row = $result->fetch_assoc()) {
        $condominios[] = $row;
    }
}
?>
<!DOCTYPE html>
<html lang="pt-BR">
  <head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Dashboard - Porteiro</title>

    <!-- Bootstrap e Font Awesome -->
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.2/dist/css/bootstrap.min.css" rel="stylesheet">
    <link href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.5.0/css/all.min.css" rel="stylesheet">

    <!-- CSS externo -->
  <link rel="stylesheet" href="/public/CSS/dashBoardcondResi.css">
  </head>
  <body>
    <div class="d-flex">
      <!-- Sidebar -->
      <nav class="sidebar">
        <h4><i class="fas fa-shield-alt"></i> Painel Porteiro</h4>
        <ul class="nav flex-column">
          <li class="nav-item"><a href="/views/dashboards/Porteiro/dashBoardChamadosP.php"><i class="fas fa-bell"></i> Reservas</a></li>
          <li><a href="/controllers/logout.php" class="text-danger"><i class="fas fa-sign-out-alt"></i> Logout</a></li>
        </ul>
        <div class="logo-container">
          <img src="/public/Image/img2.png" alt="Logo G&E Security">
        </div>
      </nav>

      <!-- Conteúdo principal -->
      <div class="main-content w-100">
        <h2>Olá, <strong><?= htmlspecialchars($nomeUsuario) ?></strong></h2>

        <div class="menu-buttons">
          <button onclick="mostrarFormulario('morador')"><i class="fas fa-user"></i> Morador</button>
            <button onclick="mostrarFormulario('visitante')"><i class="fas fa-id-card"></i> Visitante</button>
              <button onclick="mostrarFormulario('funcionario')"><i class="fas fa-briefcase"></i> Funcionário</button>
            <button onclick="mostrarFormulario('veiculo')"><i class="fas fa-car"></i> Veículo</button>
          <button onclick="mostrarFormulario('encomenda')"><i class="fas fa-box"></i> Encomenda</button>
        </div>

          <!-- Formulários -->
            <div id="form-container">

              <!-- === MORADOR === -->
              <div id="morador" class="form-section active">
                <h3>Cadastro de Morador</h3>
                  <form method="POST" action="../../../controllers/moradorController.php" enctype="multipart/form-data">
                    <label>Nome:</label><input type="text" name="nome_morador" required>
                      <label>Email:</label><input type="email" name="email_morador" required>
                        <label>Telefone:</label><input type="text" name="telefone_morador" required>
                        <label>Tipo de Documento:</label>
                        <select id="tipoDocumentoMorador" name="tipoDocumentoMorador" required onchange="atualizarCampoDocumento('Morador')">
                          <option value="" disabled selected>--Selecione--</option>
                            <option value="RG">RG</option>
                            <option value="CPF">CPF</option>
                        </select>
                        <div id="campoNumeroDocumentoMorador" style="display:none;">
                          <label id="documentoMorador">Número do Documento:</label><input type="text" id="documentoMorador" name="documentoMorador" required>
                        </div>
                        <label>Bloco/Torre:</label><input type="text" name="bloco_torre" required>
                          <label>Apartamento:</label><input type="text" name="apartamento" minlength="3" required>
                            <label>Vínculo:</label>
                            <select name="vinculo_morador" required>
                              <option value="">--Selecione--</option>
                                <option value="proprietario">Proprietário Titular</option>
                                <option value="dependente">Dependente</option>
                            </select>
                      <label>Foto:</label><input type="file" name="foto" accept="image/*" required>
                    <button type="submit">Cadastrar Morador</button>
                  </form>
              </div>

              <!-- === VISITANTE === -->
              <div id="visitante" class="form-section">
                <h3>Cadastro de Visitante</h3>
                  <form method="POST" action=" /../../controllers/visitanteController.php" enctype="multipart/form-data">
                    <label>Nome:</label><input type="text" name="nome_visitante" required>
                      <label>Tipo de Visitante:</label>
                        <select name="tipo_visitante" required>
                          <option value="">--Selecione--</option>
                            <option value="Familiar">Familiar</option>
                              <option value="Conhecido">Conhecido</option>
                            <option value="Prestador de Serviço">Prestador de Serviço</option>
                          <option value="Outros">Outros</option>
                        </select>
                        <label>Bloco/Torre a ser visitado:</label><input type="text" name="bloco_torre" required>
                            <label>Apartamento a ser visitado:</label><input type="text" name="apartamento" minlength="3" required>
                              <label>Tipo de Documento:</label>
                                <select id="tipoDocumentoVisitante" name="tipoDocumentoVisitante" required onchange="atualizarCampoDocumento('Visitante')">
                                  <option value="" disabled selected>--Selecione--</option>
                                    <option value="RG">RG</option>
                                  <option value="CPF">CPF</option>
                                </select>
                                <div id="campoNumeroDocumentoVisitante" style="display:none;">
                                  <label id="documento_visitante">Número do Documento:</label>
                                  <input type="text" id="documento_visitante" name="documento_visitante" required>
                                </div>
                          <label>Foto:</label><input type="file" name="foto" accept="image/*" required>
                        <label>Observações:</label>
                      <textarea name="observacoes" rows="3"></textarea>
                    <button type="submit">Cadastrar Visitante</button>
                  </form>
              </div>

              <!-- === FUNCIONÁRIO === -->
              <div id="funcionario" class="form-section">
                <h3>Cadastro de Funcionário</h3>
                  <form method="POST" action=" /controllers/funcionarioController.php" enctype="multipart/form-data">
                    <label>Nome:</label><input type="text" name="nome_funcionario" required>
                      <label>Cargo:</label><input type="text" name="cargo_funcionario" required>
                        <label>Tipo de Documento:</label>
                          <select id="tipoDocumentoFuncionario" name="tipoDocumentoFuncionario" required onchange="atualizarCampoDocumento('Funcionario')">
                            <option value="" disabled selected>--Selecione--</option>
                              <option value="RG">RG</option>
                              <option value="CPF">CPF</option>
                          </select>
                          <div id="campoNumeroDocumentoFuncionario" style="display:none;">
                            <label id="documento_funcionario">Número do Documento:</label><input type="text" id="documento_funcionario" name="documento_funcionario" required>
                          </div>
                          <label>Foto:</label><input type="file" name="foto" accept="image/*" required>  
                        <label>Observações:</label>
                      <textarea name="observacoes" rows="3"></textarea>
                    <button type="submit">Cadastrar Funcionário</button>
                  </form>
              </div>

              <!-- === VEÍCULO === -->
              <div id="veiculo" class="form-section">
                <h3>Cadastro de Veículo</h3>
                  <form method="POST" action=" /controllers/veiculoController.php">
                    <label>Proprietário:</label><input type="text" name="proprietario" required>
                      <label>Placa:</label><input type="text" name="placa" required>
                        <label>Modelo:</label><input type="text" name="modelo">
                      <label>Cor:</label><input type="text" name="cor">
                    <button type="submit">Cadastrar Veículo</button>
                  </form>
              </div>

              <!-- === ENCOMENDA === -->
              <div id="encomenda" class="form-section">
                <h3>Cadastro de Encomenda</h3>
                  <form method="POST" action=" /controllers/encomendaController.php" enctype="multipart/form-data">
                    <label>Nome do Destinatário:</label><input type="text" name="nomeDestinatario" required>
                      <label>Número do Apartamento:</label><input type="text" name="apartamento" required>
                        <label>Descrição da Encomenda:</label>
                        <textarea name="descricaoEncomenda" rows="2"></textarea>
                          <label>Transportadora:</label><input type="text"name="transportadora" required>
                          <label>Código de Identificação:</label><input type="text"name="codigoRastreio">
                        <label>Recebido por (funcionário):</label><input type="text" name="recebidoPor" required>
                      <label>Foto da Encomenda:</label><input type="file" name="foto" accept="image/*" required>
                    <button type="submit">Cadastrar Encomenda</button>
                  </form>
              </div>
      </div>
    </div>

    <script>
      // alterna entre formulários
        function mostrarFormulario(id) {
          document.querySelectorAll('.form-section').forEach(f => f.classList.remove('active'));
          document.getElementById(id).classList.add('active');
        }

      // controle de documento dinâmico (RG/CPF)
      function atualizarCampoDocumento(tipo) {
        const select = document.getElementById("tipoDocumento" + tipo);
        const campo = document.getElementById("campoNumeroDocumento" + tipo);
        const input = document.getElementById("numeroDocumento" + tipo);
        const label = document.getElementById("labelNumeroDocumento" + tipo);

        if (select.value === "RG") {
            campo.style.display = "block";
            label.textContent = "Número do RG:";
            input.placeholder = "00.000.000-0";
            input.pattern = "\\d{2}\\.\\d{3}\\.\\d{3}-[0-9A-Za-z]";
            input.title = "Digite no formato 00.000.000-0";
        } else if (select.value === "CPF") {
            campo.style.display = "block";
            label.textContent = "Número do CPF:";
            input.placeholder = "000.000.000-00";
            input.pattern = "\\d{3}\\.\\d{3}\\.\\d{3}-\\d{2}";
            input.title = "Digite no formato 000.000.000-00";
        } else {
            campo.style.display = "none";
            input.value = "";
        }
      }
    </script>
  </body>
</html>
