<?php
session_start();

// Verifica login
if (!isset($_SESSION['id_usuario'])) {
    $_SESSION['nome_usuario'] = "Zelador";
}

// Nome do usuário logado
$nomeUsuario = $_SESSION['nome_usuario'] ?? 'Zelador';
?>
<!DOCTYPE html>
<html lang="pt-BR">
<head>
    <meta charset="UTF-8">
    <title>Dashboard - Chamados</title>
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.2/dist/css/bootstrap.min.css" rel="stylesheet">
    <link href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.5.0/css/all.min.css" rel="stylesheet">
    <link rel="stylesheet" href="/public/CSS/dshBoardAdmStyle.css"> <!-- Mesmo estilo dos outros dashboards -->
    <style>
        .btn-visualizar {
            background-color: #fdd700;
            color: white;
            border-radius: 5px;
            padding: 4px 10px;
        }
        .btn-visualizar:hover {
            background-color:rgb(250, 223, 68);
        }
    </style>
</head>
<body>
<div class="d-flex">
    <!-- Sidebar -->
    <nav class="sidebar"><br>
        <h4><i class="fas fa-shield-alt"></i> Painel do Zelador</h4>
        <ul class="nav flex-column">
            <li><a href="/views/dashboards/Zelador/dashBoardCondominos.php"><i class="fas fa-users"></i> Condôminos</a></li>
            <li><a href="/views/dashboards/Zelador/dashBoardZelador.php" class="active"><i class="fas fa-bullhorn"></i> Chamados</a></li>
        </ul>
        <div class="logo-container">
            <img src="/public/Image/img2.png" alt="Logo G&E Security">
        </div>
    </nav>

    <!-- Conteúdo Principal -->
    <div class="main-content w-100">
        <h2><i class="fas fa-bullhorn"></i> Chamados</h2>

        <!-- Filtros -->
        <form class="d-flex gap-3 mb-3 align-items-end">
            <div>
                <label class="text-light">Nº Chamado</label>
                <input type="text" class="form-control" placeholder="Ex: 15">
            </div>
            <div>
                <label class="text-light">Status</label>
                <select class="form-select">
                    <option value="">Todos</option>
                    <option>ABERTO</option>
                    <option>FECHADO</option>
                </select>
            </div>
            <div>
                <label class="text-light">Situação</label>
                <select class="form-select">
                    <option value="TODOS">Todos</option>
                    <option>AGUARDANDO SUPORTE</option>
                    <option>EM ATENDIMENTO</option>
                </select>
            </div>
            <button class="btn btn-primary"><i class="fas fa-search"></i> Filtrar</button>
        </form>

        <!-- Tabela -->
        <div class="card p-4 shadow">
            <table class="table table-dark table-striped text-center align-middle">
                <thead>
                    <tr>
                        <th>Ação</th>
                        <th>Nº Chamado</th>
                        <th>Assunto</th>
                        <th>Descrição</th>
                        <th>Status</th>
                        <th>Situação</th>
                        <th>Data</th>
                    </tr>
                </thead>
                <tbody>
                    <tr>
                        <td><button class="btn-visualizar">Visualizar</button></td>
                        <td>001</td>
                        <td>Chão Sujo</td>
                        <td>Piso com mancha de café próximo ao<br><br>
                        hall de elevadores no sexto andar.</td>
                        <td>ABERTO</td>
                        <td>EM ATENDIMENTO</td>
                        <td>10/12/2025 16:42</td>
                    </tr>
                    <tr>
                        <td><button class="btn-visualizar">Visualizar</button></td>
                        <td>002</td>
                        <td>Lâmpada queimada</td>
                        <td>Lâmpada da área externa, próxima à brinquedoteca.</td>
                        <td>ABERTO</td>
                        <td>AGUARDANDO SUPORTE</td>
                        <td>11/12/2025 21:15</td>
                    </tr>

                    </tr>
                </tbody>
            </table>
        </div>
    </div>
</div>
</body>
</html>
