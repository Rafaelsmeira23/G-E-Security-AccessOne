<?php
session_start();

// Verificação de sessão
if (!isset($_SESSION['id_usuario']) || $_SESSION['tipo_usuario'] !== 'Administrador') {
    header("Location: login.php");
    exit();
}

// Nome do usuário logado
$nomeUsuario = $_SESSION['nome_usuario'] ?? 'Administrador';
?>
<!DOCTYPE html>
<html lang="pt-BR">
<head>
  <meta charset="UTF-8">
  <meta name="viewport" content="width=device-width, initial-scale=1.0">
  <title>Dashboard - Administrador</title>
  <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.2/dist/css/bootstrap.min.css" rel="stylesheet">
  <link href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.5.0/css/all.min.css" rel="stylesheet">
  <script src="https://cdn.jsdelivr.net/npm/chart.js"></script>
  <link rel="stylesheet" href="/public/CSS/dshBoardAdmStyle.css">
  
</head>
<body>
  <div class="d-flex">
    <!-- Sidebar -->
    <nav class="sidebar p-3">
      <h4><i class="fas fa-shield-alt"></i> Painel Admin</h4>
      <ul class="nav flex-column">
        <li class="nav-item"><a href="/views/dashboards/Admin/dashBoardUsuarios.php"><i class="fas fa-user"></i> Usuários</a></li>
        <li class="nav-item"><a href="/views/dashboards/Admin/dashBoardCondominios.php"><i class="fas fa-building"></i> Condomínios</a></li>
      </ul>

      <div class="logo-container">
        <img src="/public/Image/img2.png" alt="Logo G&E Security">
      </div>
    </nav>

    <!-- Conteúdo Principal -->
    <div class="main-content w-100">
      <div class="d-flex justify-content-between align-items-center mb-4">
        <h2>Olá, <?php echo htmlspecialchars($nomeUsuario); ?> </h2>
        <div class="dropdown">
          <button class="btn-admin" data-bs-toggle="dropdown">
            <i class="fas fa-user-circle"></i> <?php echo htmlspecialchars($nomeUsuario); ?>
          </button>
          <ul class="dropdown-menu dropdown-menu-end">
            <li><a class="btn-logout" href="/controllers/logout.php"><i class="fas fa-sign-out-alt"></i> Logout</a></li>
          </ul>
        </div>
      </div>

      <!-- Botões Centrais -->
      <div class="center-buttons">
        <a href="/views/cadCondominio.php" class="btn-custom btn-condominio">
          <i class="fas fa-building"></i> Cadastrar Condomínio
        </a>

        <a href="/views/cadZelador.php" class="btn-custom btn-zelador">
          <i class="fas fa-user-tie"></i> Cadastrar Zelador
        </a>
      </div>

    <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.2/dist/js/bootstrap.bundle.min.js"></script>

</body>
</html>