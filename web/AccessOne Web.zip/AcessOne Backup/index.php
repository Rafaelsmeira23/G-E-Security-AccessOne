<?php 
  session_start();
?>

<!DOCTYPE html>
<html lang="pt-br">
<head>
  <meta charset="UTF-8" />
  <meta name="viewport" content="width=device-width, initial-scale=1.0" />
  <title>G&E Security</title>
  <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.5.0/css/all.min.css" />
  <link href="https://fonts.googleapis.com/css2?family=Poppins:wght@400;600&display=swap" rel="stylesheet" />
  <link rel="stylesheet" href="/public/CSS/mainStyle.css" />
  <link rel="stylesheet" href="/public/CSS/chatbot.css" />
</head>

<body>
  <nav>
    <div class="container">
      <div class="logo">
        <a href="#">
          <img src="/public/Image/img2.png" alt="Logo G&E Security" />
        </a>
      </div>

      <ul>
        <?php if (isset($_SESSION['id_usuario']) && isset($_SESSION['nome'])): ?>
          <li><a href="/controllers/logout.php">Logout</a></li><br>
        <?php else: ?>
          <li><a href="/views/login.php">Login</a></li>
        <?php endif; ?>
      </ul>

      <div class="social-icons">
        <a href="https://www.facebook.com/senaisp.pirituba/?locale=pt_BR" target="_blank"><i class="fab fa-facebook-f"></i></a>
        <a href="https://www.instagram.com/senai.sp/" target="_blank"><i class="fab fa-instagram"></i></a>
        <a href="https://x.com/senainacional" target="_blank"><i class="fab fa-twitter"></i></a>
      </div>
    </div>
  </nav>

  <!-- Banner -->
  <section class="banner">
    <img src="/public/Image/geesec.jpg" alt="Gee">
  </section>

  <!-- Cabeçalho -->
  <header>
    <div class="center">

      <section class="carousel-container">
        <div class="carousel">
          <button class="prev" onclick="mudarSlide(-1)">&#10094;</button>
          <img id="slide" src="/public/Image/foto1.jpg" alt="Imagem 1">
          <button class="next" onclick="mudarSlide(1)">&#10095;</button>
        </div>
        <div class="selectors"></div>
      </section>

      <div class="info-text">
        <h1>Quem Somos</h1>
        <div class="sobre-nós">
          <div class="texto">
            <p>
              A G&E Security é uma empresa inovadora no setor de segurança e tecnologia, responsável pelo desenvolvimento do 
              <strong>AccessOne</strong>, um sistema completo e integrado para controle de acesso, monitoramento e gestão de portaria. 
              Utilizamos tecnologias de última geração para oferecer soluções eficazes e adaptáveis a residências, empresas, 
              condomínios e indústrias.
              Nosso compromisso é garantir segurança, praticidade e eficiência através de uma plataforma moderna e altamente confiável.
            </p>
          </div>
        </div>
      </div>

    </div>

    <div class="quem-somos-section">
      <div class="imagem-fundo"></div>
      <div class="quem-somos-texto">
        <h1>Diferenciais</h1>
        <p>
          O grande diferencial da G&E Security é o <strong>AccessOne</strong>, uma solução centralizada que integra portaria, visitantes, 
          estacionamento, cadastro de moradores e controle de acesso — tudo em um único lugar.
          Essa unificação elimina erros operacionais, aumenta a eficiência da equipe e reduz custos, tornando o processo mais seguro 
          e automatizado. O AccessOne também é escalável e inteligente, evoluindo conforme as necessidades de cada cliente e sempre 
          acompanhando as tendências modernas de automação e segurança patrimonial.
        </p>
      </div>
    </div>

    <div class="info-cards">
      <div class="card">
        <div class="card-title">Missão</div>
        <div class="card-text">
          <p>
            Oferecer soluções inteligentes e integradas por meio do <strong>AccessOne</strong>, garantindo excelência, inovação e eficiência 
            no controle de acesso e segurança. Buscamos entregar muito mais que tecnologia — entregamos tranquilidade, confiabilidade 
            e valor para nossos clientes.
          </p>
        </div>
      </div>

      <div class="card">
        <div class="card-title">Visão</div>
        <div class="card-text">
          <p>
            Ser referência nacional em tecnologia para controle de acesso ao consolidar o <strong>AccessOne</strong> como a plataforma mais 
            completa, moderna e intuitiva do mercado. Nosso objetivo é transformar a gestão de ambientes em uma experiência mais 
            tecnológica, conectada e eficiente.
          </p>
        </div>
      </div>

      <div class="card">
        <div class="card-title">Valores</div>
        <div class="card-text">
          <p>
            • <strong>Inovação contínua:</strong> Evolução constante do AccessOne com novas tecnologias. <br>
            • <strong>Comprometimento:</strong> Suporte dedicado e personalização para cada cliente. <br>
            • <strong>Transparência:</strong> Todos os processos são claros, auditoráveis e registrados dentro do sistema. <br>
            • <strong>Eficiência:</strong> Centralizamos diversas operações em uma única plataforma. <br>
            • <strong>Confiança:</strong> Relações sólidas baseadas em responsabilidade e resultados reais.
          </p>
        </div>
      </div>
    </div>

  </header>

  <!-- Rodapé -->
  <footer>
    <p>&copy; 2025 G&E Security</p>
  </footer>

  <script src="/public/JS/imageScript.js"></script>

  <!-- CHATBOT -->
  <div id="chatbot-container">
      <button id="chatbot-open">💬</button>

      <div id="chatbot-box" class="closed">
          <header>
              <span>Assistente Virtual</span>
              <button id="chatbot-close">✕</button>
          </header>

          <div id="chatbot-messages"></div>

          <form id="chatbot-form" autocomplete="off">
              <input id="chatbot-input" type="text" placeholder="Digite sua pergunta..." required>
              <button type="submit">Enviar</button>
          </form>
      </div>
  </div>

  <script src="/public/JS/chatbot.js"></script>

</body>
</html>