<?php 
require_once '../models/visitanteModel.php'; 
session_start();

class VisitanteController { 
    private $model; 
    
    public function __construct() { 
        $this->model = new VisitanteModel(); 
    } 
    
    public function cadastrar($dados) { 
        if ($this->model->inserir($dados)) { 
            echo "<script>alert('Visitante cadastrado com sucesso!'); window.history.back();</script>"; 
        } else { 
            echo "<script>alert('Erro ao cadastrar visitante.'); window.history.back();</script>"; 
        } 
    } 
} 

// POST
if ($_SERVER['REQUEST_METHOD'] === 'POST') {

    $controller = new VisitanteController(); 

    // Diretório de upload
    $uploadDir = __DIR__ . '/../public/uploads/Visitantes/'; 
    $urlFoto = ''; 

    if (!is_dir($uploadDir)) { 
        mkdir($uploadDir, 0755, true); 
    } 
    
    // Upload da foto
    if (!empty($_FILES['foto']['name']) && $_FILES['foto']['error'] === UPLOAD_ERR_OK) { 

        $ext = strtolower(pathinfo($_FILES['foto']['name'], PATHINFO_EXTENSION)); 
        $permitidos = ['jpeg', 'jpg', 'png'];

        if (in_array($ext, $permitidos)) { 
            $novoNome = uniqid('visit_') . '.' . $ext; 
            $destino = $uploadDir . $novoNome;

            if (move_uploaded_file($_FILES['foto']['tmp_name'], $destino)) { 
                $urlFoto = '/public/uploads/Visitantes/' . $novoNome; 
            } 
        }
    } 

    // DADOS QUE REALMENTE EXISTEM NOS FORMULÁRIOS
    $dados = [ 
    'id_condominio'       => $_SESSION['id_condominio'],
    'tipo_visitante'      => $_POST['tipo_visitante'],
    'nome'                => $_POST['nome_visitante'],
    'url_foto'            => $urlFoto,
    'documento'           => $_POST['documento_visitante'],
    'observacoes'         => $_POST['observacoes'] ?? null
];

// RESIDENCIAL → bloco + apartamento
if ($_SESSION['tipo_condominio'] === 'Residencial') {
    $dados['bloco_torre'] = $_POST['bloco_torre'];
    $dados['apartamento'] = $_POST['apartamento'];
    $dados['empresa'] = null;
    $dados['cargo'] = null;
}

// COMERCIAL → andar + conjunto
else {
    $dados['empresa'] = $_POST['conjunto'];   // armazena o CONJUNTO
    $dados['bloco_torre'] = null;
    $dados['apartamento'] = null;
}

$controller->cadastrar($dados);

}
