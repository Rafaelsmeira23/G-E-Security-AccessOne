<?php
require_once '../models/moradorModel.php';
session_start(); // ✅ necessário para acessar os dados da sessão

class MoradorController {
    private $model;

    // Construtor que instancia o model do morador
    public function __construct() {
        $this->model = new MoradorModel();
    }

    // Método para cadastrar um morador no banco
   public function cadastrar($dados) {
    if ($this->model->inserir($dados)) {
        echo "<script>alert('Morador cadastrado com sucesso!'); window.history.back();</script>";
        } else {
            echo "<script>alert('Erro ao cadastrar Morador.'); window.history.back();</script>";
        }
    }

}

// Se o formulário foi submetido via POST
if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $controller = new MoradorController();

    $uploadDir = __DIR__ . '/../public/uploads/Moradores/';
    $urlFoto = '';

    // Cria o diretório de upload se não existir
    if (!is_dir($uploadDir)) {
        mkdir($uploadDir, 0755, true);
    }

    // Processamento da imagem
    if (isset($_FILES['foto']) && $_FILES['foto']['error'] === UPLOAD_ERR_OK) {
        $fileTmpPath = $_FILES['foto']['tmp_name'];
        $fileName = basename($_FILES['foto']['name']);
        $fileExtension = strtolower(pathinfo($fileName, PATHINFO_EXTENSION));
        $allowedExtensions = ['jpeg', 'jpg', 'png'];
    

        if (in_array($fileExtension, $allowedExtensions)) {
            $newFileName = uniqid('foto_') . '.' . $fileExtension;
            $destPath = $uploadDir . $newFileName;

            if (move_uploaded_file($fileTmpPath, $destPath)) {
                // Caminho relativo para salvar no banco
                $urlFoto = '/public/uploads/Moradores/' . $newFileName;
            }
        }
    }

    // Dados vindos do formulário
    $dados = [
        'nome'                => $_POST['nome_morador'] ?? '',
        'documento'           => $_POST['documentoMorador'] ?? '',
        'telefone'            => $_POST['telefone_morador'] ?? '',
        'email'               => $_POST['email_morador'] ?? '',
        'bloco_torre'         => $_POST['bloco_torre'] ?? '',
        'apartamento'         => $_POST['apartamento'] ?? '',
        'vinculo_apartamento' => $_POST['vinculo_morador'] ?? '',
        'url_foto'            => $urlFoto,
        'id_condominio'       => $_SESSION['id_condominio'] ?? null  // Importante: null, não string vazia
    ];
    
    if (empty($_SESSION['id_condominio'])) {
        die("⚠ ERRO: Nenhum id_condominio encontrado na sessão! Verifique o login.");
    }
    
    echo "ID do condomínio: " . $_SESSION['id_condominio'];
    

    $controller->cadastrar($dados);
}   