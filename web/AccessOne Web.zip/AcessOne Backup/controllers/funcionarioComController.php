<?php
require_once '../models/funcionarioComModel.php';
session_start();

class FuncionarioController {
    private $model;

    public function __construct() {
        $this->model = new FuncionarioModel();
    }

    public function cadastrar($dados) {
        if ($this->model->inserir($dados)) {
            echo "<script>alert('Funcionário cadastrado com sucesso!'); window.history.back();</script>";
        } else {
            echo "<script>alert('Erro ao cadastrar Funcionário.'); window.history.back();</script>";
        }
    }
}

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $controller = new FuncionarioController();

    $idCondominio = $_SESSION['id_condominio']; // herda do zelador logado 

    $uploadDir = __DIR__ . '/../public/uploads/Funcionarios/';
    if (!is_dir($uploadDir)) mkdir($uploadDir, 0755, true);

    $urlFoto = '';
    if (isset($_FILES['foto']) && $_FILES['foto']['error'] === UPLOAD_ERR_OK) {
        $ext = strtolower(pathinfo($_FILES['foto']['name'], PATHINFO_EXTENSION));
        $allowed = ['jpeg', 'jpg', 'png'];
        if (in_array($ext, $allowed)) {
            $newFile = uniqid('foto_') . '.' . $ext;
            $dest = $uploadDir . $newFile;
            if (move_uploaded_file($_FILES['foto']['tmp_name'], $dest)) {
                $urlFoto = '/public/uploads/Funcionarios/' . $newFile;
            }
        }
    }

    $dados = [
        'nome'         => $_POST['nome_funcionario_com'] ?? '',
        'documento'    => $_POST['documento_funcionario_com'] ?? '',
        'telefone'     => !empty($_POST['telefone_funcionario']) ? $_POST['telefone_funcionario'] : null,
        'empresa'      => $_POST['empresa_funcionario_com'] ?? '',
        'observacoes'  => $_POST['observacoes'] ?? '',
        'url_foto'     => $urlFoto,
        'id_condominio' => $idCondominio, // Condomínio herdado automaticamente!
    ];

    $controller->cadastrar($dados);
}
