<?php
require_once '../models/encomendaModel.php';
session_start();

class EncomendaController {
    private $model;

    public function __construct() {
        $this->model = new EncomendaModel();
    }

    public function cadastrar($dados) {
        if ($this->model->inserir($dados)) {
            echo "<script>alert('Encomenda cadastrada com sucesso!'); window.history.back();</script>";
        } else {
            echo "<script>alert('Erro ao cadastrar encomenda.'); window.history.back();</script>";
        }
    }
}

if ($_SERVER['REQUEST_METHOD'] === 'POST') {

    $controller = new EncomendaController();

    // --------------------- UPLOAD DA FOTO ---------------------
    $uploadDir = __DIR__ . '/../public/uploads/Encomendas/';
    $urlFoto = '';

    if (!is_dir($uploadDir)) {
        mkdir($uploadDir, 0755, true);
    }

    if (isset($_FILES['foto']) && $_FILES['foto']['error'] === UPLOAD_ERR_OK) {

        $tmp = $_FILES['foto']['tmp_name'];
        $nome = basename($_FILES['foto']['name']);
        $ext = strtolower(pathinfo($nome, PATHINFO_EXTENSION));
        $permitidas = ['jpeg', 'jpg', 'png'];

        if (in_array($ext, $permitidas)) {

            $novoNome = uniqid('encomenda_') . '.' . $ext;
            $destino = $uploadDir . $novoNome;

            if (move_uploaded_file($tmp, $destino)) {
                $urlFoto = '/public/uploads/Encomendas/' . $novoNome;
            }
        }
    }

    // --------------------- DADOS DO FORMULÁRIO ---------------------
    $dados = [
        'id_condominio'        => $_SESSION['id_condominio'], // OBRIGATÓRIO
        'id_usuario'           => null, // sem vínculo, pode adicionar depois
        'url_foto'             => $urlFoto,
        'descricao'            => $_POST['descricaoEncomenda'] ?? '',
        'codigo_rastreamento'  => $_POST['codigoRastreio'] ?? null,
        'status'               => 'Recebida na Portaria', // ✔ compatível com o ENUM
    ];

    $controller->cadastrar($dados);
}
