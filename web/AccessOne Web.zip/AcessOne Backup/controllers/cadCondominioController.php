
<?php
// Importa o model responsável por lidar com o banco de dados do condomínio
require_once '../models/cadCondominioModel.php';

// Classe do Controller responsável pelas regras de negócio relacionadas ao condomínio
class CondominioController {
    private $model;

    public function __construct() { // Construtor: instancia o model ao iniciar o controller
        $this->model = new CondominioModel();
    }

    public function cadastrar($dados) { // Função pública para cadastrar um condomínio com os dados recebidos
        if ($this->model->inserir($dados)) { // Chama o método 'inserir' do model, passando os dados
            
            // Em caso de sucesso, redireciona para a tela de cadastro do zelador
            header("Location: /views/dashboards/Admin/dashBoardAdmin.php");
            exit;
        } else { // Em caso de falha, exibe uma mensagem de erro
            echo "Erro ao cadastrar condomínio.";
        }
    }
}

// Verifica se o formulário foi enviado via método POST
if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    // Instancia o controller
    $controller = new CondominioController();

    $dados = [ // Recebe os dados do formulário, garantindo valores padrão vazios se algum campo não for enviado
        'nome' => $_POST['nome'] ?? '',
        'tipo' => $_POST['tipo'] ?? '',
        'endereco' => $_POST['endereco'] ?? '',
        'cep' => $_POST['cep'] ?? '',
        'telefone' => $_POST['telefone'] ?? '',
        'cnpj' => $_POST['cnpj'] ?? ''
    ];
    
    // Chama o método de cadastro com os dados recebidos
    $controller->cadastrar($dados);
}