<?php 
require_once '../models/zeladorModel.php'; 

class ZeladorController {
    private $model;

    public function __construct() { 
        $this->model = new ZeladorModel(); 
    } 

    public function cadastrar($dados) {
        if ($this->model->inserir($dados)) {
                header("Location: /views/dashboards/Admin/dashBoardAdmin.php");
            exit;
        } else {
            echo "Erro ao cadastrar Zelador.";
        }
    }
}

// Execução se vier via POST
if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $controller = new ZeladorController();

    // Define diretório de upload
    $uploadDir = __DIR__ . '/../public/uploads/Zeladores/';
    $urlFoto = '';

    // Verifica se diretório existe, senão cria
    if (!is_dir($uploadDir)) {
        mkdir($uploadDir, 0755, true);
    }

    // Processa upload da foto
    if (isset($_FILES['foto']) && $_FILES['foto']['error'] === UPLOAD_ERR_OK) {
        $fileTmpPath = $_FILES['foto']['tmp_name'];
        $fileName = basename($_FILES['foto']['name']);
        $fileExtension = strtolower(pathinfo($fileName, PATHINFO_EXTENSION));
        $allowedExtensions = ['jpeg', 'jpg', 'png'];

        if (in_array($fileExtension, $allowedExtensions)) {
            $newFileName = uniqid('foto_') . '.' . $fileExtension;
            $destPath = $uploadDir . $newFileName;

            if (move_uploaded_file($fileTmpPath, $destPath)) {
                // Caminho relativo para salvar no banco
                $urlFoto = '/public/uploads/Zeladores/' . $newFileName;
            }
        }
    }

    // Monta o array de dados
    $dados = [
        'nome' => $_POST['nome'] ?? '',
        'documento' => $_POST['numeroDocumento'] ?? '',
        'url_foto' => $urlFoto,
        'email' => $_POST['email'] ?? '',
        'senha' => $_POST['senha'] ?? '',
        'empresa' => $_POST['empresa'] ?? '',
        'id_condominio' => isset($_POST['id_condominio']) ? (int)$_POST['id_condominio'] : null,
        'tipo_usuario' => 'Zelador'
    ];

    // Cadastra zelador
    $controller->cadastrar($dados);
}
