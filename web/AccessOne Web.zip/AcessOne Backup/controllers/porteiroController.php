<?php 
require_once '../models/porteiroModel.php';
session_start(); // ✅ necessário para acessar os dados da sessão

class PorteiroController { 
    private $model; 
    
    // Construtor que instancia o model do porteiro
    public function __construct() { 
        $this->model = new PorteiroModel(); 
    } 
    
    // Método para cadastrar um porteiro no banco
    public function cadastrar($dados) {
        if ($this->model->inserir($dados)){
            // Se cadastro der certo, redireciona para página de consulta
            header("Location: /views/dashboards/Zelador/dashBoardZelador.php");
            exit;
        } else {
            // Caso erro, exibe mensagem
            echo "Erro ao cadastrar Porteiro.";
        }
    }
}


// Se o formulário foi submetido via POST
if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $controller = new PorteiroController(); 

    // Garante que o zelador está logado e possui um condomínio vinculado
    if (!isset($_SESSION['id_condominio'])) {
        die("Erro: Nenhum condomínio vinculado ao usuário atual.");
    }

    $idCondominio = $_SESSION['id_condominio']; // ✅ herda do zelador logado

    // Define o diretório onde a foto será salva
    $uploadDir = __DIR__ . '/../public/uploads/Porteiros/'; 
    $urlFoto = '';

    // Cria o diretório de uploads caso não exista
    if (!is_dir($uploadDir)) {
         mkdir($uploadDir, 0755, true); 
    } 
    
    // Processa o upload da foto do porteiro
    if (isset($_FILES['foto']) && $_FILES['foto']['error'] === UPLOAD_ERR_OK) { 
        $fileTmpPath = $_FILES['foto']['tmp_name']; 
        $fileName = basename($_FILES['foto']['name']); 
        $fileExtension = strtolower(pathinfo($fileName, PATHINFO_EXTENSION)); 
        $allowedExtensions = ['jpeg', 'jpg', 'png']; // Permite apenas imagens jpeg e png
        
        if (in_array($fileExtension, $allowedExtensions)) { 
            // Gera nome único para evitar sobrescrever arquivos
            $newFileName = uniqid('foto_') . '.' . $fileExtension; 
            $destPath = $uploadDir . $newFileName; 
            
            // Move o arquivo para o diretório definido
            if (move_uploaded_file($fileTmpPath, $destPath)) { 
                // Salva a URL relativa da foto para salvar no banco
                $urlFoto = '/public/uploads/Porteiros/' . $newFileName; 
            } 
        } 
    } 
    
    // Monta os dados recebidos do formulário
    $dados = [ 
        'nome' => $_POST['nome'] ?? '', 
        'documento' => $_POST['numeroDocumento'] ?? '', 
        'url_foto' => $urlFoto, 
        'email' => $_POST['email'] ?? '', 
        'senha' => $_POST['senha'] ?? '',
        'empresa' => $_POST['empresa'] ?? '', 
        'id_condominio' => $idCondominio, // ✅ Condomínio herdado automaticamente
        'tipo_usuario' => 'Porteiro' // Define tipo de usuário
    ]; 
        
    // Chama o método para cadastrar o porteiro com os dados coletados
    $controller->cadastrar($dados); 
}
?>
