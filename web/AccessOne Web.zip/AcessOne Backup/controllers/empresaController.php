<?php
session_start();
require_once '../models/empresaModel.php';

class EmpresaController {
    private $model;

    public function __construct() {
        $this->model = new EmpresaModel();
    }

    public function cadastrar($dados) {
        if ($this->model->inserir($dados)) {
            echo "<script>alert('Empresa cadastrada com sucesso!'); window.history.back();</script>";
        } else {
            echo "<script>alert('Erro ao cadastrar empresa.'); window.history.back();</script>";
        }
    }
}

// Se o formulário for enviado via POST
if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $controller = new EmpresaController();

    // Dados do formulário
    $dados = [
        'id_condominio'      => $_SESSION['id_condominio'] ?? null,
        'nome'               => $_POST['responsavel_empresa'] ?? '',
        'empresa'            => $_POST['nome_empresa'] ?? '',
        'conjunto'           => $_POST['conjunto_empresa'],
        'cnpj'               => $_POST['cnpj_empresa'] ?? '',
        'telefone'           => $_POST['telefone_empresa'] ?? '',
        'email'              => $_POST['email_empresa'] ?? '',
        'endereco'           => $_POST['endereco_empresa'] ?? ''
    ];

    // Envia os dados para o Model
    $controller->cadastrar($dados);
}
?>
